function toCurrency(amount){
    return amount.toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,");
}


(function( $ ){
	var methods	=	{
		self: "",
		settings: "",
		data: "",
		init: function(options) {
			methods.settings = $.extend({
				width: 200,
				height: 300,
				radius: 0,
				innerradius: 20,
				circs: 1
			}, options );
			

			methods.self	=	this;
			methods.settings.radius	=	Math.min(methods.settings.width, methods.settings.height) / 2 - 150;
			methods.setup();
		},
		getArc: function(radius, innerradius){
			var arc = d3.svg.arc()
				.innerRadius(innerradius)
				.outerRadius(radius);
			return arc;
		},
		setup: function() {
			d3.csv("data/data.csv", function(error, data) {
				methods.data	=	data;
				var totalab	=	0, totals = 0;

				data.forEach(function(d){
					totalab	+=	eval(d.allocatedbudget);
					totals	+=	eval(d.spent);
				})

				methods.allocatedbudgettotal = toCurrency(totalab);
				
				var xr	=	( totals / totalab ) * methods.settings.radius;	

				var max = d3.max(data, function(d){ return eval(d.allocatedbudget); });
				var min = d3.min(data, function(d){ return eval(d.allocatedbudget); });

				var max1 = d3.max(data, function(d){ return eval(d.spent); });
				var min1 = d3.min(data, function(d){ return eval(d.spent); });

				var newmax	=	200;
				var newmin	=	0;

				var linearScale = d3.scale.linear()
					.domain([min1, max1])
					.range([100, 230])

				/*Auto range of colors*/
				methods.color		=	d3.scale.category20c();

				//Manual range of colors
				/*methods.color		=	d3.scale.ordinal()
					.range(["#001D42", "#1478A5", "#1BA7DA", "#646464", "#97999B", "#B7B7B7", "#CBCBCB"]);*/

				methods.pie = d3.layout.pie()
					.sort(null)
					.value(function(d) { 
					return d.allocatedbudget; 
				});

				methods.arc = d3.svg.arc()
					.outerRadius(function(d, i){ 
						var v2		=	40 + ( d.data.spent / d.data.allocatedbudget ) * methods.settings.radius;
						if( eval(v2) > 250 ) {
							v2 = 250;
						}
						//console.log(v2)
						return v2;
					})
					.innerRadius(40);
				
				methods.svg = d3.select("#chart").append("svg")
					.attr({ "width" : methods.settings.width, "height" : methods.settings.height })
					.append("g")
					.attr("transform", "translate(" + methods.settings.width / 2 + "," + methods.settings.height / 2 + ")");
				

				methods.labels = methods.svg.append("g")
					.attr("class", "labels");
				

				methods.pointers = methods.svg.append("g")
					.attr("class", "pointers");
				
				methods.outerlines();
				

				methods.update();
				
				methods.text();
				
			})
		},
		update: function(dataSet){
		
			methods.g = methods.svg.datum(methods.data).selectAll(".arc")
				.data(methods.pie)
				.enter().append("g")
				.attr("class", "arc");

			var path = methods.g.append("path")
				 .attr("d", methods.arc)
				 .style("cursor", "pointer")
				 .style("stroke", "0.8")
				 .style("stroke-color", "#CCC")
				 .style("fill", function(d, i) { 
							//console.log(d.data.spent+methods.color(d.data.spent));
							return methods.color(d.data.spent); 
					})
				 .on("click", function(d){
					alert(d.data.roomid)
				 })
				 .transition().delay(function(d, i, j) {
						return i * 800; 
				 }).duration(500)
				.attrTween('d', function(d,x,y) {
					
				});

			var dummycenter = methods.svg.append("circle")
				.attr("r", methods.settings.radius / 2.4)
				.attr("fill", "#FFF")
				.attr("fill-opacity", 0.5);

			methods.svg.append("svg:text")
				.style({"font-family" : "Arial", "font-size" : "17px", "font-weight" : "bold", "fill" : "#001e41", "cursor" : "pointer", "fill-opacity" : 1})	
				.text(function(){
					return '$'+methods.allocatedbudgettotal;
				})
				.each(function(d){
					var bbox	=	this.getBBox();
					d.ah		=	bbox.height;
					return d.aw =	bbox.width;
				})
				.attr("x", function(d){
					return - (d.aw / 2)
				})
				.attr("y", function(d){
					return (d.ah / 2)
				})
		},
		text: function() {
			var labels = methods.g.append("text")
				.attr("text-anchor", "middle");
			var ir = 60, r = methods.settings.radius;

			labels
					.attr("x", function(d) {
						var a = d.startAngle + (d.endAngle - d.startAngle)/2 - Math.PI/2;
						d.cx = Math.cos(a) * (ir+((r-ir)/2));
						return d.x = Math.cos(a) * (r + 40);
					})
					.attr("y", function(d) {
						var a = d.startAngle + (d.endAngle - d.startAngle)/2 - Math.PI/2;
						d.cy = Math.sin(a) * (ir+((r-ir)/2));
						return d.y = Math.sin(a) * (r + 40);
					})
					.style("font-size","12px")
					.text(function(d) {
						//return d.data.room; 
					})
					.on("click", function(d){
						//alert('asdf')
					})
					.attr("class", "room-names")
					.style("cursor", "pointer")
					.each(function(d) {
						var bbox = this.getBBox();
						d.sx = d.x - bbox.width/2 - 2;
						d.ox = d.x + bbox.width/2 + 2;
						d.sy = d.oy = d.y + 5;
					})
					.transition()
						.duration(300);

				var labelValues	=	methods.g.append("text")
									.attr("text-anchor", "middle");
				labelValues
					.attr("x", function(d) {
						var a = d.startAngle + (d.endAngle - d.startAngle)/2 - Math.PI/2;
						d.cx = Math.cos(a) * (ir+30+((r-ir)/2));
						if(d.cx > d.ox) {
							return d.x = - 300;
						} else {
							return d.x = ( methods.settings.width / 2 ) - 50;
						}
						
					})
					.attr("y", function(d) {
						var a = d.startAngle + (d.endAngle - d.startAngle)/2 - Math.PI/2;
						d.cy = Math.sin(a) * (ir+30+((r-ir)/2));
						return d.y = Math.sin(a) * (r);
					})
					.style("font-size","11px")
					.text(function(d) {
						//return d.data.spent + ' - ' + d.data.allocatedbudget; 
					})
					.each(function(d) {
						var bbox = this.getBBox();
						d.sx1 = d.x - bbox.width/2 - 2;
						d.ox1 = d.x + bbox.width/2 + 2;
						d.sy1 = d.oy1 = d.y + 5;
					})
					.transition()
						.duration(300);

				
				labels
					.transition()
					.duration(300)

					
				methods.g.append("defs").append("marker")
						.attr("id", function(d,i){
							return 'circ'+i;
						})
						.attr("markerWidth", 6)
						.attr("markerHeight", 6)
						.attr("refX", 3)
						.attr("refY", 3)
						.append("circle")
						.attr("fill", '#ababab')
						.attr("stroke", "#ababab")
						.attr("opacity", 1)
						.attr("cx", 3)
						.attr("cy", 3)
						.attr("r", 2);
								
				var pointers = methods.g.append("path")
						.attr("class", "pointer")
						.style("fill", "none")
						.style("stroke", "#ababab")
						.attr("stroke", "#ababab")
						.attr("opacity", 1)
						.attr("marker-end", function(d,i){
							//return "url(#circ"+i+")";
						});

					pointers
						.attr("d", function(d) {
							if(d.cx > d.ox) {
								//alert('a');
								return "M" + ( -((methods.settings.width-20)/2) ) + "," + d.sy + "L" + (d.ox) + "," + d.oy + " " + d.cx + "," + d.cy;
								
							} else {
								//alert('b');
								return "M" + ( ((methods.settings.width-20)/2) ) + "," + d.oy + "L" + d.sx + "," + d.sy + " " + d.cx + "," + d.cy;
							}
						})
						.transition()
						.duration(300)
							
					pointers
						.transition()
						.duration(300)
					
					//return false;

					
					methods.svg.selectAll(".room-names")
						.attr("fill", "red")
						.attr("stroke", "#000")
						.attr("x", function(d){ 
							var a = d.startAngle + (d.endAngle - d.startAngle)/2 - Math.PI/2;
							d.cx = Math.cos(a) * (ir+30+((r-ir)/2));

							if(d.cx > d.ox) {
								return d.x = - ( methods.settings.width / 2 ) + 20; 
							} else {
								return d.x = ( methods.settings.width / 2 ) - 20;
							}
						})			
				methods.placelabedivs();
		},
		outerlines: function() {
			
			methods.svg.append("svg:circle")
					.attr("r", methods.settings.radius + 40)
					.attr("class", "circle")
					.style("stroke", "#1BA7DA")
					.style("opacity", 1)
					.style("fill", "#CCC");
			

			methods.svg.append("svg:circle")
					.attr("r", methods.settings.radius + 50)
					.attr("class", "circle")
					.style("stroke", "#1BA7DA")
					.style("opacity", 0.5)
					.style("fill", "#fff");

			methods.svg.append("svg:circle")
					.attr("r", methods.settings.radius + 60)
					.attr("class", "circle")
					.style("stroke", "#1BA7DA")
					.style("opacity", 0.2)
					.style("fill", "#fff");


			methods.svg.append("svg:circle")
					.attr("r", methods.settings.radius + 70)
					.attr("class", "circle")
					.style("stroke", "#1BA7DA")
					.style("opacity", 0.1)
					.style("fill", "#fff");

			
		},
		placelabedivs: function(){
			methods.g.selectAll(".pointer")
				.each(function(dp){
					if(dp.cx > dp.ox) {
						
						methods.svg.append("svg:text")
							.style({"font-family" : "Arial", "font-size" : "11px", "font-weight" : "bold", "fill" : "#001e41", "cursor" : "pointer"})
							.on("click", function(){
								alert(dp.data.roomid)
									alert('ssdf');
							})
							.each(function(d) {
								var bbox = this.getBBox();
								return d.ax = bbox.width;
							})
							.text(function(d){
								return dp.data.room;
							})
							.attr("x", -( methods.settings.width / 2 ))
							.attr("y", dp.sy - 10)
							
							
						methods.svg.append("svg:text")
							.style({"font-family" : "Arial", "font-size" : "11px", "font-weight" : "bold", "fill" : "#001e41"})
							.each(function(d) {
								var bbox = this.getBBox();
								return d.ax = bbox.width;
							})
							.text(function(d){
								return 'Budget';
							})
							.attr("x", -( methods.settings.width / 2 ))
							.attr("y", dp.sy + 20)
						
						methods.svg.append("svg:text")
							.style({"font-family" : "Arial", "font-size" : "10px", "font-weight" : "bold", "fill" : "#001e41"})
							.each(function(d) {
								var bbox = this.getBBox();
								return d.abw = bbox.width;
							})
							.text(function(d){
								return "$"+toCurrency(dp.data.allocatedbudget);
							})
							.attr("x", -( methods.settings.width / 2 ))
							.attr("y", dp.sy + 40)
							
						
						methods.svg.append("svg:text")
							.style({"font-family" : "Arial", "font-size" : "11px", "font-weight" : "bold", "fill" : "#001e41"})
							.each(function(d) {
								var bbox = this.getBBox();
								return d.sw = bbox.width;
							})
							.text(function(d){
								return "Spent";
							})
							.attr("x", function(d){
								return -( methods.settings.width / 2 ) + 75;
							})
							.attr("y", dp.sy + 20)

						methods.svg.append("svg:text")
							.style({"font-family" : "Arial", "font-size" : "11px", "font-weight" : "bold", "fill" : "#001e41"})
							.each(function(d) {
								var bbox = this.getBBox();
								return d.abw = bbox.width;
							})
							.text(function(d){
								return "$"+toCurrency(dp.data.spent);
							})
							.attr("x", -( methods.settings.width / 2 ) + 75)
							.attr("y", dp.sy + 40)
							
						methods.svg.append("svg:text")
							.style({"font-family" : "Arial", "font-size" : "11px", "font-weight" : "bold"})
							.each(function(d) {
								var bbox = this.getBBox();
								return d.sw = bbox.width;
							})
							.text(function(d){
								return "Remaining";
							})
							.style("fill", function(d){
								var calcValue = (eval(dp.data.allocatedbudget) - eval(dp.data.spent) )
								if( calcValue < 0 ) {
									return "red";
								} else {
									return "#52BF7B";
								}
							})
							.attr("x", function(d){
								return -( methods.settings.width / 2 ) + 150;
							})
							.attr("y", dp.sy + 20)
						
						methods.svg.append("svg:text")
							.style({"font-family" : "Arial", "font-size" : "11px", "font-weight" : "bold"})
							.each(function(d) {
								var bbox = this.getBBox();
								return d.abw = bbox.width;
							})
							.text(function(d){
								var calcValue	=	toCurrency(eval(dp.data.allocatedbudget) - eval(dp.data.spent) );
								return ( calcValue < 0 ) ? ( '-$'+(-1 * calcValue) ) : '$'+calcValue;
							})
							.style("fill", function(d){
								var calcValue = (eval(dp.data.allocatedbudget) - eval(dp.data.spent) )
								if( calcValue < 0 ) {
									return "red";
								} else {
									return "#52BF7B";
								}
							})
							.attr("x", -( methods.settings.width / 2 ) + 150 )
							.attr("y", dp.sy + 40)

						methods.svg.append("circle")
						.attr("class", "legenddots")
						.attr("r", 5)
						.attr("cx", function(d){		
							return -( methods.settings.width / 2 ) + 5;
						})
						.attr("cy", dp.sy)
						.attr("fill", function(d){
							return methods.color(dp.data.spent);
						});
						
					} else {

						methods.svg.append("svg:text")							
							.style({"font-family" : "Arial", "font-size" : "11px", "font-weight" : "bold", "fill" : "#001e41", "cursor" : "pointer"})
							.on("click", function(){
								alert(dp.data.roomid)
							})
							.text(function(d){
								return dp.data.room;
							})
							.each(function(d) {
								var bbox = this.getBBox();
								return d.ax = bbox.width;
							})
							.attr("x", function(d){
								return ( methods.settings.width / 2 ) - d.ax;
							})
							.attr("y", dp.sy - 10)
						
						methods.svg.append("svg:text")
							.style({"font-family" : "Arial", "font-size" : "11px", "font-weight" : "bold", "fill" : "#001e41"})
							.each(function(d) {
								var bbox = this.getBBox();
								return d.ax = bbox.width;
							})
							.text(function(d){
								return 'Budget';
							})
							.attr("x", function(d){
								return ( methods.settings.width / 2 ) - (d.ax + 210);
							})
							.attr("y", dp.sy + 20)
						
						methods.svg.append("svg:text")
							.style({"font-family" : "Arial", "font-size" : "11px", "font-weight" : "bold", "fill" : "#001e41"})
							.each(function(d) {
								var bbox = this.getBBox();
								return d.abw = bbox.width;
							})
							.text(function(d){
								return "$"+toCurrency(dp.data.allocatedbudget);
							})
							.attr("x", function(d){
								return ( methods.settings.width / 2 ) - (d.ax + 210)
							})
							.attr("y", dp.sy + 40)
								
						methods.svg.append("svg:text")
							.style({"font-family" : "Arial", "font-size" : "11px", "font-weight" : "bold", "fill" : "#001e41"})
							.each(function(d) {
								var bbox = this.getBBox();
								return d.ax = bbox.width;
							})
							.text(function(d){
								return 'Spent';
							})
							.attr("x", function(d){
								return ( methods.settings.width / 2 ) - (d.ax + 135);
							})
							.attr("y", dp.sy + 20)
						
						methods.svg.append("svg:text")
							.style({"font-family" : "Arial", "font-size" : "11px", "font-weight" : "bold", "fill" : "#001e41"})
							.each(function(d) {
								var bbox = this.getBBox();
								return d.abw = bbox.width;
							})
							.text(function(d){
								return "$"+toCurrency(dp.data.spent);
							})
							.attr("x", function(d){
								return ( methods.settings.width / 2 ) - (d.ax + 135)
							})
							.attr("y", dp.sy + 40)

						methods.svg.append("svg:text")
							.style({"font-family" : "Arial", "font-size" : "11px", "font-weight" : "bold"})
							.each(function(d) {
								var bbox = this.getBBox();
								return d.sw = bbox.width;
							})
							.text(function(d){
								return "Remaining";
							})
							.style("fill", function(d){
								var calcValue = (eval(dp.data.allocatedbudget) - eval(dp.data.spent) )
								if( calcValue < 0 ) {
									return "red";
								} else {
									return "#52BF7B";
								}
							})
							.attr("x", function(d){
								return ( methods.settings.width / 2 ) - (d.ax + 70);
							})
							.attr("y", dp.sy + 20)
						
						methods.svg.append("svg:text")
							.style({"font-family" : "Arial", "font-size" : "11px", "font-weight" : "bold"})
							.each(function(d) {
								var bbox = this.getBBox();
								return d.abw = bbox.width;
							})
							.text(function(d){
								var calcValue	=	toCurrency(eval(dp.data.allocatedbudget) - eval(dp.data.spent) );
								return ( calcValue < 0 ) ? ( '-$'+(-1 * calcValue) ) : '$'+calcValue;
							})
							.style("fill", function(d){
								var calcValue = (eval(dp.data.allocatedbudget) - eval(dp.data.spent) )
								if( calcValue < 0 ) {
									return "red";
								} else {
									return "#52BF7B";
								}
							})
							.attr("x", function(d){
								return  ( methods.settings.width / 2 ) - (d.ax + 70)
							})
							.attr("y", dp.sy + 40)



						methods.svg.append("circle")
						.attr("class", "legenddots")
						.attr("r", 5)
						.attr("cx", function(d){
							return ( methods.settings.width / 2 ) - 10;
						})
						.attr("cy", dp.sy)
						.attr("fill", function(d){
							return methods.color(dp.data.spent);
						});
					}
				});	
			methods.colorDots();
		},
		colorDots: function(){
			
		}
	};

	$.fn.ampchart = function(methodOrOptions) {
		if ( methods[methodOrOptions] ) {
			return methods[ methodOrOptions ].apply( this, Array.prototype.slice.call( arguments, 1 ));
		} else if ( typeof methodOrOptions === 'object' || ! methodOrOptions ) {
			// Default to "init"
			return methods.init.apply( this, arguments );
		} else {
			$.error( 'Method ' +  methodOrOptions + ' does not exist' );
		}    
	};
})(jQuery);



$(document).ready(function(){
	$(".chart").ampchart({ width: 860, height: 600 });
})