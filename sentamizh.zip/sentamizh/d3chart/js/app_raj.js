function toCurrency(amount){
	return amount.toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,");
}
var WaitDuration = 0;
(function( $ ){
	var methods	=	{
		self: "",
		settings: "",
		data: "",
		init: function(options) {
			alert('1');
			methods.settings = $.extend({
				width: 200,
				height: 300,
				radius: 0,
				innerradius: 20,
				circs: 1
			}, options );			

			methods.self	=	this;
			methods.settings.radius	=	Math.min(methods.settings.width, methods.settings.height) / 2 - 150;
			methods.setup();
		},
		getArc: function(radius, innerradius){
			var arc = d3.svg.arc()
				.innerRadius(innerradius)
				.outerRadius(radius);
			alert('2');
			return arc;
		},
		setup: function() {
			alert('3');
			d3.csv("data/data.csv", function(error, data) {
				
				methods.data	=	data;
				var totalab	=	0, totals = 0;
				

				data.forEach(function(d){
					totalab	+=	eval(d.allocatedbudget);
					totals	+=	eval(d.spent);
				})

				methods.allocatedbudgettotal = toCurrency(totalab);
				
				var xr	=	( totals / totalab ) * methods.settings.radius;	

				var max = d3.max(data, function(d){ return eval(d.allocatedbudget); });
				var min = d3.min(data, function(d){ return eval(d.allocatedbudget); });

				var max1 = d3.max(data, function(d){ return eval(d.spent); });
				var min1 = d3.min(data, function(d){ return eval(d.spent); });

				var newmax	=	200;
				var newmin	=	0;

				var linearScale = d3.scale.linear()
					.domain([min1, max1])
					.range([100, 230])

				/*Auto range of colors*/
				methods.color		=	d3.scale.category20c();

				//Manual range of colors
				/*methods.color		=	d3.scale.ordinal()
					.range(["#001D42", "#1478A5", "#1BA7DA", "#646464", "#97999B", "#B7B7B7", "#CBCBCB"]);*/
				
				methods.pie = d3.layout.pie()
					.sort(null)
					.value(function(d) {
					return d.allocatedbudget;});
				
				methods.arc = d3.svg.arc()
					.outerRadius(0)
					.innerRadius(40);

				methods.arcOver = d3.svg.arc()
					.outerRadius(function(d, i){
							if(d.data.spent != 0)
								var v2		=	40 + ( d.data.spent / d.data.allocatedbudget ) * methods.settings.radius;
							else
								var v2 = 150;

							if( eval(v2) > 250 ) {
								v2 = 250;
							}
							return v2;
					})
					.innerRadius(40);
				
				methods.svg = d3.select("#chart").append("svg")
					.attr({ "width" : methods.settings.width, "height" : methods.settings.height })
					.append("g")
					.attr("transform", "translate(" + methods.settings.width / 2 + "," + methods.settings.height / 2 + ")");				

				methods.labels = methods.svg.append("g")
					.attr("class", "labels");

				methods.pointers = methods.svg.append("g")
					.attr("class", "pointers");


				alert('inside');
				methods.outerlines();
				methods.text();

				//methods.update();

				if (methods.update()){
					
					methods.colorDots();
					alert("not here");
					alert("WD:"+WaitDuration);
				}

				
				
			})
		},
		outerlines: function() {
			
			methods.svg.append("svg:circle")
					.attr("r", methods.settings.radius + 40)
					.attr("class", "circle")
					.style("stroke", "#1BA7DA")
					.style("opacity", 1)
					.style("fill", "#fff");

			methods.svg.append("svg:circle")
					.attr("r", methods.settings.radius + 50)
					.attr("class", "circle")
					.style("stroke", "#1BA7DA")
					.style("opacity", 0.5)
					.style("fill", "#fff");

			methods.svg.append("svg:circle")
					.attr("r", methods.settings.radius + 60)
					.attr("class", "circle")
					.style("stroke", "#1BA7DA")
					.style("opacity", 0.2)
					.style("fill", "#fff");

			methods.svg.append("svg:circle")
					.attr("r", methods.settings.radius + 70)
					.attr("class", "circle")
					.style("stroke", "#1BA7DA")
					.style("opacity", 0.1)
					.style("fill", "#fff");
			
		},
		update: function(dataSet){

			var path = methods.g.append("path")
				 .attr("d", methods.arc)
				 .style("cursor", function(d) { 
						if(d.data.room != 'Remaining') return 'pointer';
						return 'default';
					})
				 .style("fill", function(d, i) { 
						if (d.data.room == 'Remaining')
						{
							return '#EEE';
						}
						else if(d.data.spent == 0) 
						{
							return '#CCC';
						}
						else 
						{
							return methods.color(d.data.spent); 
						}
					})
				 .on("click", function(d){
					if(d.data.room == 'Remaining')
					{
						return false;
					}
					else
					{
						var redirectUrl = '/projects/items/'+d.data.projectid+'/'+d.data.roomid+'/';
						location.href = redirectUrl;
					}
				 })
				.on("mouseover", function(d){
					//console.log(this);
				 })

				.transition().delay(function(d, i, j) {
						return i * 800; 
				 }).duration(00)
				.attrTween('d', function(d,x,y) {

					d3.select(this).transition()
						.duration(00)
						.attr("d", methods.arcOver);
						WaitDuration = WaitDuration + 900;

				});
				
				

			var dummycenter = methods.svg.append("circle")
				.attr("r", methods.settings.radius / 2.4)
				.attr("fill", "#FFF")
				.attr("fill-opacity", 0.5);

			methods.svg.append("svg:text")
				.style({"font-family" : "Arial", "font-size" : "17px", "font-weight" : "bold", "fill" : "#001e41", "cursor" : "pointer", "fill-opacity" : 1})	
				.text(function(){
					return '$'+methods.allocatedbudgettotal;
				})
				.each(function(d){
					var bbox	=	this.getBBox();
					d.ah		=	bbox.height;
					return d.aw =	bbox.width;
				})
				.attr("x", function(d){
					return - (d.aw / 2)
				})
				.attr("y", function(d){
					return (d.ah / 2)
				})
				return 1;
		},
		text: function() {
			
				methods.g = methods.svg.datum(methods.data).selectAll(".arc")
				.data(methods.pie)
				.enter().append("g")
				.attr("class", "arc");

			var labels = methods.g.append("text").attr("text-anchor", "middle");
			var ir = 60, r = methods.settings.radius;

			labels
					.attr("x", function(d) {
						var a = d.startAngle + (d.endAngle - d.startAngle)/2 - Math.PI/2;
						d.cx = Math.cos(a) * (ir+((r-ir)/2));
						return d.x = Math.cos(a) * (r + 40);
					})
					.attr("y", function(d) {
						var a = d.startAngle + (d.endAngle - d.startAngle)/2 - Math.PI/2;
						d.cy = Math.sin(a) * (ir+((r-ir)/2));
						return d.y = Math.sin(a) * (r + 40);
					})
					.style("font-size","12px")
					.text(function(d) {
					})
					.on("click", function(d){
					})
					.attr("class", "room-names")
					.style("cursor", "pointer")
					.each(function(d) {
						var bbox = this.getBBox();
						d.sx = d.x - bbox.width/2 - 2;
						d.ox = d.x + bbox.width/2 + 2;
						d.sy = d.oy = d.y + 5;
					})
					.transition()
						.duration(300);

				var labelValues	=	methods.g.append("text").attr("text-anchor", "middle");
				labelValues
					.attr("x", function(d) {
						var a = d.startAngle + (d.endAngle - d.startAngle)/2 - Math.PI/2;
						d.cx = Math.cos(a) * (ir+30+((r-ir)/2));
						if(d.cx > d.ox) {
							return d.x = - 300;
						} else {
							return d.x = ( methods.settings.width / 2 ) - 50;
						}
						
					})
					.attr("y", function(d) {
						var a = d.startAngle + (d.endAngle - d.startAngle)/2 - Math.PI/2;
						d.cy = Math.sin(a) * (ir+30+((r-ir)/2));
						return d.y = Math.sin(a) * (r);
					})
					.style("font-size","11px")
					.text(function(d) {
						//return d.data.spent + ' - ' + d.data.allocatedbudget; 
					})
					.each(function(d) {
						var bbox = this.getBBox();
						d.sx1 = d.x - bbox.width/2 - 2;
						d.ox1 = d.x + bbox.width/2 + 2;
						d.sy1 = d.oy1 = d.y + 5;
					})
					.transition()
						.duration(300);
				
				labels
					.transition()
					.duration(300)
					
				methods.g.append("defs").append("marker")
						.attr("id", function(d,i){
							return 'circ'+i;
						})
						.attr("markerWidth", 6)
						.attr("markerHeight", 6)
						.attr("refX", 3)
						.attr("refY", 3)
						.append("circle")
						.attr("fill", '#ababab')
						.attr("stroke", "#ababab")
						.attr("opacity", 1)
						.attr("cx", 3)
						.attr("cy", 3)
						.attr("r", 2);
				//return false;

				
				methods.addpointers();
				methods.placelabedivs();
				
				
		},
		addpointers: function() {
			
			var lastUsedRHSOY = "", lastUsedLHSOY = "", rhsSX = "";
			var pointers = methods.g.append("path")
						.attr("class", "pointer")
						.style("fill", "none")
						.style("stroke", "#ababab")
						.attr("opacity", 1)
						.attr("id", function(d,i){
							return 'pointer'+i;
						})
						
						.attr("marker-end", function(d,i){
							return "url(#circ"+i+")";
						});

					pointers
						.attr("d", function(d) {
							
							var rhsOY = "", lhsOY = "";
							/*Newly added code to avoid overlap*/
								if(lastUsedRHSOY !=  "") 
								{						
									if (Math.abs(Math.abs(lastUsedRHSOY) - Math.abs(d.oy)) < 75)
									{
										rhsOY = lastUsedRHSOY + 75;
										d.sx = d.sx + 75;
									}
								}
								/*if(lastUsedLHSOY !=  "") 
								{						
									if (Math.abs(Math.abs(lastUsedLHSOY) - Math.abs(d.oy)) < 75)
									{
										lhsOY = lastUsedLHSOY + 75;
										d.sx = d.sx + 75;
									}
								}*/


							/*Newly added code to avoid overlap*/

							if(d.cx > d.ox) {
								/*LHS pointer*/
								//alert('a');
								return "M" + ( -((methods.settings.width-20)/2) ) + "," + d.sy + "L" + (d.ox) + "," + d.oy + " " + d.cx + "," + d.cy;
							} else {
								/*RHS pointer*/
								//return "M" + ( ((methods.settings.width-20)/2) ) + "," + d.oy + "L" + d.sx + "," + d.sy + " " + d.cx + "," + d.cy;
								if( rhsOY != "") 
								{
									d.oy = rhsOY;
									d.sy = d.oy;
								}
								lastUsedRHSOY = d.oy;
								//alert('b');
								return "M" + ( ((methods.settings.width-20)/2) ) + "," + d.oy + "L" + d.sx + "," + d.sy + " " + d.cx + "," + d.cy;
							}
							
						})
						.transition()
						.duration(300);
			
		},
		placelabedivs: function(){
			var lastUsedRHSDPSY = "", lastUsedLHSDPSY = "";
			methods.g.selectAll(".pointer")
				.each(function(dp){
					/*LHS contnet write*/

					if(dp.cx > dp.ox) 
					{
						if(dp.data.room == "Remaining")
						{
							methods.svg.append("svg:text")
								.style({"font-family" : "Arial", "font-size" : "11px", "font-weight" : "bold", "fill" : "#001e41"})
								
								.each(function(d) {
									var bbox = this.getBBox();
									return d.ax = bbox.width;
								})
								.text(function(d){
									return dp.data.room+" - $"+toCurrency(dp.data.allocatedbudget);
								})
								.attr("x", -( methods.settings.width / 2 ))
								.attr("y", dp.sy - 10)

							/*methods.svg.append("circle")
								.attr("class", "legenddots")
								.attr("r", 5)
								.attr("cx", function(d){		
									return -( methods.settings.width / 2 ) + 5;
								})
								.attr("cy", dp.sy)
								.attr("fill", function(d){
									return '#CCC';
								});*/
						}
						else
						{
							/*Newly added code to avoid overlap issue*/
							/*if(lastUsedLHSDPSY !=  "") 
							{						
									//alert('Last Used'+Math.abs(lastUsedLHSDPSY)+'Current'+Math.abs(dp.sy));

									if (Math.abs(Math.abs(lastUsedLHSDPSY) - Math.abs(dp.sy)) < 75)
									{
										dp.sy = lastUsedLHSDPSY + 75;
									}
							}*/
							/*Newly added code to avoid overlap issue*/

							/*Room Name*/
							methods.svg.append("svg:text")
								.style({"font-family" : "Arial", "font-size" : "11px", "font-weight" : "bold", "fill" : "#001e41", "cursor" : "pointer"})
								.on("click", function(){
									var redirectUrl = '/projects/items/'+dp.data.projectid+'/'+dp.data.roomid+'/';
									location.href = redirectUrl;
								})
								.each(function(d) {
									var bbox = this.getBBox();
									return d.ax = bbox.width;
								})
								.text(function(d){
									return dp.data.room;
								})
								.attr("x", -( methods.settings.width / 2 ))
								.attr("y", dp.sy - 10)
							/*Room Name*/

							/*Budget*/
							methods.svg.append("svg:text")
								.style({"font-family" : "Arial", "font-size" : "11px", "font-weight" : "bold", "fill" : "#001e41"})
								.each(function(d) {
									var bbox = this.getBBox();
									return d.ax = bbox.width;
								})
								.text(function(d){
									return 'Budget';
								})
								.attr("x", -( methods.settings.width / 2 ))
								.attr("y", dp.sy + 20)
							
							methods.svg.append("svg:text")
								.style({"font-family" : "Arial", "font-size" : "10px", "font-weight" : "bold", "fill" : "#001e41"})
								.each(function(d) {
									var bbox = this.getBBox();
									return d.abw = bbox.width;
								})
								.text(function(d){
									return "$"+toCurrency(dp.data.allocatedbudget);
								})
								.attr("x", -( methods.settings.width / 2 ))
								.attr("y", dp.sy + 40)
							/*Budget*/
							
							/*Spent*/
							methods.svg.append("svg:text")
								.style({"font-family" : "Arial", "font-size" : "11px", "font-weight" : "bold", "fill" : "#001e41"})
								.each(function(d) {
									var bbox = this.getBBox();
									return d.sw = bbox.width;
								})
								.text(function(d){
									return "Spent";
								})
								.attr("x", function(d){
									return -( methods.settings.width / 2 ) + 75;
								})
								.attr("y", dp.sy + 20)

							methods.svg.append("svg:text")
								.style({"font-family" : "Arial", "font-size" : "10px", "font-weight" : "bold", "fill" : "#001e41"})
								.each(function(d) {
									var bbox = this.getBBox();
									return d.abw = bbox.width;
								})
								.text(function(d){
									return "$"+toCurrency(dp.data.spent);
								})
								.attr("x", -( methods.settings.width / 2 ) + 75)
								.attr("y", dp.sy + 40)
							/*Spent*/

							/*Remaining*/
							methods.svg.append("svg:text")
								.style({"font-family" : "Arial", "font-size" : "11px", "font-weight" : "bold"})
								.each(function(d) {
									var bbox = this.getBBox();
									return d.sw = bbox.width;
								})
								.text(function(d){
									return "Remaining";
								})
								.style("fill", function(d){
									var calcValue = (eval(dp.data.allocatedbudget) - eval(dp.data.spent) )
									if( calcValue < 0 ) {
										return "red";
									} else {
										return "#52BF7B";
									}
								})
								.attr("x", function(d){
									return -( methods.settings.width / 2 ) + 150;
								})
								.attr("y", dp.sy + 20)
							
							methods.svg.append("svg:text")
								.style({"font-family" : "Arial", "font-size" : "10px", "font-weight" : "bold"})
								.each(function(d) {
									var bbox = this.getBBox();
									return d.abw = bbox.width;
								})
								.text(function(d){
									var calcValue	=	toCurrency(eval(dp.data.allocatedbudget) - eval(dp.data.spent) );
									return ( calcValue < 0 ) ? ( '-$'+(-1 * calcValue) ) : '$'+calcValue;
								})
								.style("fill", function(d){
									var calcValue = (eval(dp.data.allocatedbudget) - eval(dp.data.spent) )
									if( calcValue < 0 ) {
										return "red";
									} else {
										return "#52BF7B";
									}
								})
								.attr("x", -( methods.settings.width / 2 ) + 150 )
								.attr("y", dp.sy + 40)
							/*Remaining*/
							
							/*Legend Dot*/
							methods.svg.append("circle")
								.attr("class", "legenddots")
								.attr("r", 5)
								.attr("cx", function(d){		
									return -( methods.settings.width / 2 ) + 5;
								})
								.attr("cy", dp.sy)
								.attr("fill", function(d){
									return methods.color(dp.data.spent);
								});
							/*Legend Dot*/
							lastUsedLHSDPSY = dp.sy;
						}
					}
					else
					{
						/*RHS contnet write*/
						//alert('RHS content write');
						if(dp.data.room == "Remaining")
						{
							
							methods.svg.append("svg:text")
								.style({"font-family" : "Arial", "font-size" : "11px", "font-weight" : "bold", "fill" : "#001e41"})
								.text(function(d){
									return dp.data.room+" - $"+toCurrency(dp.data.allocatedbudget);
								})
								.each(function(d) {
									var bbox = this.getBBox();
									return d.ax = bbox.width;
								})
								.attr("x", function(d){
									return ( methods.settings.width / 2 ) - d.ax;
								})
								.attr("y", dp.sy - 10)


							/*methods.svg.append("circle")
								.attr("class", "legenddots")
								.attr("r", 5)
								.attr("cx", function(d){
									return -( methods.settings.width / 2 ) + 5;
								})
								.attr("cy", dp.sy)
								.attr("fill", function(d){
									return '#CCC';
								});*/
						}
						else
						{
							/*Newly added code to avoid overlap issue*/
							if(lastUsedRHSDPSY !=  "") 
							{
									if (Math.abs(Math.abs(lastUsedRHSDPSY) - Math.abs(dp.sy)) < 75)
									{
										dp.sy = lastUsedRHSDPSY + 75;
										console.log('RHS'+dp.sy);
									}
							}
							/*Newly added code to avoid overlap issue*/

							/*Room Name*/
							methods.svg.append("svg:text")
								.style({"font-family" : "Arial", "font-size" : "11px", "font-weight" : "bold", "fill" : "#001e41", "cursor" : "pointer"})
								.on("click", function(){
									var redirectUrl = '/projects/items/'+dp.data.projectid+'/'+dp.data.roomid+'/';
									location.href = redirectUrl;
								})
								.text(function(d){
									return dp.data.room;
								})
								.each(function(d) {
									var bbox = this.getBBox();
									return d.ax = bbox.width;
								})
								.attr("x", function(d){
									return ( methods.settings.width / 2 ) - d.ax;
								})
								.attr("y", dp.sy - 10)
							/*Room Name*/

							/*Budget*/
							methods.svg.append("svg:text")
								.style({"font-family" : "Arial", "font-size" : "11px", "font-weight" : "bold", "fill" : "#001e41"})
								.each(function(d) {
									var bbox = this.getBBox();
									return d.ax = bbox.width;
								})
								.text(function(d){
									return 'Budget';
								})
								.attr("x", function(d){
									return ( methods.settings.width / 2 ) - (d.ax + 210);
								})
								.attr("y", dp.sy + 20)
							
							methods.svg.append("svg:text")
								.style({"font-family" : "Arial", "font-size" : "10px", "font-weight" : "bold", "fill" : "#001e41"})
								.each(function(d) {
									var bbox = this.getBBox();
									return d.abw = bbox.width;
								})
								.text(function(d){
									return "$"+toCurrency(dp.data.allocatedbudget);
								})
								.attr("x", function(d){
									return ( methods.settings.width / 2 ) - (d.ax + 210)
								})
								.attr("y", dp.sy + 40)

							/*Budget*/

							/*Spent*/
							methods.svg.append("svg:text")
								.style({"font-family" : "Arial", "font-size" : "11px", "font-weight" : "bold", "fill" : "#001e41"})
								.each(function(d) {
									var bbox = this.getBBox();
									return d.ax = bbox.width;
								})
								.text(function(d){
									return 'Spent';
								})
								.attr("x", function(d){
									return ( methods.settings.width / 2 ) - (d.ax + 135);
								})
								.attr("y", dp.sy + 20)
							
							methods.svg.append("svg:text")
								.style({"font-family" : "Arial", "font-size" : "10px", "font-weight" : "bold", "fill" : "#001e41"})
								.each(function(d) {
									var bbox = this.getBBox();
									return d.abw = bbox.width;
								})
								.text(function(d){
									return "$"+toCurrency(dp.data.spent);
								})
								.attr("x", function(d){
									return ( methods.settings.width / 2 ) - (d.ax + 135)
								})
								.attr("y", dp.sy + 40)
							/*Spent*/

							/*Remaining*/
							methods.svg.append("svg:text")
								.style({"font-family" : "Arial", "font-size" : "11px", "font-weight" : "bold"})
								.each(function(d) {
									var bbox = this.getBBox();
									return d.sw = bbox.width;
								})
								.text(function(d){
									return "Remaining";
								})
								.style("fill", function(d){
									var calcValue = (eval(dp.data.allocatedbudget) - eval(dp.data.spent) )
									if( calcValue < 0 ) {
										return "red";
									} else {
										return "#52BF7B";
									}
								})
								.attr("x", function(d){
									return ( methods.settings.width / 2 ) - (d.ax + 70);
								})
								.attr("y", dp.sy + 20)
							
							methods.svg.append("svg:text")
								.style({"font-family" : "Arial", "font-size" : "10px", "font-weight" : "bold"})
								.each(function(d) {
									var bbox = this.getBBox();
									return d.abw = bbox.width;
								})
								.text(function(d){
									var calcValue	=	toCurrency(eval(dp.data.allocatedbudget) - eval(dp.data.spent) );
									return ( calcValue < 0 ) ? ( '-$'+(-1 * calcValue) ) : '$'+calcValue;
								})
								.style("fill", function(d){
									var calcValue = (eval(dp.data.allocatedbudget) - eval(dp.data.spent) )
									if( calcValue < 0 ) {
										return "red";
									} else {
										return "#52BF7B";
									}
								})
								.attr("x", function(d){
									return  ( methods.settings.width / 2 ) - (d.ax + 70)
								})
								.attr("y", dp.sy + 40)
							/*Remaining*/

							/*Legend dot*/
							methods.svg.append("circle")
								.attr("class", "legenddots")
								.attr("r", 5)
								.attr("cx", function(d){
									return ( methods.settings.width / 2 ) - 10;
								})
								.attr("cy", dp.sy)
								.attr("fill", function(d){
									return methods.color(dp.data.spent);
								});
							/*Legend dot*/
							lastUsedRHSDPSY = dp.sy;
						}
					}
				});	
			methods.colorDots();
		},
		colorDots: function(){
			alert('last?');
		}
	};

	$.fn.ampchart = function(methodOrOptions) {
		if ( methods[methodOrOptions] ) {
			return methods[ methodOrOptions ].apply( this, Array.prototype.slice.call( arguments, 1 ));
		} else if ( typeof methodOrOptions === 'object' || ! methodOrOptions ) {
			// Default to "init"
			return methods.init.apply( this, arguments );
		} else {
			$.error( 'Method ' +  methodOrOptions + ' does not exist' );
		}    
	};
})(jQuery);



$(document).ready(function(){
	var w = (screen.width < 780 ) ? 650 : 860;
	$(".chart").ampchart({ width: w, height: 520 });
})