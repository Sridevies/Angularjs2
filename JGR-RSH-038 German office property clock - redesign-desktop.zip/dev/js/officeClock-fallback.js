var jQuery110 = $.noConflict();
jQuery110('.main-chart-container').html('<img src="../img/officeClock-fallback.png"><div class="fallback">Unfortunately your browser does not support this visualization. It requires a browser with SVG support, such as <a href="https://www.google.com/intl/en/chrome/browser/">Chrome</a>, <a href="http://www.mozilla.org/en-US/">Firefox</a>, <a href="http://support.apple.com/downloads/#safari">Safari</a> or the latest <a href="http://windows.microsoft.com/en-gb/internet-explorer/ie-9-worldwide-languages">Internet Explorer 9</a>.</div>');
jQuery110('.main-chart-container').css({
  'border': 'none',
  'background': 'none'
});