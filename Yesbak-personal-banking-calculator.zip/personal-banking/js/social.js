
/*Facebook Script start*/
$(function(){
	// Calling our plugin with a page id and an access token
	// that you will need to generate as explained in the tutorial:
	$('#wall').facebookWall({
		id:'172334649487460',
		access_token:'193673707489176|CSya6L7Q081Uw6OrFfI14AsmfSA'
	});
 
});
/*Facebook Script end*/

/*Tweeter Script start*/
$('#tweecool').tweecool({
username : 'yesbank'
});

/*Tweeter Script end*/

/*Youtube Script start*/
function goClicked() {
	$('#youmax').empty().append(' loading ...');
	
	$('#youmax').youmax({
		apiKey:'AIzaSyDEm5wGLsWi2G3WG40re-DAJcWioQSpJ6o',
		youTubeChannelURL:$('#youTubeChannelUrl').val(),
		
		youTubePlaylistURL:$('#youTubePlaylistUrl').val(),
		youmaxDefaultTab:"UPLOADS",
		youmaxColumns:3,
		showVideoInLightbox:false,
		maxResults:15,
		
	});

	//youTubeChannelURL=$('#youTubeChannelUrl').val();
	//youTubePlaylistURL=$('#youTubePlaylistUrl').val();
}

$('#youmax').youmax({
	apiKey:'AIzaSyDEm5wGLsWi2G3WG40re-DAJcWioQSpJ6o',
	youTubeChannelURL:"https://www.youtube.com/user/yesbank",
	
	youTubePlaylistURL:"https://www.youtube.com/user/yesbank/playlists",
	youmaxDefaultTab:"UPLOADS",
	youmaxColumns:3,
	showVideoInLightbox:false,
	maxResults:15,
	
});

/*Youtube Script end*/