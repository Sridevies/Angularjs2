var baseOffset, thisOffset, masterBottom, afterScroll, winhgt, minusheight, masterHeight, thisText, deviceAnim, reinitWidth;
var plantHeight = 0;
var topScroll = true;
var winWidth = $(window).width();

function initMilestone(isReinit){
	reinitWidth = $(window).width();
	if(isReinit==true){
		if(reinitWidth > 1024){
			$(".keyMilestone").removeAttr("style").find(".master").removeClass("absolute").removeClass("animate");
			$(".historyMaster").removeAttr("style");
		}
		$(".breadcrumb").removeClass("abs");
		$(".keyMilestone").removeAttr("style").find(".master").removeClass("absolute animate")
		$(".keyMilestone").removeAttr("style").find(".master").removeAttr("style");
	}



	$(".breadcrumb").addClass("abs");
	winhgt = $(window).height();
	minusheight = $("header").outerHeight(true)+$(".breadcrumb").outerHeight()+50;
	masterHeight = $(".keyMilestone").outerHeight()+"px";
	$(".keyMilestone").css({"height":winhgt - minusheight}).find(".master").addClass("absolute").height(masterHeight);

	baseOffset = $(".keyMilestone").offset().top;
	$(".keyMilestone .master").addClass("animate");

	$(".keyMilestone .history > h2").each(function(){
		thisOffset = $(this).next("img").length ? $(this).next("img").offset().top : $(this).offset().top;
		masterBottom = thisOffset - baseOffset;
		masterBottom = masterBottom > 0 ? 0 : masterBottom;
		$(this).attr("data-visible-position",masterBottom);
	}).promise().done(function(){
		if(isReinit==true && reinitWidth > 1024){
			$(".years li.current a").trigger("click",["reInit"]); // isLimited to ReInit
		}
	});

	

	if(isReinit==true){
		if(reinitWidth > 1024){
			$(window).scrollTop(0);
		}else{
			var cYear = $(".years li.current").length == 0 ? "2003" : thisText;
			var genScroll =$(".keyMilestone .master h2[data-scroll='"+cYear+"']").offset().top - 100;
			$(window).scrollTop(genScroll);
		}
	}


}

//Event
function milestoneScroller(e,touchDirection){

	if($(window).width() > 1024){

		e.preventDefault();
		e.returnValue=false;
		clearTimeout(afterScroll);

		if(e.type=="touchend"){
			var eventHandler  = touchDirection;
		}else if(e.type=="mousewheel" || e.type=="DOMMouseScroll"){
			var eventHandler  = MouseWheelHandler(e) == 1 ? "up" : "down";
		}
	 	

	 	if($(window).scrollTop() == 0){
	 		topScroll = true;
	 	}else if($(window).scrollTop() == $(document).height() - $(window).height()){
	 		topScroll = false;
	 	}

	 	afterScroll = setTimeout(function(){
	 		if(eventHandler=="up"){
	 			if(topScroll == false){
	 				$("html,body").animate({scrollTop: 0},1000);
	 				return false;
	 			}

	 			if($(".years li.current").prev().length){
	 				$(".years li.current").prev().find("a").click();
	 			}
	 		}else{
	 			
	 			if($(".years li.current").next().length){
	 				$(".years li.current").next().find("a").click();
	 			}else{
	 				$("html,body").animate({scrollTop: $(document).height() - $(window).height()},1000)
	 			}
	 		}
	 	},100);

	 	return false;

 	}

}
$(window).resize(function(){
	$(".history, .master").addClass("noTransition");
});

$(window).on("resizeEnd",function(){
	//console.log("resizeEnd");
	if(winWidth  != $(window).width()){
		initMilestone(true);
		winWidth = $(window).width();
	}
	$(".history, .master").removeClass("noTransition");
});

$(window).load(function(){

	/* Key Milestone Start */

	if($("#keyMilestone").length){
		plant = $(".keyMilestone .master .plant");
		/* Mousewheel Start */
		var scrollDiv = document.getElementById("keyMilestone");
		if (scrollDiv.addEventListener) {
			scrollDiv.addEventListener("mousewheel", milestoneScroller, false); // IE9, Chrome, Safari, Opera
			scrollDiv.addEventListener("DOMMouseScroll", milestoneScroller, false); // Firefox
		}
		else{
			scrollDiv.attachEvent("onmousewheel", milestoneScroller); // IE 6/7/8
		}
		/* Mousewheel End */

		/*$("#keyMilestone").swipe( {
		    //Generic swipe handler for all directions
		    swipe:function(event, direction, distance, duration, fingerCount, fingerData) {
				if(direction=="up")  {
					milestoneScroller(event,"down");
				}else if(direction=="down")  {
					milestoneScroller(event,"up");
				}
		    }
		 });*/

		initMilestone();

		/* Scroll Calculation .. bottom of Master - Start */

		$(".historyMaster").hide();

		/* Scroll Calculation .. bottom of Master - End */

		var transitionsSupported = ('transition' in document.documentElement.style) || ('WebkitTransition' in document.documentElement.style);
		var plantTop = plant.find(".top");
		plantTop.css("height","299px");

		plantTop.find(".leaf").addClass("active");
		if($(".device").length){
			var timeout = 0;
		}else{
			var timeout = 4000;
		}
			setTimeout(function(){
				plantTop.addClass("active"); 
				plant.addClass("active");
				$(".historyMaster").fadeIn(1000,function(){
					$(".years li:last-child").find("a").click();
				});
				
			},timeout);

		$(".history > .text").animate({opacity:1},800);

		/* Year List - Start */

		var yearHeightForFirst = $(".years li").eq(0).height();
		var yearHeight = $(".years li").eq(1).outerHeight(true);
		var visibleItems = 6;
		$(".yearMaster .ov").height(yearHeight*visibleItems)
		var maxOffTop = $(".yearMaster .ov").offset().top;
		var maxOffBottom = maxOffTop + $(".yearMaster .ov").outerHeight(true);
		var yearLength = $(".years li").length;
		var slideCounter = visibleItems;
		var slideAmount = 0;

		//Event
		$(".years li a").click(function(event,limitedTo){

			if(limitedTo != "onlySlide"){

				$(this).parents("li").addClass("current").siblings().removeClass("current");
				thisText = $(this).text();


				//$(".keyMilestone .master .history.active").removeClass("active");
				var animateBottom = $(".keyMilestone .master .history h2[data-scroll='"+thisText+"']").attr("data-visible-position");

				if(limitedTo == "reInit"){
					thisText = plant.attr("data-height");
				}

				if(thisText=="Intro"){
					var historyOffset = parseInt($(".keyMilestone .master h2[data-scroll='"+thisText+"']").parents(".history").position().top + $(".keyMilestone .master h2[data-scroll='"+thisText+"']").parents(".history").height());
				}else{
					var historyOffset = parseInt($(".keyMilestone .master h2[data-scroll='"+thisText+"']").parents(".history").position().top);
				}


				plantHeight = $(window).width() > 1024 ? (parseInt($(".historyMaster").outerHeight()) - historyOffset) : plantHeight;
				
				if(transitionsSupported){

					if(parseInt(plant.attr("data-height")) <= parseInt(thisText) || thisText=="Intro"){
						plant.css("height",plantHeight+"px");

						if(parseInt(thisText) > parseInt(plant.attr("data-height")) || thisText=="Intro") {
							plant.attr("data-height",thisText);
						}
					}

					$(".keyMilestone .master").css("bottom",animateBottom+"px");

					

				}else{ 
					//IE9

					if(parseInt(plant.attr("data-height")) <= parseInt(thisText) || thisText=="Intro"){
						plant.stop(true,false).animate({"height":plantHeight+"px"},1000);

						if(parseInt(thisText) > parseInt(plant.attr("data-height")) || thisText=="Intro") {
							plant.attr("data-height",thisText);
						}
					}

					$(".keyMilestone .master").stop(true,false).delay(500).animate({"bottom":animateBottom+"px"},1000);
					//$(".plant")
				}

				setTimeout(function(){
					$(".keyMilestone .master h2:contains('"+thisText+"')").parents(".history").addClass("active").siblings().removeClass("active");
				},700)

			}

			var thisItem = parseInt($(this).parent().index())+1;
			var slideIndex = (yearLength-thisItem)-visibleItems+1;
			var slideAmount = slideIndex*yearHeight*-1;
			$(".years li").removeClass("visible");

			if(thisItem <= yearLength - visibleItems){
				$(".action").removeClass("disabled");
				$(".years li").eq(thisItem-1).addClass("visible");

				if($(".years li").eq(0).hasClass("visible")){
					slideAmount = slideAmount+parseInt($(".years li").eq(1).css("padding-top")); // padding of First LI is 0;
				}
				$(".years").stop(true,true).animate({"bottom":slideAmount},300);
				
			}else{
				$(".next").addClass("disabled");
				$(".years").stop(true,true).animate({"bottom":0},300);
				$(".years li").eq(yearLength-visibleItems).addClass("visible");
			}

			if($(this).text() == $(".years li").eq(0).text()){
				$(".prev").addClass("disabled");
			}
			
			if($(window).width() <= 1024){
				deviceAnim = setTimeout(function(){
					var genScroll =$(".keyMilestone .master h2[data-scroll='"+thisText+"']").offset().top - 100;
					$("html,body").animate({scrollTop:genScroll},800);
				},1000);
			}else{
				$(window).scrollTop(0);
			}



		});

		$(".history h2").click(function(){
			clearTimeout(deviceAnim);
			if($(window).width()<= 1024){
				 $(".years li a:contains('"+$(this).attr('data-scroll')+"')").click();
			}
		});
		


		/*$(".master").on('transitionend webkitTransitionEnd oTransitionEnd otransitionend MSTransitionEnd', function() {});*/

		

		$(".yearMaster .action").click(function(){
			if($(this).hasClass("disabled") || $(".years").is(":animated")){
				return false; // Disable Click
			}

			if($(this).hasClass("prev")){
				$(".years li.visible").first().prev().find("a").trigger("click",["onlySlide"]);
			}else if($(this).hasClass("next")){
				$(".years li.visible").first().next().find("a").trigger("click",["onlySlide"]);
			}

		});

		/* Year List - End */

	}
	/* Key Milestone End */

});