
/********** Start Create HTML 5 ELEMENT ********/
document.createElement("section");
document.createElement("header");
document.createElement("footer");
document.createElement("article");
document.createElement("aside");
document.createElement("nav");
/********** End Create HTML 5 ELEMENT ********/
var activeInd, _self, example4Ajax, newsurl, pageTitle, minHeight;
var arrayHeight=[];
var activeArticle, firePusestate, visibleDoc;
var _body = $("body");

(function () {
    $.fn.addPlaceholder = function (options) {
        var settings = $.extend({
            events: true,
            IE: true
        }, options);

        function detectIE() {
            var ua = window.navigator.userAgent;

            var msie = ua.indexOf('MSIE ');
            if (msie > 0) {
                // IE 10 or older => return version number
                return parseInt(ua.substring(msie + 5, ua.indexOf('.', msie)), 10);
            }

            var trident = ua.indexOf('Trident/');
            if (trident > 0) {
                // IE 11 => return version number
                var rv = ua.indexOf('rv:');
                return parseInt(ua.substring(rv + 3, ua.indexOf('.', rv)), 10);
            }

            var edge = ua.indexOf('Edge/');
            if (edge > 0) {
                // IE 12 => return version number
                return parseInt(ua.substring(edge + 5, ua.indexOf('.', edge)), 10);
            }

            // other browser
            return false;
        }

        if (detectIE()) {
            return this.each(function () {
                var a = $(this).attr("placeholder");
                $(this).attr("placeholder", "");
				//alert($(this).val());
				//if($(this).val()==""){
                	$(this).before("<div class='placeholder'>" + a + "</div>")
                	if($(this).val()!=""){
                		$(this).prev(".placeholder").hide()
                	}
				//}else{
					//$(this).before("<div class='placeholder displayNone'>" + a + "</div>")
				//}

                $(this).keydown(function () {
                    $(this).siblings(".placeholder").hide();
                });

                $(this).keyup(function () {
                    if ($(this).val() == "") {
                        $(this).siblings(".placeholder").show();
                    }
                });

                $(this).focus(function () {
                    if ($(this).val() == "") {
                        $(this).siblings(".placeholder").show();
                    } else {
                        $(this).siblings(".placeholder").hide();
                    }
                });

                $(this).blur(function () {
                    if ($(this).val() == "") {
                        $(this).siblings(".placeholder").show();
                    }
                    else {
                        $(this).siblings(".placeholder").hide();
                    }
                });
				


            });
        }
    }
	applyHeight();
	
	
	
})(jQuery);

function windowORdevice() {

    if ($(window).width() > 1024) {
        $("body").addClass("desktop").removeClass("device");
    }
    else {
        /*Device*/
        $("body").addClass("device").removeClass("desktop");
    }
}

function MouseWheelHandler(e) {
	// cross-browser wheel delta
	var e = window.event || e; // old IE support
	var delta = Math.max(-1, Math.min(1, (e.wheelDelta || -e.detail)));
	return delta
}

$(document).ready(function(){
	var leftcontH = $(window).height() - ($('header').height() +  $('.twoClrBand').height() + $('.fixedWrap').height() + 20);
	$('.leftContainer').css({'width':$('.leftContainer').width(), 'height':leftcontH});
	
/*PushState start*/
var URL_PATH = "/demos/history";
var first = true;

//History API feature detection
if (!(window.history && history.pushState)) {
	$(".history-message").fadeIn();
}

/* When we get a popstate event, lets log it onto the page */
var popstateLog = $("#popstateLog");

$(window).on("popstate", function(e) {
	//alert(123)
  handlePopstate(e);
});

var handlePopstate = function(e) {
  var time = new Date( e.originalEvent.timeStamp ).toLocaleTimeString();
  var path = window.location.href.replace(window.location.origin,"");
  popstateLog.prepend(" <li> <time> " + time + " </time> <p> <span class='type'> popstate </span> <a href='"+path+"'>" + path + "</a> - <span class='type'> history.length: </span> <span> " + history.length +" </span> </p> </li> ");
  checkURLForProcessing(first);
  first = false;
};


/* Extract the URL from the editable field and use it within pushState */
$(".articleList a").on("click", function(event, isTrigger) {
	//console.log($(this).attr("href"));
	activeInd = $(this).parent('li').index();
	event.preventDefault();
	_self = $(this);
	newsurl = _self.attr("href");
	URLcall();
	if(typeof isTrigger=="undefined")
	{
		//event.preventDefault();
		$(".articleDataWrap").html('');
		setTimeout(function(){
		$(".articleDataWrap").children('article').addClass('selected');
		},1000);
	}

	
}).eq(0).trigger("click", [false]); //onclick

example4Ajax = function(newsurl) {
  $.ajax({
    headers : {'X-Content-Only':'true'},
    type: "GET",
    url: newsurl,
    cache: false
  }).done(function( content ) {
    //$(".articleData").html('');
	$('.articleDataWrap').append($('.articleDataWrap',content).html()).addClass("animated");
   	//$(".articleDataWrap").append(pre);
  });
};

var checkURLForProcessing = function(first) {
	var user = document.location.search.split("=")[1];
	if (user && user.length > 0) {
		$("#twitter-user").text(user);
		requestTweet(user);
	} 
  if ( ( document.location.pathname !== URL_PATH && document.location.pathname !== URL_PATH + '/' ) && !first) {
    //user is not on the default page
    example4Ajax(document.location.pathname);
  } else if (!first) {
    //console.log("hmm what to do");
    //This is a hack
    $("#ajaxOutput").text("Here is some default content");
  }
};
//checkURLForProcessing(true);

/*Pushstate end*/
});

function URLcall() {
	pageTitle = document.title;
	_self.parent().addClass('active').siblings().removeClass('active');
	setTimeout(function(){
	example4Ajax(newsurl);
	history.pushState('', pageTitle, newsurl);
 	return false;
	},500);
}

function customaddPlaceholder() {

    $("input:text").addPlaceholder();

}

function customSelect(){
	$("select").each(function(){
		if($(this).parents(".selectBox").find(".selectedValue").length == 0){
			$("<div class='selectedValue'></div>").insertBefore($(this))
		}
		$(this).siblings(".selectedValue").text($(this).find("option:selected").text())		
	});

	$("select").change(function(){
		$(this).siblings(".selectedValue").text($(this).find("option:selected").text())	
	});
}

function sitemapDevice(){
	if($(window).width() < 768){
		$(".linkBox").each(function(){
			$(this).addClass("fullLength")
			$(this).width($(this).children("ul").outerWidth() * $(this).children("ul").length) ;
		});
	}else{
		$(".linkBox").removeAttr("style");
	}
}

function multiStepRefresh(){
	$(".multiStep").each(function(){
		var multiStepCarousel = $(this).data('owlCarousel');
	    multiStepCarousel._width = $(this).width();
	    multiStepCarousel.invalidate('width');
	    multiStepCarousel.refresh();
	});
}

var winH, winW, headerH, LandingsliderH, footerH, footerScroll,isDevice;
var galSrc;
var lastScrollTop = 0;
// Document Ready - Start
$(function(){
	windowORdevice();

	winH = parseInt($(window).height());
	winW = parseInt($(window).width());
	docH = parseInt($(document).height());
	headerH = parseInt($('header').height());
	LandingsliderH = parseInt($('.landingSlider').height());

	customaddPlaceholder();
	customSelect();

	$(".customDropAction").click(function(e){
		e.stopPropagation();
		var selector = $(this).parent().find(".customDropMaster");
		if(selector.is(":visible")){
			selector.slideUp();
		}else{
			selector.slideDown();
		}
		
	});

	$(".customDropMaster .close").click(function(e){
		e.stopPropagation();
		$(this).parents(".customDropMaster").slideUp();

	});

	$(".customDropper.dropDown ul li").click(function(e){
		e.stopPropagation();
		$(this).parents(".customDropMaster").slideUp();
		var _thisText = $(this).find("a").html();
		$(this).parents(".customDropper").find(".customDropAction").html(_thisText)
	});

	$(".searchIcon > a").click(function(){
		$(this).toggleClass("close").siblings(".searchWrap").fadeToggle();
		var _this = $(this).parents(".topRight").nextAll();
		var _thisOpacity = $(this).hasClass("close") ? 0 : 1;
		_this.css({opacity:_thisOpacity});
	});

	$(".lBox").each(function(){
		//Adding 5 color bluestrip to Lightbox.
		$(this).append('<div class="styling"><span></span><span></span><span></span><span></span><span></span></div>');
	});

	if(document.all && !window.atob){
		//IE9 & OLDER 

		/*For Gradient START*/

		if($(".twoClrBand").length){
			var bg = $(".twoClrBand").css("background-color");
			$(".twoClrBand").prepend("<div class='leftBG' style='display:block; width:50%; height:100%; position:absolute; left:0; top:0; z-index:1; background:"+bg+";'></div>")
			$(".leftBG").siblings().css({"z-index":2, 'position':'relative'});
		}

		/*For Gradient END*/
	}


	if (/Android|webOS|iPhone|iPad|iPod|BlackBerry/i.test(navigator.userAgent)) {
		$("body").addClass("touchDevices");
		isDevice = true;
	}else{
		$("body").addClass("no-touch");
		isDevice = false;
	}


//console.log(winH);
//alert(winH);
	
	if(winW>1280){
		bannerHeight();
	}
	
	if(winW>1024 && winW<=1280){
		bannerHeight1();
	}
	if(winW<=1024){
		bannerHeightDevice();
	}
	
	if(winW<=1024){
		//$('.footerLinksWrap').prepend($('.footerTop').clone());
		
		$('.topRight li.login a, .quickLinks li a').html(' ');
		
		var advWidth = $('.advantageDetailBox li').length * $('.advantageDetailBox li').width();
		$('.advantageDetailBox ul').css({'width':advWidth});
		
		footerH = parseInt($('.footerLinksWrap').offset().top);
		//console.log('onload' + footerH);
		//console.log('winH' + winH);	
		//console.log('fixedFooter' + $('.footerTop').height());
		//console.log('copyright' + $('.copyright').height());	
	}	
		
		
		$('.menuBox h2').on('click', function(){
			if(winW<768){
				$(this).parent().find('ul').slideDown();
				$(this).parent().siblings().find('ul').slideUp();
			}
		});
		
		/*$('.linksBox h3').on('click', function(){
			if(winW<768){
				$(this).next('ul').slideToggle();
				$(this).parent().siblings('.linksBox').find('ul').slideUp();
			}
		});*/
		
	$('.footerArrow').on('click', function(){
		//var thisOffset = $(this).offset().top;
		$(this).toggleClass('active');
		$('.footerLinksWrap').toggleClass('marBtm');
		$('.footerTop').stop().slideToggle();
		//$('html, body').animate({'scrollTop':thisOffset},500);
	});
	
  	if(! /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) {	
		$('.productWrap .productBox').hover(function(){
			$(this).find('h2').stop().animate({'top':'25%'}, 600, 'easeOutBack');
			$(this).find('p').eq(0).stop().animate({'bottom':'50%'}, 600, 'easeOutBack');
			$(this).find('.hoverView').stop().animate({'opacity':1,'bottom':'10%'}, 600, 'easeOutBack');
			$(this).stop().css({'background':'rgba(0,62,134,0.7)'}, 600, 'easeOutBack');
		}, function(){
			$(this).find('h2').stop().animate({'top':'50%'}, 600, 'easeOutBack');
			$(this).find('p').eq(0).stop().animate({'bottom':'25%'}, 600, 'easeOutBack');
			$(this).find('.hoverView').stop().animate({'opacity':0,'bottom':'-40%'}, 600, 'easeOutBack');
			$(this).stop().css({'background':'none'}, 600, 'easeOutBack');
			});
		
		$('.personalMenu').on('click', function(event){
		 	productMenu(event);
			$('.menuDetails').css({'top':'50%', 'transform':'translateY(-50%)'},1000);
		});
		
		if($('.hoverBoxes').length){
			$('.hoverBoxes').on('mouseenter', function(){
				if($(this).hasClass('noTitle')){
					var hoverTopVal = "38%";
					var hoverBottomVal = "10%"
				}
				else{
					var hoverTopVal = "10%";
					var hoverBottomVal = "10%"
				}
				$(this).find('.hoverBoxTop').stop().animate({'top':hoverTopVal}, 600, 'easeOutBack');
				$(this).find('.hoverView').stop().animate({'opacity':1,'bottom':hoverBottomVal}, 600, 'easeOutBack');
				$(this).find('.hoverData').stop().css({'background':'rgba(0,98,168,0.7)'}, 600, 'easeOutBack');
			})
			
			$('.hoverBoxes').on('mouseleave', function(){
				if($(this).hasClass('noTitle')){
					var topVal = "69%";
					var bottomVal = "-40%"	
				}
				else{
					var topVal = "40%";
					var bottomVal = "-40%"	
				}
				$(this).find('.hoverBoxTop').stop().animate({'top':topVal}, 600, 'easeOutBack');
				$(this).find('.hoverView').stop().animate({'opacity':0,'bottom':bottomVal}, 600, 'easeOutBack');
				$(this).find('.hoverData').stop().css({'background':'none'}, 600, 'easeOutBack');
			})
		}
	}
	else {
		$('.productBox.personal').on('click', function(event){
		 	productMenu(event);
			setTimeout(function(){
			$('.productMenu').css({'height':$('.productWrap').height()});
			},1000);
		});
	}

	$('.closeMenu').on('click', function(){
		$('.productMenu').slideUp('slow','easeOutBack', function(){
				$('.menuDetails').animate({'opacity':0},1000);
			});
		$('.productWrap').find('.productBox').css({'opacity':1});
	});
	
	$('.quickLinks .icon-share').on('click', function(){
		$('.socialLinks').toggleClass('active');
	});
	
	/*Owl Start*/
	if(winW<=1024){
		lookingLinks();
	}
	
	if($('.bannerCarousel, .yesFirstCont .innerBannerCarousel').length){
		$('.bannerCarousel, .yesFirstCont .innerBannerCarousel').owlCarousel({
			items:1,
			dots:true,
			dotsContainer: $('.bannerCarousel, .yesFirstCont .innerBannerCarousel').next(".contentWrapper").find(".customNav"),
			navRewind:false,
			margin:0,
			responsiveClass:true,
			autoplay:false,
			autoplayTimeout:2000,
			autoplayHoverPause:true,
			smartSpeed:1000,
			loop:true,
			//autoplay:true,
			//loop:true
		});
	}

	
	if($('.innerBannerCarousel.multiBanner').length){
		$('.innerBannerCarousel.multiBanner').owlCarousel({
			items:1,
			dots:true,
			dotsContainer: $(this).next(".contentWrapper").find(".customNav"),
			navRewind:false,
			margin:0,
			responsiveClass:true,
			autoplay:false,
			autoplayTimeout:2000,
			autoplayHoverPause:true,
			smartSpeed:1000,
			//autoplay:true,
			//loop:true
		});
	}

	if($('.innerBannerCarousel').hasClass("")){
		$('.bannerCarousel, .yesFirstCont .innerBannerCarousel').owlCarousel({
			items:1,
			dots:true,
			dotsContainer: $('.bannerCarousel, .yesFirstCont .innerBannerCarousel').next(".contentWrapper").find(".customNav"),
			navRewind:false,
			margin:0,
			responsiveClass:true,
			autoplay:false,
			autoplayTimeout:2000,
			autoplayHoverPause:true,
			smartSpeed:1000,
			loop:true,
			//autoplay:true,
			//loop:true
		});
	}

	if($('.bandCarousel').length){
		$('.bandCarousel').owlCarousel({
			nav:true,
			dots:false,
			loop:false,
			navText:["",""],
			navContainer: $('.bandCarousel').prev(".customNav"),
			navRewind:false,
			margin:0,
			responsiveClass:true,
			responsive:{
				0:{
					items:1
				},
				480:{
					items:2
				},
				980:{
					items:2
				},
				1024:{
					items:3
				},
				1280:{
					items:4
				}
			}
		});
	}
	if($('.imageCarousel').length){
		$('.imageCarousel').owlCarousel({
			nav:true,
			dots:false,
			loop:false,
			navText:["",""],
			navContainer: $('.imageCarousel').prev(".customNav"),
			navRewind:false,
			margin:7,
			responsiveClass:true,
			responsive:{
				0:{
					items:2
				},
				480:{
					items:3
				},
				1024:{
					items:4
				},
				1280:{
					items:4
				}
			}
		});
	}
	
	
	if($('.pevlBoxCarousel').length){
		if($('body').hasClass('cards')){
			var navVal = true;
		}	
		else{
			var navVal = false;
		}
		
		$('.pevlBoxCarousel').owlCarousel({
			
			dots:true,
			//dotsContainer: $('.pevlBoxCarousel').next(".customNav"),
			loop:false,
			navRewind:false,
			margin:0,
			responsiveClass:true,
			pullDrag:true,
			nav:false,
			navContainer: $('.pevlBoxCarousel').next(".customNav"),
			responsive:{
				0:{
					items:2,
					nav:false,
					center: true,
					loop: true
				},
				480:{
					items:2,
					nav:false
					
				},
				768:{
					items:3,
					nav:false
				},
				1024:{
					items:3,
					pullDrag:false,
					nav:true,
					dots:false,
					
				}
			}
		});
	}
	
	if($('.offersCarousel').length){
		$('.offersCarousel').owlCarousel({
			nav:false,
			dots:true,
			loop:false,
			navRewind:false,
			margin:0,
			responsiveClass:true,
			pullDrag:true,
			responsive:{
				0:{
					items:1
				},
				480:{
					items:2
				},
				1024:{
					items:2,
					pullDrag:false
				}
			}
		});
	}
	
	if($('.hoverBoxesCarousel').length){
		var pullDragVal = $('.hoverBoxesCarousel').children.length>2 ? true : false;
		$('.hoverBoxesCarousel').owlCarousel({
			nav:false,
			dots:true,
			loop:false,
			navRewind:false,
			margin:0,
			pullDrag:true,
			responsiveClass:true,
			responsive:{
				0:{
					items:1
				},
				598:{
					items:2,
					pullDrag : pullDragVal
				}
			}
		});
	}
	
	if($('.solutioneOWL').length){
		//var pullDragVal = $('.hoverBoxesCarousel').children.length>2 ? true : false;
		$('.solutioneOWL').owlCarousel({
			nav:false,
			dots:true,
			loop:false,
			navRewind:false,
			margin:0,
			//pullDrag:true,
			//dotsContainer: $('.solutioneOWL').next(".customNav"),
			responsiveClass:true,
			responsive:{
				0:{
					items:1
				},
				481:{
					items:2
				},
				769:{
					items:3
				}
			}
		});
	}
	
	if($('.midCarousel').length){
		$('.midCarousel').owlCarousel({
			items:1,
			nav:true,
			dots:false,
			loop:false,
			navText:["",""],
			navContainer: $('.midCarousel').prev(".customNav"),
			navRewind:false,
			margin:0,
			responsiveClass:true
		});
	}

	if($('.featureMaster').length){
		$('.featureMaster .featureOWL').owlCarousel({
			items:3,
			nav:true,
			dots:true,
			loop:false,
			slideBy:1,
			navText:["",""],
			navContainer: $('.featureMaster').find(".customNav"),
			navRewind:false,
			margin:20,
			responsiveClass:true,
			responsive:{
				0:{
					items:1
				},
				480:{
					items:1
				},
				640:{
					items:2
				},
				768:{
					items:3
				}
			}
		});
		$('.featureMaster').on("click",".featureOWL .featureBox .btn", function(){
			$(this).parents(".featureBox").clone().appendTo(".showCont");
			$(".showCont").fadeIn();
		});

		$(document).on("click",".close",function(){
			$(this).parents(".showCont").fadeOut(800,function(){
				$(this).find(".featureBox").remove();
			})
		});
		
	}
	if($('.verticalLayout').length){

		$('.verticalLayout .boxOwl').owlCarousel({
			items:3,
			dots:true,
			loop:false,
			slideBy:1,
			nav:false,
			navRewind:false,
			responsiveClass:true,
			margin:10,
			responsive:{
				0:{
					items:1.5,
					center: true,
					loop: true
				},
				480:{
					items:2.2,
					center: true,
					loop: true
				},
				600:{
					items:1.4,
					center: true,
					loop: true
				},
				768:{
					items:3
				}
			}
		});
	}
	
	
	if($('.horizontalLayout').length){

		if($('.verticalLayout .boxOwl').children().length){
			$('.horizontalLayout .boxOwl').owlCarousel({
				items:3,
				dots:true,
				loop:false,
				slideBy:1,
				nav:false,
				navRewind:false,
				margin:10,
				responsiveClass:true,
				responsive:{
					0:{
						items:1.2,
						center: true,
						loop: true
					},
					360:{
						items:1.5,
						center: true,
						loop: true
					},
					480:{
						items:2,
						center: true,
						loop: true
					},
					640:{
						items:2.4,
						center: true,
						loop: true
					},
					768:{
						items:4,
						pullDrag:false
					}
				}
			});

		}else{

			$('.horizontalLayout .boxOwl').owlCarousel({
				items:3,
				dots:true,
				loop:false,
				slideBy:1,
				nav:false,
				navRewind:false,
				margin:10,
				responsiveClass:true,
				responsive:{
					0:{
						items:1
					},
					480:{
						items:2,
						pullDrag:false
					}
				}
			});

		}
		
	}

	if($('.openAccountWrap').length){

		$('.productDetail .boxOwl').owlCarousel({
			dots:true,
			loop:false,
			slideBy:1,
			nav:false,
			margin:10,
			responsive:{
				0:{
					items:1,
				},
				600:{
					items:2,
					/*center: true,
					loop: true*/
				},
				768:{
					items:3
				}
			}
		});
	}
	
	if($('.circleBox').length){
		if($('.cards').length){
			var itemVal = 4
		}
		else{
			var itemVal = 5
		}
		
		$('.circleBox').owlCarousel({
			items:5,
			nav:false,
			dots:true,
			loop:false,
			slideBy:1,
			navRewind:false,
			pullDrag:true,
			responsiveClass:true,
			responsive:{
				0:{
					items:1
				},
				480:{
					items:2
				},
				640:{
					items:3
				},
				768:{
					items:4,
					dots:false
				},
				1024:{
					items:itemVal,
					dots:false,
					pullDrag:false
				}
			}
		});
	}


	if($('.accountBox').length){
		$('.accountBox').owlCarousel({
			items:2,
			dots:true,
			margin:20,
			responsiveClass:true,
			responsive:{
				0:{
					items:1
				},
				481:{
					items:2
				},
				768:{
					items:1
				},
				1024:{
					items:2
				}
			}
		});
	}
	
	if($('.offersWrap').length){
		$('.offersWrap ul').owlCarousel({				
                dots:true,
                loop: true,				
				margin:30,
                nav:false,				
				navText:false,
                responsive: {
                	1024: {
                		items: 3,
						pullDrag:false
                	},
                	768: {
						loop: true,
						autoplay:true,
						autoplayTimeout:2000,
						smartSpeed:1000,
                		items: 2
                	},
					640: {
						items: 2
					},
					320: {
						center:true,
						items: 2
					}
                }
            });
	}
	
	if(winW<768){
		if($('.imgHoverWrap').length){
			$('.imgHoverWrap').owlCarousel({				
				dots:true,
				loop: true,
				autoplay:true,
				autoplayTimeout:2000,
				smartSpeed:1000,			
				nav:false,				
				navText:false,
				responsive: {
					480: {
						items: 2
					},
					320: {
						items: 1
					}
				}
			});
		}
	}
	
/*	$('.no-touch .itemSquare').hover(function(){
		$(this).find('.itemSquareCont').stop().css({'background':'rgba(255,255,255,0.9)'}, 600, 'easeOutBack');
	}, function(){
		$(this).find('.itemSquareCont').stop().css({'background':'none'}, 600, 'easeOutBack');
	});	
	*/
	
	if($('#relationCarousel').length){
		$('#relationCarousel .relationBox').each(function(){
			$(this).attr('data-index',$(this).index()+1);
		}).promise().done(function(){
				//alert($(this).length);
				$('.itemsCount .T-item').text($(this).length);
			});
		
		$('#relationCarousel').owlCarousel({				
			dots:false,
			loop: true,
			navRewind:false,				
			margin:10,
			nav:true,				
			navText:false,			
			callbacks:true,
			center:true,
			responsive: {
				768: {					
					items: 2
				},
				320: {
					items: 1
				}
			},

		});
		
		$('#relationCarousel').on('translated.owl.carousel',function(e){
		 //alert(e.type);
		 relationContentWid();
		 $('.itemsCount .C-item').text($(this).find('.owl-item.center').find('.relationBox').attr('data-index'));
		});
		
		relationContentWid();	
	}
	
	if(winW<768){
		if($('.awardCategory').length){
			$('.awardCategory').owlCarousel({				
				dots:true,
				loop: false,
				nav:false,				
				navText:false,			
				callbacks:true,
				responsive: {
					480: {
						items: 2
					},
					320: {
						items: 1
					}
				},
	
			});
		}
	}
	if(winW<=1280){
		if($('#keyDifferentiat').length){
			$('#keyDifferentiat').find('.keysection').removeAttr('style');
			$('#keyDifferentiat').owlCarousel({				
				dots:true,
				loop: false,
				nav:false,				
				navText:false,			
				callbacks:true,
				responsive: {
					1024: {
						items: 2
					},
					320: {
						items: 1
					}
				}
	
			});
		}
		
	}

	
	if(winW<=1280){
		if($('.debitList').length){
			$('.debitList').find('li:gt(0)').css('border-left','1px solid #d2dbe0');
			$('.debitList').owlCarousel({				
				dots:true,
				loop: false,
				nav:false,				
				navText:false,			
				callbacks:true,
				slide:1,
				responsive: {
					640: {
						items: 4,
						pullDrag:false
					},
					480: {
						items: 2
					},
					320: {
						items: 1
					}
				}
	
			});
		}
		if(winW<480) {
			$('.debitList').find('li').css('border','none');
		}
	}
	
	if($('.cardsWrap').length){
		$('.cardsWrap .innerCards').owlCarousel({
			items:3,
			nav:true,
			dots:true,
			loop:false,
			slideBy:1,
			navText:["",""],
			navContainer: $('.cardsWrap').find(".customNav"),
			navRewind:false,
			margin:20,
			responsiveClass:true,
			responsive:{
				0:{
					items:1
				},
				480:{
					items:1
				},
				600:{
					items:2
				},
				768:{
					items:3,
				},
				1280:{
					dots:false,
				}
			}
		});

	}

	if($(".multiStep").length){
		$(".multiStep").owlCarousel({
			items:1,
			nav:true,
			dots:false,
			loop:false,
			slideBy:1,
			pullDrag:false,
			mouseDrag:false,
			touchDrag:false,
			navText:["Prev","Next"],
			//navContainer: $('.cardsWrap').find(".customNav"),
			navRewind:false,
			margin:20,
			responsiveClass:true
		});
	}

	/* OWL END */
	if($('.owl-carousel').length){
		$('.owl-carousel').on('translated.owl.carousel', function(event) {
				if($(this).find(".owl-stage .owl-item").last().hasClass("active")){
					$(this).find(".owl-controls .owl-dot").last().addClass("active").siblings().removeClass("active");
				}
		});
		
		$('.owl-carousel').on('resized.owl.carousel', function(event) {
			if($(this).find(".owl-stage .owl-item").last().hasClass("active")){
				$(this).find(".owl-controls .owl-dot").last().addClass("active").siblings().removeClass("active");
			}
		});
	}


	inputt();

	


	/* Product Page - Start */
	$(document).on('click', '.accordMaster .accord > span', function(event, triggerFrom){
	//$(".accordMaster .accord > span").click(event, triggerFrom){
		var thisParent = $(this).parents(".accordMaster");
		$(this).parent().find(".content").slideDown();
		$(this).parent().addClass("active").siblings().removeClass("active").find(".content").slideUp();
		$(this).parents(".accordMaster").find(".accord > span").text("+");
		$(this).text("–");
		if($('.faq, .contactus').length){
			setTimeout(function(){
				if(triggerFrom!='onLoad' ){
				$("html,body").animate({scrollTop: thisParent.find(".accord.active").offset().top- $("header").outerHeight() - 50 },300);}
			
			},800)
		}
		
	});

	$(document).on('click', '.accordMaster .accord > p', function(event){
		$(this).siblings("span").click();
	});


	
	
	$(".bannerSlide .text .btnDiv").click(function(){
		$(".bannerForm").slideToggle(500,function(){
			multiStepRefresh();
			$("html,body").animate({scrollTop:$(".bannerForm").offset().top - 120},300);
		});
	});
	
	$('.bannerForm .close').on('click', function(){
		$(".bannerSlide .text .btnDiv").click();
	})

	var rateTimeOut;
	$(".rateThis span").click(function(){
		clearTimeout(rateTimeOut);
		var _this =$(this);
		_this.parent().children().removeClass("active");
		_this.prevAll().andSelf().addClass("active");
		_this.parents(".rateThis").addClass("active");

		rateTimeOut = setTimeout(function(){_this.parents(".rateThis").removeClass("active");},3000)
	});
	/* Product Page - End */
	
	/*if($('.formBoxTop').length) {
		$(".formBoxTop").click(function(){
			$(this).find('p').toggleClass('closed');
			$('.formBoxBottom').slideToggle();
		})
	}
*/	if(winW>=768) {
		$('.advantageDetailBox li').eq(3).addClass('right');
		$('.advantageDetailBox li').eq(7).addClass('right');
	}
	else if(winW<768){
		$('.advantageDetailBox li:last-child').addClass('right');
	}
	
	$('.advantageDetailBox li').on('click', function(event){
		if($(event.target).attr('class')!='outerDiv'){
			return false;
		}
		event.stopPropagation();
		var thisWidth = $(this).width();
		var currLeftPos=$(this).index()*thisWidth;
		
		if(currLeftPos>0)
		{
			$(this).parents(".advantageDetailBox").animate({scrollLeft:currLeftPos},500);
		}
		$(this).siblings().find('.outerDiv').css('width','100%');
		$(this).find('.outerDiv').css('width','200%');
		$(this).find('.innerTxt').removeAttr('style');

			if(!$(this).hasClass('right')){				
				$(this).siblings().not($('.advantageDetailBox li.right')).find('.innerTxt').animate({'left':'-100%'});
				$(this).find('.innerTxt').animate({'left':0});
				$('.advantageDetailBox li.right').find('.innerTxt').animate({'right':'-100%'});
			}
			else {
				$(this).find('.innerTxt').animate({'right':'0%'});
				$(this).siblings().not($('.advantageDetailBox li.right')).find('.innerTxt').animate({'left':'-100%'});
				$('.advantageDetailBox li.right').not(this).find('.innerTxt').animate({'right':'-100%'});				
			}

		
	});
	$('.advantageDetailBox li .close').on('click', function(event){
		event.stopPropagation();
		//$('.advantageDetailBox li').find('.outerDiv').css('width','100%');
		$('.advantageDetailBox li').find('.outerDiv, .innerTxt').removeAttr('style');
		//$('.advantageDetailBox li.right').find('.innerTxt').animate({'left':'inherit','right':'-100%'});
		//$('.advantageDetailBox li').find('.innerTxt').animate({'left':'-100%'});

	});
	
	$('.ourTeamWrap li').on('click', function(){
		var thisInd = $(this).index();
		$(this).addClass('sel').siblings().removeClass('sel');
		$('.ourTeamWrap').find('.ourteamBox').eq(thisInd).show().siblings('.ourteamBox').hide();
	}).eq(0).click();
	
	$(".levelOne ul li").on("click", function() {
		if($(window).width()<768){
			$('.levelOne .actLink').html($(this).html());
			//$('.privilegesMaster .privilegesBox').eq($(this).index()).show().siblings().hide();
			$('.levelOne ul').slideUp();
			$('.activeItem').removeClass('act');
		}
		//else{
		$(this).addClass('active').siblings().removeClass('active');
		var leftVal = $(this).position().left;
		$('.levelTwoMaster .levelTwo').eq($(this).index()).show().siblings().hide();
		$('.levelTwoMasterCont span').css('left', leftVal)
		//}
	}).eq(0).click();
	
	/*$('.offersWrap li').hover(function(){
		$(this).find('.logo').show();
	}, function(){
			$(this).find('.logo').hide();
		});*/
	
	if($(window).width()<768){
		if($('.stepsNum').length){
			$(document).on('click', '.stepsNum li', function(){
				$(this).addClass('active').siblings().removeClass('active');
				$(this).parents('.stepsNum').next('.stepsMaster').find('li').eq($(this).index()).show().siblings().hide();
			})
			$('.stepsNum').each(function(){
				$(this).find('li').eq(0).click(); 
			})
			
			
		}
		$(document).on('click', '.activeItem', function(){
			$(this).next().slideToggle();
			$(this).toggleClass('act');
		})
		
		$('.itemList li').on('click', function(){
			$('.activeItem .activeText').html($(this).html());
			$('.privilegesMaster .privilegesBox').eq($(this).index()).show().siblings().hide();
			$('.itemList').slideUp();
			var carousel = $('.prvCarousel').data('owlCarousel');
			carousel._width = $('.prvCarousel').width();
			carousel.invalidate('width');
			carousel.refresh();
			$('.activeItem').removeClass('act');
			//
		}).eq(0).click();
		
		
		
		
		var articleTop = $('header').height() + $('.twoClrBand').height();		
		$('.articleCont').css({'margin-top':articleTop + 20});
		
	}
	
	$('.privilegesOffers h2').on('click', function(){
		$(this).next().toggleClass('mobHeight');
	});
	
	$('.deviceAccord').on('click', function(){
		$(this).toggleClass('opened');
		$(this).next().slideToggle();
	});

	/*Research*/
	if($( ".researchCat").length){

		$( ".researchCat > span" ).draggable({ 
			revert: "invalid", 
			helper: "clone",
			drag:function(){
				if($(window).width()<=767){
					return false;
				}
				
			} 
		});

		$(".searchControl").droppable({
			hoverClass: "ui-state-hover",
			drop: function (e, ui) {
				 $("#search_research").val($(ui.draggable).next().text()).attr("readonly","")
       			 $(".dropcircle").html($(ui.draggable).clone())
       			 $(".dropcircle span").removeClass("ui-draggable ui-draggable-handle");
       			 $(".searchControl .close").show().siblings(".searchIco").hide();
       			 $(this).find(".placeholder").hide();
				 $("#selectedIcon").val($(this).find("#search_research").val());
   			 }
		});


		$(".searchControl .close").click(function(){
			$(".dropcircle").html("");
			$("#search_research").val("").removeAttr("readonly").focus();
			 $(this).hide().siblings(".searchIco").fadeIn();
		});


		$('.researchCats').owlCarousel({
			items:6,
            dots:false,
            pullDrag:false,
            touchDrag:false,
            mouseDrag:false,
            nav:true,
            navRewind:false,
			navText:false,
			navContainer:$(".researchCatMaster .customNav"),
            responsive: {
				320: {
					items:2
				},
				480: {
					items:3
				},
				768: {
					items:4
				},
				1024: {
					items:5
				},
				1280: {
					items:6
				}

            }
        });


		$('.impReports .reportMaster').owlCarousel({
			nav:false,
			dots:true,
			loop:false,
			navRewind:false,
			pullDrag:false,
			margin:0,
			responsiveClass:true,
			pullDrag:true,
			responsive:{
				0:{
					items:1
				},
				481:{
					items:2
				},
				1024:{
					items:4,
					pullDrag:false
				}
			}
		});

	}

	$(document).on('click', '.formBoxTop', function(event, triggerFrom){
		if($('.subscribeBox').length){
			if($(".formBoxBottom > .current").length == 0){
				$(".formBoxBottom >  div:first-child").addClass("current").show().siblings().hide();
			}
		}
		$(this).find('p').toggleClass('closed');
		$(this).next().slideToggle();
		var ths = $(this);
		setTimeout(function(){
		var topVal = ths.offset().top - $('header').outerHeight() -10;
		if(triggerFrom!='onLoad' ){
			$('html,body').animate({scrollTop:topVal}, 800)}
		}, 800)
		
	});
	
	//$('.formBoxTop').trigger('click', ['onLoad']);
	
	
	

	$(".subscribeBox .formBoxBottom .formBoxLeft .btnDiv input").click(function(){
		$(".formBoxBottom .formBoxLeft").removeClass("current").slideUp().siblings(".formBoxRight").addClass("current").slideDown();

	});

	$(".subscribeBox .skip").click(function(){
		$(this).parents('.subscribeBox').find(".formBoxBottom .formBoxRight").removeClass("current").slideUp().siblings(".thanks").addClass("current").slideDown();
		$("html,body").delay(500).animate({scrollTop:$(".subscribeBox").offset().top- $("header").outerHeight()},500);
	});
	/*Research - End*/
	
	$(document).on('click', '.moreNewsBtn', function(){
		$('.articleCont .leftContainer').toggleClass('opened');
		$('.overlayInner').slideToggle();
	});
	
	if($('.prvCarousel').length){

		if($('.prvCarouselMaster').hasClass('no-carousal')){
			$(".prvItem").wrap("<div class='prvItemMaster' data-added='wrapped from common js'/>");


			$(document).on("click",".no-carousal .prvItemMaster .squareHover a",function(){
				var $itemSelector = $(this).parents(".prvCarouselMaster").find(".prvItemMaster");
				var $this = $(this).parents(".prvItemMaster");

				$this.removeClass("inactive").addClass("active").siblings().removeClass("active").addClass("inactive");
				$(".empty:visible").remove();

				$("html,body").animate({scrollTop:$this.offset().top - 80},500)

				var thisInd = $(this).parents(".prvItemMaster").index();
				

				if($(window).width() >= 768){
					var insertIndex = ((Math.floor(thisInd / 3) + 1)*3)-1;  // For 3 Items
				}else if($(window).width() > 480){
					var insertIndex = ((Math.floor(thisInd / 2) + 1)*2)-1;	// For 2 Items
				}else if($(window).width() <= 480){
					var insertIndex = ((Math.floor(thisInd / 1) + 1)*1)-1;  // For 1 Item
				}

				if(insertIndex >= $itemSelector.length){
					var me = $itemSelector.last();
				}else{
					var me = $itemSelector.eq(insertIndex);
				}

				$(".empty").removeClass(".infoContent");
				$(this).parents(".prvItemMaster").find(".thumbDesc")
				.clone()
				.insertAfter(me)
				.wrap("<div class='empty' />")
				.parent().addClass("infoContent")
				.prepend("<span class='close icon-cross'></span>");

			});

			$(document).on("click",".infoContent .close",function(){
				$(this).parents(".prvCarousel").find(".prvItemMaster").removeClass("inactive").removeClass("active");
				$(this).parents(".empty").remove();

			});

		}else{

			if($('.prvCarouselMaster').hasClass('teamCarouselMaster')){

				$('.teamCarouselMaster .prvCarousel').each(function(){

					$(this).owlCarousel({
						items:1,
						loop:false,
						nav:false,
						dots:true,
						margin:10,
						//navText:["",""],
						//navContainer: $(this).parent().find(".customNav"),
						navRewind:false,
						margin:0,
						responsiveClass:true,
						responsive:{
							0:{
								items:1.2,
								loop:true,
								center: true
							},
							480:{
								items:2
							},
							768:{
								items:6,
								dots:false
							}
						}
					});

				});
				
			}
			else{

				$('.prvCarousel').each(function(){
					$(this).owlCarousel({
						items:1,
						loop:false,
						nav:true,
						dots:false,
						navText:["",""],
						navContainer: $(this).parent().find(".customNav"),
						navRewind:false,
						margin:0,
						responsiveClass:true,
						responsive:{
						0:{
							items:1
						},
						480:{
							items:2
						},
						980:{
							items:2
						},
						1280:{
							items:2
						}
					}
					});
				});
			
			}


		}

		
	}
	
	if($('.accordion').length){
		$(document).on('click', '.tabWrap li', function(){
			$(this).addClass('active').siblings().removeClass('active');
			$('.accordion .accCont').eq($(this).index()).find('.accHead')
			.addClass('active')
			.next().slideDown()
			.parent().siblings().find('.accHead').removeClass('active').next().slideUp();
			
				$('.accCont').each(function(){
					//$('.accCont').eq(0).find('.accHead').trigger('click', ['onLoad']);
					$(this).find(".accordMaster").find(".accord").eq(0).find('span').trigger('click', ['onLoad']);
				});
			
		})
		$('.accCont').each(function(){
			//$('.accCont').eq(0).find('.accHead').trigger('click', ['onLoad']);
			$(this).find(".accordMaster .accord").eq(0).find('span').trigger('click', ['onLoad']);
		});
		$('.tabWrap li').eq(0).click();
		$(document).on('click', '.accHead', function(event, triggerFrom){
			var thisIndex = $(this).parent().index();
			$(this).addClass('active').next().slideDown();
			
			$(this).parent().siblings().find('.accHead').removeClass('active').next().slideUp();
			$('.tabWrap li').eq(thisIndex).addClass('active').siblings().removeClass('active');
			setTimeout(function(){
				
				if($('.twoClrBand').length){
					var topVal = $('.accHead.active').offset().top - ($('header').outerHeight() + $('.twoClrBand').outerHeight()) -10;
				}
				else{
					var topVal = $('.accHead.active').offset().top - $('header').outerHeight() -10;
				}
				if(triggerFrom!='onLoad' ){
				$('html,body').animate({scrollTop:topVal}, 800)}
			}, 800)
			
			if($('.teamCarouselMaster').length && !$(".teamCarouselMaster").hasClass("no-carousal")){
				$('.teamCarouselMaster').each(function(){
					var newCarousel = $(this).find('.prvCarousel').data('owlCarousel');
					newCarousel._width = $(this).find('.prvCarousel').width();
					newCarousel.invalidate('width');
					newCarousel.refresh();
				})
			}
			

			
		})
		$('.accCont').eq(0).find('.accHead').trigger('click', ['onLoad']);
	}
	

		
	
	$("#key-nav a").on("click", function(n) {
		n.preventDefault();
		var thisAttr = $(this).attr("href");
		var off  = $(thisAttr).offset().top;
		$(this).parent().addClass('active').siblings().removeClass('active');
		$('html,body').animate({scrollTop:off},1000);
		//_body.scroll(thisAttr, 400, "easeInOutQuad")
	});
	
		if($('#datepicker').length){
			var Event = function (text, className) {
				this.text = text;
				this.className = className;
			};
			// An array of events
			var events = {};
			events[new Date("12/12/2015")] = new Event("You have selected Training 1", "highlight");
			events[new Date("08/16/2015")] = new Event("You have selected Training 2", "highlight");
			events[new Date("07/12/2015")] = new Event("You have selected Training 3", "highlight");
			events[new Date("11/18/2015")] = new Event("You have selected Training 4", "highlight");
	
			$('#datepicker').datepicker({
				dateFormat: 'dd-mm-yy',
				changeMonth: true,
				changeYear: true,
				showOn: 'button',
				buttonImage: "../images/calendar.png",
				buttonImageOnly: true,
				beforeShowDay: function (date) {
					var event = events[date];
					if (event) {
						return [true, event.className, event.text];
					} else {
						return [true, '', ''];
					}
				}/*,
            onSelect: function (date) {
                var event = events[new Date(date)];
                if (event) {
                    alert(event.text);
                }
                else {
                    alert('No training event');
                }
            }*/
			});
		}

		$(".totalresult").on("click", function() {
			if(winW<768){
				$('.resultFilter').slideToggle();
			}
		});
		
		$(".levelOne .actLink").on("click", function() {
			if(winW<768){
				$('.levelOne ul').slideToggle();
				$(this).toggleClass('act');
			}
		});
		
		$(".searchRight .box .title").on("click", function() {
			if(winW<768){
				$(this).next().slideToggle();
			}
		});

		/* Compare Page - Start*/
		var h3Offset = 0;
		$(".compare h3").click(function(){
			h3Offset = $(this).parents("tr").offset().top-$("header").outerHeight();
			$(this).toggleClass("active");
			$(this).parents("tr").nextAll().each(function(){
				if($(this).find("h3").length){
					return false;
				}
				$(this).toggle();
			}).promise().done(function(){
				$("html,body").animate({scrollTop:h3Offset},800)
			});
		})

		$(document).on("click",".compare .imgBox .close",function(){
			//$(this).parents("td").remove();
			var parentInd = $(this).parents("td").index();
			$(this).parents("table").find("tr").each(function(){
				if($(this).index()==0){
					$(this).find("td").eq(parentInd).html('<div class="addMoreCards"><div class="selectBox"><div class="selectedValue">Some Other Card 1</div><select><option selected="">Add  Another Card</option><option>Some Other Card 1</option><option>Some Other Card 2</option><option>Some Other Card 3</option></select></div></div>')
				}else{
					$(this).find("td").eq(parentInd).html("");
				}
				
			});





			$("#lastClosed").val($(this).parents("td").find("h2").text());
		});
		/* Compare Page - End*/
		
		if($('.imgThumb').length){
			var autoGallery;
			var lightBoxVideo = document.getElementById("galVideo");
			var thumbLength = $(".imgThumb").length;

			$(".imgThumb").on("click", function(event,isTriggered) {
				
				$(this).addClass("current").parents(".owl-item").siblings().find(".imgThumb").removeClass("current");
				var imgPath = $(this).find('img').attr('src');
				$('.imgBig img').attr('src', imgPath);

			}).eq(0).click();


			$(document).on("click", ".imgBig .zoom", function(event,isTriggered,autoNext){
				if(isTriggered == undefined){
					galSrc = $(".imgBig img").attr("src");
				}else{
					galSrc = isTriggered;
					if(autoNext==true){
						$(".progressingBar").removeAttr("style").stop().animate({width:"100%"},2900);
					}
				}
				var thisImage =  $(".imgThumb img[src='"+galSrc+"']");

				if(thisImage.parents(".imgThumb").attr("data-video")){
					$('.imgBig').attr("data-video",thisImage.parents(".imgThumb").attr("data-video"))
				}else{
					$('.imgBig').removeAttr("data-video")
				}

				if($(".imgBig").attr("data-video")){ // If Video
					var videoPath = $(".imgBig").attr("data-video");

					if(lightBoxVideo.canPlayType("video/mp4")){
						$("#imageGallery video").attr('src', videoPath+".mp4");
					}else if(lightBoxVideo.canPlayType("video/webm")){
						$("#imageGallery video").attr('src', videoPath+".webm");
					}else if(lightBoxVideo.canPlayType("video/ogv")){
						$("#imageGallery video").attr('src', videoPath+".ogv");
					}
					$("#imageGallery video").attr('poster', galSrc);
					$("#imageGallery video").show().siblings("img").hide();

				}else{  // If Image
					$("#imageGallery img").attr("src",galSrc).show().siblings("video").hide();
				}


				$("#imageGallery .desc p").text(thisImage.attr("alt"))

				var $thisIndex = $(".imgThumb img[src='"+galSrc+"']").parents(".owl-item").index();

				$(".counter").html("<span>"+parseInt($thisIndex+1)+"</span> out of "+thumbLength);
				$("#imageGallery").css('top', $(window).scrollTop() + 50);
				$("#imageGallery, .overlay").show();

				if($thisIndex == 0){
					$("#imageGallery .controls .prev").addClass("disabled");
					$("#imageGallery .controls .next").removeClass("disabled");
				}else if(parseInt($thisIndex+1) == thumbLength){
					$("#imageGallery .controls .prev").removeClass("disabled");
					$("#imageGallery .controls .next").addClass("disabled");
				}else{
					$("#imageGallery .controls .prev, #imageGallery .controls .next").removeClass("disabled");
				}

			});

			$(".imgThumb").each(function(){
				if($(this).attr('data-video')){
					if($(this).find('span').length==0){
						$(this).prepend('<span></span>');
					}
				}
			})

			$(document).on("click", "#imageGallery .controls a", function(event,isTriggered,autoNext){
				$(".progressingBar").removeAttr("style");
				
				if(isTriggered == undefined){
					if($(".playBt").hasClass("icon-pause")){
			    		$(".playBt").click();
					}

				}

				

				if(lightBoxVideo.paused == false && isTriggered != true){
					lightBoxVideo.pause();
				}

				if(!$(this).hasClass("disabled")){
					var $selector =  $(".imgThumb img[src='"+galSrc+"']").parents(".owl-item");
					if($(this).hasClass("prev")){
						galVal = $selector.prev().find(".imgThumb img").attr("src");
					}else{ // if next
						if($selector.next().length){
							galVal = $selector.next().find(".imgThumb img").attr("src");
						}
					}
					
					$(".imgBig .zoom").trigger("click",[galVal,autoNext]);
					
				}else{
					clearInterval(autoGallery);
				}
			});

			$(".playBt").click(function(){
				if(lightBoxVideo.paused == false){
					lightBoxVideo.pause()
				}

				$(this).toggleClass("icon-pause");

				if($(this).hasClass("icon-pause")){
					$(".progressingBar").removeAttr("style").stop().animate({width:"100%"},2900);
					autoGallery = setInterval(function(){
						if(!$("#imageGallery .controls .next").hasClass("disabled")){
							

							$("#imageGallery .controls .next").trigger("click",[true,true])

							

						}else{
							if($(".playBt").hasClass("autoStop")){
								$(".playBt").removeClass("autoStop");
								galVal = $(".imgThumb").eq(0).find("img").attr("src");
								$(".imgBig .zoom").trigger("click",[galVal]);


							}else{
								$(".playBt").addClass("autoStop").removeClass("icon-pause");
								clearInterval(autoGallery);
							}
						}
					},3000);
				}else{
					$(".playBt").removeClass("icon-pause");
					$(".progressingBar").stop().removeAttr("style");
					clearInterval(autoGallery);
				}
			});


			$('#imageGallery video').bind('play', function (e) {
			    if($(".playBt").hasClass("icon-pause")){
			    	$(".playBt").click();
				}
			});

					
					
			$("#imageGallery .closeLB").click(function(){
				$(".playBt").removeClass("icon-pause");
				$(".progressingBar").stop().removeAttr("style");
				clearInterval(autoGallery);
			})


		}

		$(".closeLB").click(function(){
			$(".lightBox, .overlay").hide();
		})
		
		$(".addressListWrap .arrowBtn").on('click', function(){
			if($(this).hasClass('open')){
				$(this).removeClass('open');
				$(".addressListWrap").animate({'left':'0px'});
			}
			else {
				$(this).addClass('open');
				$(".addressListWrap").animate({'left':'-252px'});
			}
		});
		
		$(".addressList").on('click', function(){
			$(this).addClass('selected').siblings().removeClass('selected');
		});
		
		$(".advSearch").on('click', function(){
			$(this).toggleClass('active');
			$('.advSearchMaster').slideToggle();
		})

		/*Sitemap*/
		sitemapDevice();
		/*Sitemap - End*/
		
		
		$(document).on('click', '.surveyTopBand .closeBtn', function(){
			$('.surveyTopBand').slideUp();
		});

		$(".dropdownUL li a").click(function(){
			var showInd = $(this).parent().index();
			var $thisParent = $(this).parents(".accData")
			$thisParent.find(".dropdownULcontent .accordMaster").eq(showInd).show().siblings().hide();

			if($(this).parents(".dropdownUL").find("a.active").length != 0){
				$("html,body").animate({scrollTop: $thisParent.offset().top-100+"px"},300);
			}

			$(this).addClass("active").parent().siblings().find("a").removeClass("active");
			
			

			$thisParent.find(".dropdownData").text($(this).text())

			if($thisParent.find(".dropdownULcontent .accordMaster").eq(showInd).find(".accord.active").length == 0){
				$thisParent.find(".dropdownULcontent .accordMaster").eq(showInd).find(".accord").eq(0).children("span").click();
			}
		});

		$(".dropdownUL").each(function(){
			$(this).find("li").eq(0).find("a").click(); //Loans - under rates page.
		});

		if($(".dropdownULcontent").length){
			$(".dropdownULcontent").each(function(){
				$(this).find("table").wrap("<div class='ov' />");
			});
		}
		
		
		$('.stepNextBtn').on('click', function(){
			$(this).parents('.stepBox').hide().siblings('.stepBox').show();
			$(this).parents('.surveyWrap').find('.steps').children('li').addClass('active');
			var surveyTop = $('.surveyWrap').offset().top - $('.surveyTopBand').outerHeight();
			$('html, body').animate({scrollTop:surveyTop},800);
		});

		/* CardsLanding - Start */

		if($(".scrollSlider").length){
			if(winW > 1024){
				var minusH = $("header").outerHeight() + $("footer .fixedWrap").outerHeight();
				$(".scrollSections").height(winH-minusH);
			}


			var scrollDiv = document.getElementById("wrapper");
			if (scrollDiv.addEventListener) {
				scrollDiv.addEventListener("mousewheel", cardsScroller, false); // IE9, Chrome, Safari, Opera
				scrollDiv.addEventListener("DOMMouseScroll", cardsScroller, false); // Firefox
			}
			else{
				scrollDiv.attachEvent("onmousewheel", cardsScroller); // IE 6/7/8
			}


			$(".scrollSectionMaster .dots li").click(function(){
				var ind = $(this).index();
				$(this).addClass("active").siblings().removeClass("active");
				$("html,body").stop(true,true).animate({scrollTop: $(".scrollSlider .scrollSections").eq(ind).offset().top-  $("header").outerHeight()},500)
			});
		}
		/* CardsLanding - End */
		//Calculating height
		/*if($('.debitList li').length){
			$('.debitList li').each(function() {
				arrayHeight.push($(this).height());
				//console.log(arrayHeight);
				minHeight = Math.max.apply(Math,arrayHeight);
				//console.log(maxHeight);
			});
		}*/
		
		var socialFlag = true;
		$('.linksSocials li').addClass('active');
		$('.linksSocials li').on('click', function(){
			var _thisIndex = $(this).index();
			var actLength = $('.social-inner > div:visible').length-1 ;
			//console.log(actLength);
			if(actLength<1 && $(this).hasClass('active')) {
				return false;
			}
			else {
				$(this).toggleClass('active');
				if($(this).hasClass('active')){
					$('.social-inner > div').eq(_thisIndex).show();
				}
				else {
					$('.social-inner > div').eq(_thisIndex).hide();
				}
				
 				actLength = $('.social-inner > div:visible').length ;
				var actWidth =  (100 / (actLength)) - 2;
				$('.social-inner > div:visible').css({'width': actWidth + '%'});
			}
			
		});

		/* Compare */
		/*$(document).on("change", ".compare_bb input:checkbox", function(){
			if($(this).is(":checked")){
				$(this).siblings("label").text("Added to compare");
				$(this).parents(".checkbox").addClass("active");
				$(".comparisonBox").slideDown();
			}else{
				$(this).siblings("label").text("Add to compare")
				$(this).parents(".checkbox").removeClass("active");
				$(".comparisonBox").slideUp();
			}
		});*/

		$(document).on("change", ".addToCompare_input", function(){
			if($(this).is(":checked")){
				$(this).siblings("label").text("Added to compare");
				$(this).parents(".checkbox").addClass("active");
				$("html,body").animate({scrollTop:$(".blueBand").offset().top-300})
				$(".comparisonBox").slideDown();
			}else{
				$(this).siblings("label").text("Add to compare")
				$(this).parents(".checkbox").removeClass("active");
				if($(".comparisonBox img").length > 0){
					$(".comparisonBox").slideDown();
				}
				
			}
		});

		$(document).on("click", ".comparisonBox > .close", function(){
			$(".comparisonBox").slideUp();
		});
		/* Compare - End */

		/* .lBox - Click to Call */
		$("*[data-lightbox]").click(function(){
			var showId = "#"+$(this).attr("data-lightbox");
			$(".overlay,"+showId).fadeIn();

			$("html,body").animate({scrollTop:$(showId).offset().top - 100},500);

			//setTimeout(function(){
				if($(showId).find(".owl-carousel").length){
					var carouselData = $(showId).find(".owl-carousel").data('owlCarousel');
				    carouselData._width = $(showId).find(".owl-carousel").width();
				    carouselData.invalidate('width');
				    carouselData.refresh();
				}
			//},500);

			

			var closeThis = $(showId).find(".close");

			closeThis.one("click",function(){
				$(".overlay,"+showId).fadeOut();
			});

			$(".overlay").one("click",function(){
				closeThis.click();
			});
		});

		/* lBox - Click to Call - End */

		/* Explore Menu - Start */
			var actPosLeft, actPosTop;
			var _lastThis;
			$(".cat").click(function(){
				var _this = $(this).parents("li");
				_lastThis = _this;

				if(_this.position().top > 0){
					var dAmount = 1000;
				}else{
					var dAmount = 500;
				}

				if($(window).width() > 480){
					_this.find(".innerExplore").css("width",_this.parent("ul").width()-_this.width());
				}
				else{
					_this.find(".innerExplore").css("width",_this.parent("ul").width());
				}

				_this.find(".innerExplore").delay(dAmount).fadeIn(500,function(){
					_this.parents(".exploreBox").find(".close").addClass("back").attr("title","Back to products");
				});

				_this.addClass("active").siblings().removeClass("active").addClass("hideUs");
				_this.css({"left":_this.position().left, "top":_this.position().top})

				actPosLeft = _this.position().left;
				actPosTop = _this.position().top;

				setTimeout(function(){
					_this.addClass("animate").css({"position":"absolute", "left":0, "top":0});

					/*setTimeout(function(){
						_this.css({"left":actPosLeft, "top":actPosTop});
						setTimeout(function(){
							_this.removeAttr("style");
							_this.removeClass("active").siblings().removeClass("hideUs");
						},1500);
					},2500);*/

				},500)
			});

			$(document).on("click",".exploreBtnWrap .messageBtn",function(){
				$(".exploreBox").addClass("active");
			});

			$(document).on("click",".exploreBox .close",function(){
				if(!$(this).hasClass("back")){
					$(".exploreBox").removeClass("active");
				}else{
					//For Back
					$(this).removeClass("back");
					_lastThis.find(".innerExplore").fadeOut(300);
					_lastThis.css({"left":actPosLeft, "top":actPosTop});
					setTimeout(function(){
						_lastThis.removeAttr("style");
						_lastThis.removeClass("animate active").siblings().removeClass("hideUs");
					},1000);

				}
			});

		/* Explore Menu - End */

});

function resetExplore(_this){
	try{
		$(".exploreBox").removeClass("active");
		$(".exploreBox .close").removeClass("back");
		$(".exploreBox .products > li").removeClass("hideUs");
		$(".exploreBox .products > li.active").removeClass("active animate").removeAttr("style");
	}catch(ex){
		//Die Quitely
	}
}
/*Document Ready - END */
var afterScroll;
function cardsScroller(e,touchDirection){

	if($(window).width() >= 1024){

		
		clearTimeout(afterScroll);
		if(e.type=="touchend"){
			var eventHandler  = touchDirection;
		}else if(e.type=="mousewheel" || e.type=="DOMMouseScroll"){
			var eventHandler  = MouseWheelHandler(e) == 1 ? "up" : "down";
		}

		afterScroll = setTimeout(function(){
	 		if(eventHandler=="down"){

	 			if($(".scrollSectionMaster .dots li.active").next().length){
	 				e.preventDefault();
					e.returnValue=false;
					$(".scrollSectionMaster .dots").fadeIn();
					if(lastScrollTop == 0){
						$(".scrollSectionMaster .dots li").eq(0).click();
					}else{
						$(".scrollSectionMaster .dots li.active").next().click();
					}
		
	 			}else{
	 				$(".scrollSectionMaster .dots").fadeOut();
	 			}
	 		}else if(eventHandler=="up"){

	 			if($(".scrollSectionMaster .dots li.active").prev().length){
	 				e.preventDefault();
					e.returnValue=false;

					if(lastScrollTop == $(document).outerHeight()-$(window).height() || $(".scrollSectionMaster .dots:visible").length == 0){
						$(".scrollSectionMaster .dots li.active").click();
					}else{
						$(".scrollSectionMaster .dots li.active").prev().click();
					}
					$(".scrollSectionMaster .dots").fadeIn();
	 				
	 			}else{
	 				$(".scrollSectionMaster .dots").fadeOut();
	 				$("html,body").stop(true,true).animate({scrollTop: 0},500)
	 			}
	 			
	 			//$("html,body").animate({scrollTop: $(document).height() - $(window).height()},1000)
	 		}
	 	},100);
		
	 	return false;



 	}

}

$(window).load(function(){
	//alert(winH);

	if($('.loop').length){
		$('.loop').owlCarousel({
                dots:false,
                loop: true,
                nav:true,
				navText:false,
                responsive: {
                	1024: {
                		items: 3
                	},
                	768: {
                		items: 2
                	},
					640: {
						items: 2
					},
					320: {
						items: 1
					}
                }
            });

			if($(window).width()>=768)
			{
				$(".owl-prev").click();
			}
	}

	if($('.cardsCarousel').length){

		$('.cardsCarousel').each(function(){

			if($(this).parents(".cardsCarouselMaster").find(".carouselGroup").length == 1){
				
				$(this).owlCarousel({	
					items:4,			
					dots:false,
					loop: false,
					nav:true,
					navText:["",""],
					navContainer: $(this).parents(".carouselGroup").find(".customNav"),
					navRewind:false,						
					callbacks:true,
					responsive: {
						0: {
							items: 2
						},
						480:{
							items: 3
						},
						640: {
							items: 4
						}
					}

				});

			}else{

				$(this).owlCarousel({	
					items:4,			
					dots:false,
					loop: false,
					nav:true,
					navText:["",""],
					navContainer: $(this).parents(".carouselGroup").find(".customNav"),
					navRewind:false,						
					callbacks:true,
					responsive: {
						0: {
							items: 1
						},
						481:{
							items: 2
						}
					}

				});

			}



		});
		

	}
	
	if($(window).width()<768)
	{
		$('.privilegesOffers .offersWrap, .privilegesOffers .privilegBox').addClass('mobHeight');
	}
	
	adjustMeRight(); // For Adjusting random content
	
	//$('.debitList li').css('height',minHeight);
	
});

$(window).resize(function(){
	/*if($(".border-menu").hasClass("open") && $(window).width() > 767){
			$(".border-menu").click();
	}*/
	if(this.resizeTO) clearTimeout(this.resizeTO);
		this.resizeTO = setTimeout(function() {
		$(this).trigger('resizeEnd');
	},300);
});

$(window).bind('resizeEnd', function() {
	if(winW ==  parseInt($(window).width())){
		return false;
	}
	
	if($(".bannerForm").length && $(window).width()>1279){
		$(".bannerForm").removeAttr("style");
	}

	if(winW !=  parseInt($(window).width())){
		try{
			$(".prvCarouselMaster.no-carousal:visible").find(".prvItemMaster.active a").click();
		}catch(ex){
			//Do Nothing.
		}
	}

	multiStepRefresh();

	/*Explore*/
	resetExplore($(".exploreBox .products > li.active"));
	/*Explore - End*/
	
	/*if($('.debitList li').length){
		$('.debitList li').removeAttr('style');
		$('.debitList li').each(function() {
			arrayHeight.push($(this).height());
			minHeight = Math.max.apply(Math,arrayHeight);
		});
		$('.debitList li').css('height',minHeight);
	}*/
	
	$("#imageGallery:visible").css('top', $(window).scrollTop() + 50);

	setTimeout(function(){
		applyHeight();
	},300)

	if($(".bannerForm").length && winW !=  parseInt($(window).width()) && $(window).width()>1279){
		$(".bannerForm").removeAttr("style");
	}
	setTimeout(function(){
		applyHeight();
	},300)

	windowORdevice();
	winH = parseInt($(window).height());
	winW = parseInt($(window).width());
	docH = parseInt($(document).height());
	headerH = parseInt($('header').height());
	LandingsliderH = parseInt($('.landingSlider').height());

	if(winW>1024 && winW<=1280){		
		bannerHeight();
	}
	
	//$('.productMenu').hide();
	
	if(winW<=1024){
		$('.bannerWrap').removeAttr('style');
		bannerHeightDevice();
	}
	
	lookingLinks();
	
	//footerH = parseInt($('.footerLinksWrap').offset().top - $('.footerLinksWrap').height());
	//console.log('resize' + footerH);
	if(winW<768){
		var articleTop = $('header').height() + $('.twoClrBand').height();		
		$('.articleCont').css({'margin-top':articleTop + 20});
		$('.stepsNum').each(function(){
			$(this).find('li').eq(0).click(); 
		})
		
	}
	else {
		$('.articleCont, .stepsCont').removeAttr('style');
	}
	
	$('.leftContainer').css({'width':'29%'});
	$('.leftContainer').css({'width':$('.leftContainer').width()});
	
	adjustMeRight();
	relationContentWid();

	if(winW<768){
		if($('.awardCategory').length){
			$('.awardCategory').owlCarousel({				
				dots:true,
				loop: false,
				nav:false,				
				navText:false,			
				callbacks:true,
				responsive: {
					480: {
						items: 2
					},
					320: {
						items: 1
					}
				},
	
			});
		}
	}
	
	if(winW<=1280){
		if($('#keyDifferentiat').length){
			$('#keyDifferentiat').find('.keysection').removeAttr('style');
			$('#keyDifferentiat').owlCarousel({				
				dots:true,
				loop: false,
				nav:false,				
				navText:false,			
				callbacks:true,
				responsive: {
					1024: {
						items: 2
					},
					320: {
						items: 1
					}
				}	
			});
		}
		
	}
	
	if(winW<=1280){
		if($('.debitList').length){
			$('.debitList').owlCarousel({				
				dots:true,
				loop: false,
				nav:false,				
				navText:false,			
				callbacks:true,
				slide:1,
				responsive: {
					640: {
						items: 4
					},
					480: {
						items: 2
					},
					320: {
						items: 1
					}
				}
	
			});
		}
		
	}
	if(winW<=1280){
		if($('.debitList').length){
			$('.debitList').find('li:gt(0)').css('border-left','1px solid #d2dbe0');
			$('.debitList').owlCarousel({				
				dots:true,
				loop: false,
				nav:false,				
				navText:false,			
				callbacks:true,
				slide:1,
				responsive: {
					640: {
						items: 4,
						pullDrag:false
					},
					480: {
						items: 2
					},
					320: {
						items: 1
					}
				}
	
			});
		}
		if(winW<480) {
			$('.debitList').find('li').removeAttr('style');
		}		
	}
	
	
	keysecHeight();

	if(winW>=768){
		$('.resultFilter').removeAttr('style');
	}

	if(winW>480){
		if($(".dropdownUL").length){
			$(".dropdownUL").removeAttr("style");
		}
	}

	if($(".scrollSlider").length){
		if(winW < 1025){
			$(".scrollSections").removeAttr("style");
		}else{
			var minusH = $("header").outerHeight() + $("footer .fixedWrap").outerHeight();
			$(".scrollSections").height(winH-minusH);
		}
	}

	/*Sitemap*/
	sitemapDevice();
	/*Sitemap - End*/

	if($(".lBox:visible").length){
		$("html,body").animate({scrollTop:$(".lBox:visible").offset().top - 100},500);
	}

});
/* Resize End - End */

var flag=false;
$(window).scroll(function(){
	
	if(this.scrollTO) clearTimeout(this.scrollTO);
	this.scrollTO = setTimeout(function() {
		$(this).trigger('scrollEnd');
	},100);

	//var fireTrigger = ($(window).scrollTop() * 100) / winH;
	var fireTrigger=($(window).scrollTop()/($(document).height()-winH))*100;
	
	if(fireTrigger>80 && flag==false){
		$(".articleList li.active").next("li").addClass("abc").children('a').trigger('click',true);
		flag=true;
		//return false;
	}
		
	$('.leftContainer').toggleClass('fixedList', $(document).scrollTop() >= 50);
	
	/*News article progress bar functionality start*/
	var wrapper_height = $(".articleList").height();
	var top = $(this).scrollTop() + 200;
	
	$(".articleDataWrap article").each(function(i) {
		var this_top = $(this).offset().top;
		var height = $(this).height();
		var this_bottom = this_top + height;
		var percent = 0;
		if (top >= this_top && top <= this_bottom) {
			percent = ((top - this_top) / (height - 0)) * 100;
			if (percent >= 100) {
				percent = 100;
				$(".articleList li:eq(" + i + ") .iconCheck").show();
			} else {
				//$(".articleList li:eq(" + i + ") .iconCheck").hide();
			}
		} else if (top > this_bottom) {
			percent = 100;
			$(".articleList li:eq(" + i + ") .iconCheck").show();
		}
		$(".articleList li:eq(" + i + ") .progressbar").css("height", percent + "%");
	});
	/*News article progress bar functionality end*/
	if(winW>1280){
		if($('#keyDifferentiat').length){
			$('#keyDifferentiat').addClass('scrollStart');
			var startSecoffset = $('#keyDifferentiat .keysection:first').offset().top - 70;
			var lastSecoffset = $('#keyDifferentiat .keysection:last').offset().top - 70;
			//console.log('startSecoffset - ' + startSecoffset);
			//console.log($(window).scrollTop());
			//console.log('lastSecoffset - ' + lastSecoffset);
				
			if($(window).scrollTop()>=startSecoffset){
				$('#keyDifferentiat').removeClass('scrollStart');
				$('#key-nav').addClass('showNav');
			}
			else if($(window).scrollTop()<startSecoffset){
				$('#keyDifferentiat').addClass('scrollStart');
				$('#key-nav').removeClass('showNav');
			}
			if($(window).scrollTop()>=lastSecoffset){
				$('#keyDifferentiat').addClass('scrollEnd');
				$('#key-nav').removeClass('showNav');
			}
			else if($(window).scrollTop()<lastSecoffset){
				$('#keyDifferentiat').removeClass('scrollEnd');
			}
			
			if($(window).scrollTop()>=$('#keyDifferentiat .keysection').eq(4).offset().top - 180){
				$('#key-nav li').eq(4).addClass('active').siblings().removeClass('active');
			}
			else if($(window).scrollTop()>=$('#keyDifferentiat .keysection').eq(3).offset().top - 180){
				$('#key-nav li').eq(3).addClass('active').siblings().removeClass('active');
			}
			else if($(window).scrollTop()>=$('#keyDifferentiat .keysection').eq(2).offset().top - 180){
				$('#key-nav li').eq(2).addClass('active').siblings().removeClass('active');
			}
			else if($(window).scrollTop()>=$('#keyDifferentiat .keysection').eq(1).offset().top - 180){
				$('#key-nav li').eq(1).addClass('active').siblings().removeClass('active');
			}
			else if($(window).scrollTop()>=$('#keyDifferentiat .keysection').eq(0).offset().top - 180){
				$('#key-nav li').eq(0).addClass('active').siblings().removeClass('active');
			}
			
		}
	}
	
});

$(window).bind('scrollEnd', function(){
  // Do Your Stuff Here
  flag=false;
  lastScrollTop = $(window).scrollTop();
});

function lookingLinks() {
	if($('.lookingLinks').length){
			$(".lookingLinks ul").owlCarousel({
			loop:false,
			dots:true,
			navRewind:false,
			margin:0,
			responsive:{
				0:{
					items:1
				},
				480:{
					items:2
				},
				640:{
					items:3
				},
				1024:{
					items:5
				},
				1025: {
					items:2
				}
			}
		});
	}
}

function bannerHeight() {
	winH = parseInt($(window).height());
	headerH = parseInt($('header').height());
	LandingsliderH = parseInt($('.landingSlider').height());
	//console.log(winH);
	$('.bannerWrap').height((winH - headerH)-50);
	bannerHeight1();
}

function bannerHeight1() {
	var bannerH = $('.bannerWrap').height();
	var prodH = bannerH/2;
	$('.productWrap').css({'width':bannerH});
	$('.productBox').css({'height':prodH, 'width':prodH-1});
	$('.productMenu').height(bannerH);
}

function bannerHeightDevice(){
	var ProdW = $('.productBox').width();
	$('.productBox').css({'height':ProdW});
}
function inputt(){

	$('.checkbox > input').each(function(){
		
		if($(this).prev('span').length==0){
			var checkClass = $(this).is(':checked') ? "cheked" : "uncheked";
			$("<span class='"+checkClass+"'></span>").insertBefore($(this));
		}
	});
	
	$('.radioBtn').find("input[type='radio']").each(function(){
		if($(this).prev('span').length==0){
			$("<span class='uncheked'></span>").insertBefore($(this));
		}
	});
	

	$(document).on('click','input:checkbox', function(){
		var Check = $(this).is(':checked');
		if(Check){
			$(this).prev('span').addClass('cheked').removeClass('uncheked');
		}else{		
			$(this).prev('span').addClass('uncheked').removeClass('cheked');
		}
	});	

	$(document).on('click','input:radio', function(){
		var Check = $(this).is(':checked');
		if(Check){
			var thisName = $(this).attr("name");
			$(this).prev('span').addClass('cheked').removeClass('uncheked');
			$("input[name="+thisName+"]").not(this).prev("span").removeClass("checked").addClass('uncheked');
		}
	});		
}

function productMenu(event) {
	event.preventDefault();
	$('.productWrap').find('.productBox').css({'opacity':0});	
	$('.productMenu').css({'width':$('.productWrap').width()});
	$('.productMenu').slideDown('slow','easeOutBack', function(){
			$('.menuDetails').animate({'opacity':1},500);
		});
}

//function to height for yes first -privileges LHS box 
function applyHeight() {
	if($(window).width()>767){
		if($('.prvText').length){
			$('.prvText').removeAttr('style');
			$('.prvText').height($('.prvItem').outerHeight()-2);
		}
	}
	
}
/*Product box rearrangment start*/
	var minusIndex = 0;
	var placeInsideThis;
	var maxHeight = 0;
	function placeMeRight(_this,equalNumber){
			if(equalNumber == 1){				
				_this.removeAttr("style").children().removeAttr("style").removeClass("used");
				return false;
			}
			placeInsideThis = _this
			minusIndex = equalNumber;
			var imgCounter = 0;
			_this.children().removeAttr("style").removeClass("used");
			_this.children().eq(minusIndex-1).nextAll().each(function(){
				//console.log("INDEX: "+$(this).index())
				var i = $(this).index();

				var toAssignLeft = $(this).parent().children().eq(i-minusIndex).position().left+"px";
				var toAssignTop = ($(this).parent().children().eq(i-minusIndex).position().top+ $(this).parent().children().eq(i-minusIndex).outerHeight(true))+"px";
				$(this).parent().children().eq(i).css({"position":"absolute","left":toAssignLeft,"top":toAssignTop})
				
				var thisHeight = parseInt(toAssignTop) + $(this).parent().children().eq(i).outerHeight(true);
				maxHeight = thisHeight > maxHeight ? thisHeight : maxHeight;
			}).promise().done(function(){
				placeInsideThis.height(maxHeight);
				maxHeight = 0;
			});
	}
	
	function adjustMeRight(){
		
		if($("#prodContainer").length){
			var getMyWindow = $(window).width();
			if(getMyWindow <= 480){	placeMeRight($("#prodContainer"),1);}
			else if(getMyWindow <= 640){placeMeRight($("#prodContainer"),2)}
			else if(getMyWindow <= 1024){placeMeRight($("#prodContainer"),3)}
			else if(getMyWindow <= 1366){placeMeRight($("#prodContainer"),3)}
			else if(getMyWindow <= 1680){placeMeRight($("#prodContainer"),3)}
			else if(getMyWindow <= 1920){placeMeRight($("#prodContainer"),3)}
		}
	
	}
	/*Product box rearrangment end*/
	
	function relationContentWid() {
		$('.relationContentBox > div:first-child').html('');
		var contentDivWidth = $('#relationCarousel').find('.owl-item').width();
		var activeItem = $('#relationCarousel').find('.owl-item.center, .owl-item.active').find('.innerContent').html();
		$('.relationContentBox').css({'width':contentDivWidth});
		$('.relationContentBox > div:first-child').append(activeItem);
		
	}
	
	function keysecHeight() {
		visibleDoc = winH - ($('header').height() + $('fixedWrap').height()+50);
		//alert(visibleDoc);
		if(winW>1280){
			$('#keyDifferentiat').find('.keysection').outerHeight(visibleDoc);
		}
	}


$(window).load(function(){
	applyHeight();
	keysecHeight();
})

function applyWidth(){
	if($(window).width()<1024){
	var totList = $('.levelTwo ul li').length;
	$('.contactLinks ul').width();
	}
}