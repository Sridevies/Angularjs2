
$(function(){
//alert(9);
$( "input.productVal" ).val(addCommas(1000));
productSlider();

});
function productSlider(){
	var liLen = 1000000;
	/*$('.monthlyInvAmtOuterWrap ul').html('').css('width',(63*liLen)+'px');
	for(var i=1; i<=liLen; i++){
		$('.monthlyInvAmtOuterWrap ul').append('<li>'+i+'</li>');
	}*/
    $(".proSlider").slider({
        
        value:0,
        min:1000,
        max:1000000,
		animate:true,
        range: "min",
        start:function(event, ui){
			
		},
        slide: function(event, ui){
			var eq = ui.value-1;
			
			$( "input.productVal" ).val(addCommas(ui.value));
			
			//console.log(eq)
			
        },
        stop:function(event, ui){
			var eq = ui.value-1;
			
			//calculateFunction();
		}
    });
	//$('.monthlyInvAmtOuterWrap ul li').eq(0).addClass('activeTxt');

}

//Function to add Commas to numbers
function addCommas(nStr){
	nStr += '';
	x = nStr.split('.');
	x1 = x[0];
	x2 = x.length > 1 ? '.' + x[1] : '';
	var rgx = /(\d+)(\d{3})/;
	while (rgx.test(x1)) {
		x1 = x1.replace(rgx, '$1' + ',' + '$2');
	}
	return x1 + x2;
}
