/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* Copyright 2012-2013 Daniel Tillin full license details at http://code.google.com/p/csv-to-array/#License */String.prototype.csvToArray=function(e){var t={fSep:",",rSep:"\r\n",quot:'"',head:false,trim:false};if(e){for(var n in t){if(!e[n])e[n]=t[n]}}else{e=t}var r=[[""]];for(var i=f=p=q=0;p<this.length;p++){switch(c=this.charAt(p)){case e.quot:if(q&&this.charAt(p+1)==e.quot){r[i][f]+=e.quot;++p}else{q^=1}break;case e.fSep:if(!q){if(e.trim){r[i][f]=r[i][f].replace(/^\s\s*/,"").replace(/\s\s*$/,"")}r[i][++f]=""}else{r[i][f]+=c}break;case e.rSep.charAt(0):if(!q&&(!e.rSep.charAt(1)||e.rSep.charAt(1)&&e.rSep.charAt(1)==this.charAt(p+1))){if(e.trim){r[i][f]=r[i][f].replace(/^\s\s*/,"").replace(/\s\s*$/,"")}r[++i]=[""];r[i][f=0]="";if(e.rSep.charAt(1)){++p}}else{r[i][f]+=c}break;default:r[i][f]+=c}}if(e.head){r.shift()}if(r[r.length-1].length<r[0].length){r.pop()}return r};
                
                
function CSV2JSON(csv) {
    //var array = CSVToArray(csv);
    var array = csv.csvToArray();
    var objArray = [];
    for (var i = 1; i < array.length; i++) {
        objArray[i - 1] = {};
        for (var k = 0; k < array[0].length && k < array[i].length; k++) {
            var key = array[0][k];
            objArray[i - 1][key] = array[i][k]
        }
    }

    var json = JSON.stringify(objArray);
    var str = json.replace(/},/g, "},\r\n");

    return str;
}

function getID(str) {
    return (($.trim(str)).replace(/[^a-zA-Z0-9\s]/gi, '').replace(/[_\s]/g, '')).toLowerCase();
}