var currentMode = "Table";
var selectedTab = "Office";
var sourcePrimeRentm2pa = [];
var sourcePrimeRentmQoQ = [];
var sourcePrimeYield = [];
var sourceYieldShift = [];
function AppModel()	{
	//var data;
	var self = this;
	self.csvdata  =   ko.observableArray();
	self.selectedFlag = ko.observableArray();
	$.ajax({
		url: "/JEMEARSH021/v5/data-client/data.csv",// local path
		//url: "/jll/2014/EMEA/JEMEARSH021/v3/data-client/data.csv",   // live	csv path
		async: false,
		cache: false,
		dataType: "text",
		contentType: 'Content-type: text/plain; charset=iso-8859-1',
		beforeSend: function (jqXHR) {
			jqXHR.overrideMimeType('text/html;charset=iso-8859-1');
		},headers: {
			Accept: "text/csv; charset=utf-8",
			"Content-Type": "text/csv; charset=utf-8"
		},success: function (html) {
			self.csvdata(eval(CSV2JSON(html)));
		}
	});
	self.filterData = ko.computed(function () {
	    return ko.utils.arrayFilter(self.csvdata(), function (flaglist) {
	        return flaglist.category;
	    });
	});
	self.format=function(nStr)
	{
		nStr += '';
		x = nStr.split('.');
		x1 = x[0];
		x2 = x.length > 1 ? '.' + x[1] : '';
		var rgx = /(\d+)(\d{3})/;
		while (rgx.test(x1)) 
			{
				x1 = x1.replace(rgx, '$1' + ',' + '$2');
			} 
		return x1 + x2;
	}
};
$(document).ready(function () {

    ko.applyBindings(new AppModel());
	
	//lightbox
	var windwidth = $(window).width();
    var windheight = $(window).height();

    var boxwidth = $('.light-box').outerWidth();
    var boxheight = $('.light-box').outerHeight();

    var lightbox_left = (windwidth / 2) - (boxwidth / 2);
    var lightbox_top = (windheight / 2) - (boxheight / 2);

		lightbox_left +=10

	$(this).addClass('info_ctb_active');
	$('.overlay-light-box').css({ 'opacity': 0.85 }).fadeIn('fast');
	$('.light-box').fadeIn().css({ 'left': lightbox_left+"px",'top': lightbox_top+"px"});

	$(".close_bt").add('.overlay-light-box').click(function(){
		$('.light-box').fadeOut("slow");
		$('.overlay-light-box').fadeOut("slow");
		$(".coutry_click").trigger("click");
	});

    $(".tab-sorting li").click(function () {
        $(".tab-sorting li").children('div').removeClass('sorting-color');
        $(this).children('div').addClass('sorting-color');

        $('.sorting-color').css({ "opacity": "0.3" });
    });

    $('.table-click').click(function () {
        currentMode = "Table";
        $('.bar-chart').hide();
        $('.Retail').add('.Industrial').add('.Office').hide();
        $(eval("\"." + selectedTab + "\"")).show();
		$(".data-list td").find("strong").removeClass("text_right").addClass("text_left");
    });
    $('.Retail').add('.Industrial').hide();
    // Office data functin 
    $('.green-color').click(function () {
        sourcePrimeRentm2pa = [];
        sourcePrimeRentmQoQ = [];
        sourcePrimeYield = [];
        sourceYieldShift = [];
        selectedTab = "Office";
        if (currentMode == "Table") {
            $('.Office').show();
        } else if (currentMode == "Chart") {
            $('.Office').show();
            $('.Office').each(function () {
                if (!$(this).hasClass("gray-color")) { $(this).hide() }
            });
            //For Percent Conversion
            calcfunction();
            //For Percent Conversion
        }
        $('.Retail').add('.Industrial').hide();
        $('.tab-sorting th').removeClass('yellow-color green-color brown-color').addClass('green-color');
        $('.data-list li').removeClass('yellow-color reen-color brown-color').addClass('green-color');
        barChart();
    });
    // Retail data functin 
    $('.yellow-color').click(function () {
        sourcePrimeRentm2pa = [];
        sourcePrimeRentmQoQ = [];
        sourcePrimeYield = [];
        sourceYieldShift = [];
        selectedTab = "Retail";
        if (currentMode == "Table") {
            $('.Retail').show();
        } else if (currentMode == "Chart") {
            $('.Retail').show();
            $('.Retail').each(function () {
                if (!$(this).hasClass("gray-color")) { $(this).hide() }
            });
            //For Percent Conversion
            calcfunction();
        }
        $('.Office').add('.Industrial').hide();	
        $('.tab-sorting th').removeClass('yellow-color green-color brown-color').addClass('yellow-color');
        $('.data-list li').removeClass('yellow-color reen-color brown-color').addClass('yellow-color');        
        barChart();
    });
    //Industrial data functin 
    $('.brown-color').click(function () {
        sourcePrimeRentm2pa = [];
        sourcePrimeRentmQoQ = [];
        sourcePrimeYield = [];
        sourceYieldShift = [];
        selectedTab = "Industrial";
        if (currentMode == "Table") {
            $('.Industrial').show();
        } else if (currentMode == "Chart") {
            $('.Industrial').show();
            $('.Industrial').each(function () {
                if (!$(this).hasClass("gray-color")) { $(this).hide() }
            });
            //For Percent Conversion
            calcfunction();
        }
        $('.Retail').add('.Office').hide();

        $('.tab-sorting th').removeClass('yellow-color green-color brown-color').addClass('brown-color');
        $('.data-list li').removeClass('yellow-color reen-color brown-color').addClass('brown-color');
        barChart();
    });
    //Active
    $("#myTable tbody").on( "click", "tr",function () {
        if (currentMode == "Chart") { return false; }
        var selectedCountry = $(this).find(".countryClass").text();
        $(".Office").each(function () {
            if ($(this).find(".countryClass").text() == selectedCountry) {
                $(this).toggleClass("gray-color");
            }
        });
        $(".Retail").each(function () {
            if ($(this).find(".countryClass").text() == selectedCountry) {
                $(this).toggleClass("gray-color");
            }
        });
        $(".Industrial").each(function () {
            if ($(this).find(".countryClass").text() == selectedCountry) {
                $(this).toggleClass("gray-color");
            }
        });
        //For Chart Tab
        var selectedCount = $(".gray-color").length / 3;
		console.log($(".gray-color").length+" "+selectedCount);
        if (selectedCount <= 1 || selectedCount >= 16) {
            $(".chart-click").hide();
        }else {
            $(".chart-click").show();
        }
    });
    //Active 
    //chart click function 
    $('.bar-chart').hide();
    $('.chart-click').click(function () {
        sourcePrimeRentm2pa = [];
        sourcePrimeRentmQoQ = [];
        sourcePrimeYield = [];
        sourceYieldShift = [];
        currentMode = "Chart";
        $('.bar-chart').show();
        //Show only previously selected tab	
        calcfunction();
        barChart();
    });
	$("#myTable").tablesorter({ sortMultiSortKey: 'altKey'});
	$(".clear-selection").click(function () {
		$(".table-click").trigger("click");
		$(".data-list tr").removeClass("gray-color");
		$(".chart-click").hide(100);
		$(".data-list td").find("strong").removeClass("text_right").addClass("text_left");
    });
});
//bar chart function 
function barChart(){
	$('.bar-chart li').each(function(){
		var value = parseInt($(this).find(".chart_value").text());
		$(this).animate({ width : (value) + 'px' }, 1000);
	});
};
function percent(array) {
    var i, max = 0;
    for (i = 0; i < array.length; i++)
        if (array[i] > max) max = array[i];
    for (i = 0; i < array.length; i++)
        array[i] = array[i] * 100 / max;
    return array;
}
function calcfunction(){
	$('.Retail').add('.Industrial').add('.Office').hide();
	$(eval("\"." + selectedTab + "\"")).each(function () {
		if ($(this).hasClass("gray-color")) {
			$(this).show();
			sourcePrimeRentm2pa.push(($(this).find("td").eq(1).find("strong").text()) * (1));
			sourcePrimeRentmQoQ.push(($(this).find("td").eq(2).find("strong").text()) * (1));
			sourcePrimeYield.push(($(this).find("td").eq(3).find("strong").text()) * (1));
			sourceYieldShift.push(($(this).find("td").eq(4).find("strong").text()) * (1));
		};
	});
	sourcePrimeRentm2pa = percent(sourcePrimeRentm2pa);
	var selectedCount = 0;
	$(eval("\"." + selectedTab + "\"")).each(function (i, val) {
		if ($(this).hasClass("gray-color")) {
			$(this).find("td").eq(1).find(".chart_value").text(sourcePrimeRentm2pa[selectedCount]);
		$(this).find("td").eq(2).find(".chart_value").text(sourcePrimeRentmQoQ[selectedCount]<0?(sourcePrimeRentmQoQ[selectedCount]*(-1)):sourcePrimeRentmQoQ[selectedCount]);
		if(sourcePrimeRentmQoQ[selectedCount]<0){
			$(this).find("td").eq(2).find(".prime_rent_negval").show();
			$(this).find("td").eq(2).find(".prime_rent").hide();
			$(this).find("td").eq(2).find("strong").removeClass("text_left").addClass("text_right");
		} else {
			$(this).find("td").eq(2).find(".prime_rent_negval").hide();
			$(this).find("td").eq(2).find(".prime_rent").show();
		}
		$(this).find("td").eq(3).find(".chart_value").text(sourcePrimeYield[selectedCount]<0?(sourcePrimeYield[selectedCount]*(-1)):sourcePrimeYield[selectedCount]);
		if(sourcePrimeYield[selectedCount]<0){
			$(this).find("td").eq(3).find(".prime_rent_negval").show();
			$(this).find("td").eq(3).find(".prime_rent").hide();
			$(this).find("td").eq(3).find("strong").removeClass("text_left").addClass("text_right");
		} else {
			$(this).find("td").eq(3).find(".prime_rent_negval").hide();
			$(this).find("td").eq(3).find(".prime_rent").show();
		}
		$(this).find("td").eq(4).find(".chart_value").text(sourceYieldShift[selectedCount]<0?(sourceYieldShift[selectedCount]*(-1)):sourceYieldShift[selectedCount]);
		if(sourceYieldShift[selectedCount]<0){
			$(this).find("td").eq(4).find(".prime_rent_negval").show();
			$(this).find("td").eq(4).find(".prime_rent").hide();
			$(this).find("td").eq(4).find("strong").removeClass("text_left").addClass("text_right");
			var valSourceYieldShift = sourceYieldShift[selectedCount]<0?(sourceYieldShift[selectedCount]*(-1)):sourceYieldShift[selectedCount];
			if(valSourceYieldShift>85){valSourceYieldShift = 85;}
			console.log(valSourceYieldShift);
			$(this).find("td").eq(4).find(".prime_rent_negval").find(".chart_value").text(valSourceYieldShift);
		} else {
			$(this).find("td").eq(4).find(".prime_rent_negval").hide();
			$(this).find("td").eq(4).find(".prime_rent").show();
		}
		selectedCount++;
		}
	});
}