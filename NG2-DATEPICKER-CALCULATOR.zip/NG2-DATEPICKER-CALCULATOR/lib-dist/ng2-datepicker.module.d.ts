export { DatePickerOptions, DateModel } from './ng2-datepicker.component';
export declare class DatePickerModule {
}
