angular.module('myApp',[]).controller('BIReports',function($scope,$http,$window,$timeout){
	
	// Report Format list
	$http.get("/sites/17079/_api/Web/Lists/GetByTitle('Report Format')/Items").then(function(response){
		$scope.ReportFormatList = response.data.value;
	});
	
	// Service Line list
	$http.get("/sites/17079/_api/Web/Lists/GetByTitle('Service Line')/Items").then(function(response){
		$scope.ServiceLineList = response.data.value;
	});

	// Data Source
	$http.get("/sites/17079/_api/Web/Lists/GetByTitle('Data Source')/Items").then(function(response){
		$scope.DataSourceList = response.data.value;
	});

	// Account Name
	$http.get("/sites/17079/_api/Web/Lists/GetByTitle('Account Name')/Items").then(function(response){
		$scope.AccountNameList = response.data.value;
	});

	//  Feature slier
	$http.get("/sites/17079/_api/Web/Lists/GetByTitle('Reports')/Items?$expand=ServiceLine&$select=ServiceLine/Title,ServiceLine/Id,Title,Description,LikeCount,LogoImage/Url&$Filter=FeatureSlider eq 1").then(function(response){
		$scope.FeatureSlierList = response.data.value;
	});

	//  Category slier
	$http.get("/sites/17079/_api/Web/Lists/GetByTitle('Service Line')/Items").then(function(response){
		$scope.CategorySlierList = response.data.value;
	});
	
	//  Contacts Region
	$http.get("/sites/17079/_api/Web/Lists/GetByTitle('Regions')/Items").then(function(response){
		$scope.ContactsRegionList = response.data.value;
	});

	//  Contacts Full
	$http.get("/sites/17079/_api/Web/Lists/GetByTitle('Contacts')/Items?$expand=Region&$select=Region/Title,Region/Id,Title,Description,MailId,LinkedIn,ImagePath/Url").then(function(response){
		$scope.ContactsList = response.data.value;
	});

	// Gategory count
	$http.get("/sites/17079/_api/Web/Lists/GetByTitle('Service Line')/Items").then(function(response){
		//console.log("length="+response.data.value.length);
		var cateItemCount = response.data.value.length
		for(i=1; i <= cateItemCount; i++){
			var j = 0;
			var url = "/sites/17079/_api/Web/Lists/GetByTitle('Reports')/Items?$filter=ServiceLineId eq ";
			$http.get(url+i).then(function(itemCount){
				var count = itemCount.data.value.length; 
				//console.log("ind-Count="+count);
				var ClassName = document.getElementsByClassName("totalCount");
				ClassName[j].innerHTML=count;
				j++;
				//console.log("j="+j);
			});
		}
	});

	/*var categoryArray = [];
	$http.get("/sites/17079/_api/Web/Lists/GetByTitle('Service Line')/Items?$select=Title").then(function(response){
		var TotalLength = response.data.value.length;
		for(j=0; j < TotalLength; j++){
			categoryArray.push(response.data.value[j].Title);
		}
	});
	$http.get("/sites/17079/_api/Web/Lists/GetByTitle('Reports')/Items?$expand=ServiceLine&$select=ServiceLine/Title").then(function(response1){
		var TotalLength1 = response1.data.value.length;
		for(k=0; k < TotalLength1; k++){
			categoryArray.push(response1.data.value[k].ServiceLine.Title);
		}
	});
	$window.onload = function(){
		$scope.itemCount = [];
		categoryArray.sort();
		var current = null;
		var cnt = 0;  
		for (var i = 0; i < categoryArray.length; i++) {
			if (categoryArray[i] != current) {
				if (cnt > 0) {
					$scope.itemCount.push(cnt);
				}
				current = categoryArray[i];
				cnt = 1;
			} else {
				cnt++;
			}
		}
		if (cnt > 0) {
			$scope.itemCount.push(cnt);
		}

		$scope.arrayLength =  $scope.itemCount.length;
		console.log($scope.itemCount);

        		
	}*/
	var searchPageUrl = 'https://jll2.sharepoint.com/sites/17079/SiteAssets/BI-Report/search-report.aspx'
	$scope.searchpage = function(){
		var searchWord = document.getElementById('searhbox').value;
		var rfValue = document.getElementById('RF-val').value;
		var slValue = document.getElementById('SL-val').value;
		var dsValue = document.getElementById('DS-val').value;
		var anValue = document.getElementById('AN-val').value;
		if(searchWord != '' || rfValue != '' ||  slValue != '' ||  dsValue != '' ||  anValue != ''){
			window.location.href='search-report.aspx?kw='+searchWord+'&rf='+rfValue+'&sl='+slValue+'&ds='+dsValue+'&an='+anValue;
		}else{
			alert("Please select any one field");
		}
	}
})
