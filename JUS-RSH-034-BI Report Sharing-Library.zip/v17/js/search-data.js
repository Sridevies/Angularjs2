angular.module('myApp',[]).controller('BISearch',function($scope,$http,$window,$compile){
	// Report Format list
	$http.get("/sites/17079/_api/Web/Lists/GetByTitle('Report Format')/Items").then(function(response){
		$scope.ReportFormatList = response.data.value;
	});
	
	// Service Line list
	$http.get("/sites/17079/_api/Web/Lists/GetByTitle('Service Line')/Items").then(function(response){
		$scope.ServiceLineList = response.data.value;
	});

	// Data Source
	$http.get("/sites/17079/_api/Web/Lists/GetByTitle('Data Source')/Items").then(function(response){
		$scope.DataSourceList = response.data.value;
	});

	// Account Name
	$http.get("/sites/17079/_api/Web/Lists/GetByTitle('Account Name')/Items").then(function(response){
		$scope.AccountNameList = response.data.value;
	});
	
	$window.onload = function(){
		//------FORM Validation----		
		var QueryString = function () {
			// This function is anonymous, is executed immediately and 
			// the return value is assigned to QueryString!
			var query_string = {};
			var query = window.location.search.substring(1);
			var vars = query.split("&");
			for (var i=0;i<vars.length;i++) {
			var pair = vars[i].split("=");
				// If first entry with this name
			if (typeof query_string[pair[0]] === "undefined") {
			  query_string[pair[0]] = decodeURIComponent(pair[1]);
				// If second entry with this name
			} else if (typeof query_string[pair[0]] === "string") {
			  var arr = [ query_string[pair[0]],decodeURIComponent(pair[1]) ];
			  query_string[pair[0]] = arr;
				// If third or later entry with this name
			} else {
			  query_string[pair[0]].push(decodeURIComponent(pair[1]));
			}
			} 
			return query_string;
		}();
		// QueryString.kw
		/*document.getElementById("searhbox").value=QueryString.kw;
		document.getElementById("RF-val").value=QueryString.rf;
		document.getElementById("SL-val").value=QueryString.sl;
		document.getElementById("DS-val").value=QueryString.ds;
		document.getElementById("AN-val").value=QueryString.an;*/

		
		$("#searhbox").val(QueryString.kw);
		$("#RF-val").val(QueryString.rf);
		$("#SL-val").val(QueryString.sl);
		$("#DS-val").val(QueryString.ds);
		$("#AN-val").val(QueryString.an); 
	
		setTimeout(function(){
			$("#RFscrollbar li:eq("+QueryString.rf+")").trigger("click"); 
			$("#SLscrollbar li:eq("+QueryString.sl+")").trigger("click");
			$("#DSscrollbar li:eq("+QueryString.ds+")").trigger("click");
			$("#ANscrollbar li:eq("+QueryString.an+")").trigger("click");

			$("#RFscrollbar li").click(function(){
				var rfVal = $(this).attr("rel");
				$("#RF-val").val(rfVal);
			});
			$("#SLscrollbar li").click(function(){
				var slVal = $(this).attr("rel");
				$("#SL-val").val(slVal);
			});
			$("#DSscrollbar li").click(function(){
				var dsVal = $(this).attr("rel");
				$("#DS-val").val(dsVal);
			});
			$("#ANscrollbar li").click(function(){
				var anVal = $(this).attr("rel");
				$("#AN-val").val(anVal);
			});
		},3000);
		setTimeout(function(){
			showingResultText();
		},3200);		
		setTimeout(function(){
			document.getElementById("updateSearch").click();
		},3500);		
		
	};
	$scope.searchUpdate = function(){
		var searchWord = document.getElementById('searhbox').value;
		var rfValue = document.getElementById('RF-val').value;
		var slValue = document.getElementById('SL-val').value;
		var dsValue = document.getElementById('DS-val').value;
		var anValue = document.getElementById('AN-val').value;

		var listURLwithFilter = "/sites/17079/_api/Web/Lists/GetByTitle('Reports')/Items?$expand=ReportFormat,ServiceLine,DataSourcesUsedToGenerateReport,AccountName&$select=ID,Description,BusinessQuestionThisReportAnswer,DataCaptureProcess,Example,ReportLocation,DeliveryMethod,PrimaryReportConsumer,InternalJLLAccountTeamFacing,ExternalClientFacing,BusinessOwner,ReportCreator,FrequencyUpdatedDelivered,OngoingEffortToGenerateReport,TotalHoursToProduceInitially,WhatIssuesAreThereWithTheReport,AllMetrics,DocumentationExists,OtherNotes,ReportImportance,Keywords,LogoImage,PDFPath,LikeCount,ReportFormat/Title,ReportFormat/Id,Title,ServiceLine/Title,ServiceLine/Id,Title,DataSourcesUsedToGenerateReport/Title,DataSourcesUsedToGenerateReport/Id,Title,AccountName/Title,AccountName/Id,Title&$filter=({filterqry})";
		if(searchWord != '' || rfValue != '' ||  slValue != '' ||  dsValue != '' ||  anValue != ''){
			//alert("Working");	
			$(".search-overlay").show();
			$(".search-loadImg").fadeIn();
			               
			var filterQuery = "{titlefilter}{rffilter}{slfilter}{dsfilter}{anfilter}";

			// For Report Title
			if(searchWord){
				   filterQuery = filterQuery.replace("{titlefilter}","Title eq '"+searchWord+"' and ");
			}else{
				   filterQuery = filterQuery.replace("{titlefilter}","");
			}
			
			// For Report Format
			if(rfValue){
				   filterQuery = filterQuery.replace("{rffilter}","ReportFormatId eq '"+rfValue+"' and ");
			}else{
				   filterQuery = filterQuery.replace("{rffilter}","");
			}
			
			// For Service LIne
			if(slValue){
				   filterQuery = filterQuery.replace("{slfilter}","ServiceLineId eq '"+slValue+"' and ");
			}else{
				   filterQuery = filterQuery.replace("{slfilter}","");
			}
			
			// For Data Source
			if(dsValue){
				   filterQuery = filterQuery.replace("{dsfilter}","DataSourcesUsedToGenerateReportId eq '"+dsValue+"' and ");
			}else{
				   filterQuery = filterQuery.replace("{dsfilter}","");
			}
			
			// For Account Name
			if(anValue){
				   filterQuery = filterQuery.replace("{anfilter}","AccountNameId eq '"+anValue+"' and ");
			}else{
				   filterQuery = filterQuery.replace("{anfilter}","");
			}
			filterQuery = filterQuery.substring(0,filterQuery.length-5);
			listURLwithFilter = listURLwithFilter.replace("{filterqry}",filterQuery);
			//console.log(listURLwithFilter);
			var selectText = $(".selectText").text();
			if(selectText == 'Alphabetically'){
				$http.get(listURLwithFilter+'&$orderby=Title asc').then(function(searhQueryResponse){
					$scope.searchData = searhQueryResponse.data.value;
					//console.log(searhQueryResponse.data);
				});
			}else{
				$http.get(listURLwithFilter+'&$orderby=LikeCount desc').then(function(searhQueryResponse){
					$scope.searchData = searhQueryResponse.data.value;
					//console.log(searhQueryResponse.data);
				});
			}
			//For top4 slider
			$http.get(listURLwithFilter+'&$top=4&$orderby=LikeCount desc').then(function(sliderquery){
				$scope.sliderData = sliderquery.data.value;
			});
			
			//For Related Searcch
			$http.get("/sites/17079/_api/Web/Lists/GetByTitle('Reports')/Items?$expand=ReportFormat,ServiceLine,DataSourcesUsedToGenerateReport,AccountName&$select=ID,Description,BusinessQuestionThisReportAnswer,DataCaptureProcess,Example,ReportLocation,DeliveryMethod,PrimaryReportConsumer,InternalJLLAccountTeamFacing,ExternalClientFacing,BusinessOwner,ReportCreator,FrequencyUpdatedDelivered,OngoingEffortToGenerateReport,TotalHoursToProduceInitially,WhatIssuesAreThereWithTheReport,AllMetrics,DocumentationExists,OtherNotes,ReportImportance,Keywords,LogoImage,PDFPath,LikeCount,ReportFormat/Title,ReportFormat/Id,Title,ServiceLine/Title,ServiceLine/Id,Title,DataSourcesUsedToGenerateReport/Title,DataSourcesUsedToGenerateReport/Id,Title,AccountName/Title,AccountName/Id,Title").then(function(relatedsearch){
				$scope.relatedData = relatedsearch.data.value;
			});
			$scope.relatedFilterQuery();
			$(".slick-slider .slides").slick('unslick');
			setTimeout(function(){
				$(".grid").isotope( 'reloadItems' ).isotope();
				showingResultText();
				//$('.flexslider').resize();
				//$(".slick-slider .slides").slick() 
				$('.slick-slider .slides').slick({
					dots: true,
					prevArrow: false,
					nextArrow: false
				});	
				$(document).resize();
				if ($('.slides li').length == 0){
					$('.grid').hide();
					$('.Noresult').show();
				}else{
					$('.grid').show();
					$('.Noresult').hide();
				}
				var searchText = $(".getResultText").text().trim();
				var trimRemove = searchText.substring(0, searchText.length -1).trim();
				$(".resultText").text(" ").text(trimRemove);
			},1500);
			setTimeout(function(){
				$(".search-loadImg").fadeOut();	
				$(".search-overlay").fadeOut();
			},4000);
			
		}else{
			alert("Please select any one field"); 
			$(".search-overlay").hide();
			$(".search-loadImg").hide();
		}
	}
	$(".result-sort li").click(function(){
		var sortText = $(this).text();
		$(".selectText").text(sortText);
		$("#updateSearch").trigger("click");
	});

	$scope.relatedFilterQuery = function(){
		relatedFilter();		
		$scope.filterKW = $("#filterKW").val();
		$scope.filterRF = $("#filterRF").val();
		$scope.filterSL = $("#filterSL").val();
		$scope.filterDS = $("#filterDS").val();
		$scope.filterAN = $("#filterAN").val();
	}
});

function relatedFilter(){
	var filterKW = $("#searhbox").val();
	$("#filterKW").val(filterKW);
	
	//console.log("functin enter")
	
	var filterRF = $('#ddrf').text();
	if(filterRF == 'Report Format'){
		$('#filterRF').val('');
		//console.log("val empty chk :" + filterRF)
	}else{
		$('#filterRF').val('');
		$('#filterRF').val($('#ddrf').text().trim());	
		//console.log($('#filterRF').val(filterRF));		
	}
	
	var filterSL = $('#ddsl').text();
	if(filterSL == 'Service Line'){
		$('#filterSL').val('');	
	}else{
		$('#filterSL').val('');	
		$('#filterSL').val($('#ddsl').text().trim());
		//console.log($('#filterSL').val(filterSL));		
	}

	var filterDS = $('#ddds').text();
	if(filterDS == 'Data Source'){
		$('#filterDS').val('');	
	}else{
		$('#filterDS').val('');		
		$('#filterDS').val($('#ddds').text().trim());
		//console.log($('#filterDS').val(filterDS));		
	}
	
	var filterAN = $('#ddan').text();
	if(filterAN == 'Account Name'){
		$('#filterAN').val('');
	}else{
		$('#filterAN').val('');
		$('#filterAN').val($('#ddan').text().trim());	
		//console.log($('#filterAN').val(filterAN));		
	}
}
function showingResultText(){
	var searchText = $("#searhbox").val();
	if(searchText != ''){
		$("#searchkeyText").text(searchText+" / ");
	}else{
		$("#searchkeyText").text('');
	}
	
	var rfText = $(".dd-val:eq(0) p").text();
	if(rfText != 'Report Format'){
		$("#rfText").text(rfText+" / ");
	}else{
		$("#rfText").text('');
	}
	
	var slText = $(".dd-val:eq(1) p").text();
	if(slText != 'Service Line'){
		$("#slText").text(slText+" / ");
	} else{
		$("#slText").text('');
	}
	
	var dsText = $(".dd-val:eq(2) p").text();
	if(dsText != 'Data Source'){
		$("#dsText").text(dsText+" / ");
	}else{
		$("#dsText").text('');
	}
	
	var anText = $(".dd-val:eq(3) p").text();
	if(anText != 'Account Name'){
		$("#anText").text(anText+" / ");
	}else{
		$("#anText").text('');
	}
	
}