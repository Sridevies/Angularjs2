angular.module('myApp',['ngRoute']).controller('BISearch',function($scope,$http,$window,$q){
	// Report Format list
	$http.get("/sites/17079/_api/Web/Lists/GetByTitle('Report Format')/Items").then(function(response){
		$scope.ReportFormatList = response.data.value;
	});
	
	// Service Line list
	$http.get("/sites/17079/_api/Web/Lists/GetByTitle('Service Line')/Items").then(function(response){
		$scope.ServiceLineList = response.data.value;
	});

	// Data Source
	$http.get("/sites/17079/_api/Web/Lists/GetByTitle('Data Source')/Items").then(function(response){
		$scope.DataSourceList = response.data.value;
	});

	// Account Name
	$http.get("/sites/17079/_api/Web/Lists/GetByTitle('Account Name')/Items").then(function(response){
		$scope.AccountNameList = response.data.value;
	});
	
	$window.onload = function(){
		//------FORM Validation----		
		var QueryString = function () {
			// This function is anonymous, is executed immediately and 
			// the return value is assigned to QueryString!
			var query_string = {};
			var query = window.location.search.substring(1);
			var vars = query.split("&");
			for (var i=0;i<vars.length;i++) {
			var pair = vars[i].split("=");
				// If first entry with this name
			if (typeof query_string[pair[0]] === "undefined") {
			  query_string[pair[0]] = decodeURIComponent(pair[1]);
				// If second entry with this name
			} else if (typeof query_string[pair[0]] === "string") {
			  var arr = [ query_string[pair[0]],decodeURIComponent(pair[1]) ];
			  query_string[pair[0]] = arr;
				// If third or later entry with this name
			} else {
			  query_string[pair[0]].push(decodeURIComponent(pair[1]));
			}
			} 
			return query_string;
		}();
		// QueryString.kw
		/*document.getElementById("searhbox").value=QueryString.kw;
		document.getElementById("RF-val").value=QueryString.rf;
		document.getElementById("SL-val").value=QueryString.sl;
		document.getElementById("DS-val").value=QueryString.ds;
		document.getElementById("AN-val").value=QueryString.an;*/

		
		$("#searhbox").val(QueryString.kw);
		$("#RF-val").val(QueryString.rf);
		$("#SL-val").val(QueryString.sl);
		$("#DS-val").val(QueryString.ds);
		$("#AN-val").val(QueryString.an); 

		document.getElementById("updateSearch").click();	
		setTimeout(function(){
			$("#RFscrollbar li:eq("+QueryString.rf+")").trigger("click"); 
			$("#SLscrollbar li:eq("+QueryString.sl+")").trigger("click");
			$("#DSscrollbar li:eq("+QueryString.ds+")").trigger("click");
			$("#ANscrollbar li:eq("+QueryString.an+")").trigger("click");

			$("#RFscrollbar li").click(function(){
				var rfVal = $(this).attr("rel");
				$("#RF-val").val(rfVal);
			});
			$("#SLscrollbar li").click(function(){
				var slVal = $(this).attr("rel");
				$("#SL-val").val(slVal);
			});
			$("#DSscrollbar li").click(function(){
				var dsVal = $(this).attr("rel");
				$("#DS-val").val(dsVal);
			});
			$("#ANscrollbar li").click(function(){
				var anVal = $(this).attr("rel");
				$("#AN-val").val(anVal);
			});
		},2500);
		setTimeout(function(){
			showingResultText();
		},3000);
		
	};
	$scope.searchUpdate = function(){
		var searchWord = document.getElementById('searhbox').value;
		var rfValue = document.getElementById('RF-val').value;
		var slValue = document.getElementById('SL-val').value;
		var dsValue = document.getElementById('DS-val').value;
		var anValue = document.getElementById('AN-val').value;

		var listURLwithFilter = "/sites/17079/_api/Web/Lists/GetByTitle('Reports')/Items?$expand=ReportFormat,ServiceLine,DataSourcesUsedToGenerateReport,AccountName&$select=ID,Description,BusinessQuestionThisReportAnswer,DataCaptureProcess,Example,ReportLocation,DeliveryMethod,PrimaryReportConsumer,InternalJLLAccountTeamFacing,ExternalClientFacing,BusinessOwner,ReportCreator,FrequencyUpdatedDelivered,OngoingEffortToGenerateReport,TotalHoursToProduceInitially,WhatIssuesAreThereWithTheReport,AllMetrics,DocumentationExists,OtherNotes,ReportImportance,Keywords,LogoImage,PDFPath,LikeCount,ReportFormat/Title,ReportFormat/Id,Title,ServiceLine/Title,ServiceLine/Id,Title,DataSourcesUsedToGenerateReport/Title,DataSourcesUsedToGenerateReport/Id,Title,AccountName/Title,AccountName/Id,Title&$orderby=Title asc&$filter=({filterqry})";
		if(searchWord != '' || rfValue != '' ||  slValue != '' ||  dsValue != '' ||  anValue != ''){
			//alert("Working");
			               
			var filterQuery = "{titlefilter}{rffilter}{slfilter}{dsfilter}{anfilter}";

			// For Report Title
			if(searchWord){
				   filterQuery = filterQuery.replace("{titlefilter}","Title eq '"+searchWord+"' and ");
			}else{
				   filterQuery = filterQuery.replace("{titlefilter}","");
			}
			
			// For Report Format
			if(rfValue){
				   filterQuery = filterQuery.replace("{rffilter}","ReportFormatId eq '"+rfValue+"' and ");
			}else{
				   filterQuery = filterQuery.replace("{rffilter}","");
			}
			
			// For Service LIne
			if(slValue){
				   filterQuery = filterQuery.replace("{slfilter}","ServiceLineId eq '"+slValue+"' and ");
			}else{
				   filterQuery = filterQuery.replace("{slfilter}","");
			}
			
			// For Data Source
			if(dsValue){
				   filterQuery = filterQuery.replace("{dsfilter}","DataSourcesUsedToGenerateReportId eq '"+dsValue+"' and ");
			}else{
				   filterQuery = filterQuery.replace("{dsfilter}","");
			}
			
			// For Account Name
			if(anValue){
				   filterQuery = filterQuery.replace("{anfilter}","AccountNameId eq '"+anValue+"' and ");
			}else{
				   filterQuery = filterQuery.replace("{anfilter}","");
			}
			filterQuery = filterQuery.substring(0,filterQuery.length-5);
			listURLwithFilter = listURLwithFilter.replace("{filterqry}",filterQuery);
			//console.log(listURLwithFilter);
			
			$http.get(listURLwithFilter).then(function(searhQueryResponse){
				$scope.searchData = searhQueryResponse.data.value;
				//console.log(searhQueryResponse.data);
			});
			//For top4 slider

			//var myarray = []

			$http.get(listURLwithFilter+'&$top=4&$orderby=LikeCount desc').then(function(sliderquery){
				
				$scope.sliderData = sliderquery.data.value;
				$scope.log = [];
					
				angular.forEach($scope.sliderData, function(value, key) {
					//console.log(key + ': ' + value);
					$scope.myObj = {}
					$scope.myObj.myUrl = value.LogoImage.Url;
					$scope.myObj.myTitle = value.Title;
					$scope.myObj.myCount = value.LikeCount;
					//console.log(log.push($scope.myObj))
					$scope.log.push($scope.myObj);
				});
				//console.log($scope.log);
			});

			$http.get("/sites/17079/_api/Web/Lists/GetByTitle('Service Line')/Items").then(function(sliderquery){
				//console.log(sliderquery.data);
			});
			$http.get("/sites/17079/_api/Web/Lists/GetByTitle('Reports')/Items").then(function(sliderquery){
				//alert("y")
				//console.log(sliderquery);
			});





			// Two List data 
			var serviceLineArray = $http.get("/sites/17079/_api/Web/Lists/GetByTitle('Service Line')/Items"),
				reportsArray = $http.get("/sites/17079/_api/Web/Lists/GetByTitle('Reports')/Items");

			// Data manuplation
			$q.all([serviceLineArray, reportsArray]).then(function(arrayOfResults) {

				$scope.serviceLineList = arrayOfResults[0].data.value;// list One
				$scope.reportsList = arrayOfResults[1].data.value;// list Two


				//slide data array object
				$scope.serviceLine = [];
				
				// Get the data from Service line list, Create object and push in to service Line array
				angular.forEach($scope.serviceLineList, function(value, key) {

						$scope.newObj = {} // empty Obj
						$scope.newObj.sTitle = value.Title;
						$scope.newObj.sDescription = value.Description;
						$scope.newObj.sId = value.Id;
						$scope.newObj.viewCount = 0;

						$scope.serviceLine.push($scope.newObj);
				});

				// Report Serviec Line Id push to array
				var reportServiceLineId =  [];

				// Get the service line id from Report list & push in to array
				angular.forEach($scope.reportsList, function(value, key){
					reportServiceLineId.push(value.ServiceLineId)
				});

				//find the repeated Object function
				var keyArray = repeatObj(reportServiceLineId);

				//assain the view count vaue in the array obj
				$.each(keyArray[0],function(aKey, aValue){
					//array obj each
					$.each($scope.serviceLine, function(aoKey, aoValue){
						if(aValue == aoValue.sId){
							console.log(keyArray[1][aKey]);
							$scope.serviceLine[aoKey]['viewCount'] = keyArray[1][aKey];
						}
					})
				});
				console.log($scope.serviceLine);
				
			});


			


			
			setTimeout(function(){
				$(".grid").isotope( 'reloadItems' ).isotope();
				showingResultText();
				//alert();
				/*$(".slick-slider ul").slick();*/
			},1500); 
		}else{
			alert("Please select any one field");
		}
	}
});

// Get repeat item in a array
function repeatObj(arr) {
	var a = [], b = [], prev; 
	console.log(prev);
	arr.sort();
	for ( var i = 0; i < arr.length; i++ ) {
		if ( arr[i] !== prev ) {
			a.push(arr[i]);
			b.push(1);
		} else {
			b[b.length-1]++;
		}
		prev = arr[i];
	}	
	return [a, b];
}


function showingResultText(){
	var searchText = $("#searhbox").val();
	if(searchText != ''){
		$("#searchkeyText").text(searchText+" / ");
	}else{
		$("#searchkeyText").text('');
	}
	
	var rfText = $(".dd-val:eq(0) p").text();
	if(rfText != 'Report Format'){
		$("#rfText").text(rfText+" / ");
	}else{
		$("#rfText").text('');
	}
	
	var slText = $(".dd-val:eq(1) p").text();
	if(slText != 'Service Line'){
		$("#slText").text(slText+" / ");
	} else{
		$("#slText").text('');
	}
	
	var dsText = $(".dd-val:eq(2) p").text();
	if(dsText != 'Data Source'){
		$("#dsText").text(dsText+" / ");
	}else{
		$("#dsText").text('');
	}
	
	var anText = $(".dd-val:eq(3) p").text();
	if(anText != 'Account Name'){
		$("#anText").text(anText+" / ");
	}else{
		$("#anText").text('');
	}
}

/*
	$(window).load(function(){
		$('.like-bt').click(function() {
			alert("d");
			$(this).html(function(i, val) { return val*1+1 });
		});
	});
*/