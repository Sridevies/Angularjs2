angular.module('myApp',[]).controller('BIReports',function($scope,$http,$window,$timeout,$q){
	
	$http.get("/sites/17079/_api/Web/currentUser?$select=Title,LoginName,Id").then(function(response){
		console.log(response);
		$scope.UserID = response.data;
	});

	// Report Format list
	$http.get("/sites/17079/_api/Web/Lists/GetByTitle('Report Format')/Items").then(function(response){
		$scope.ReportFormatList = response.data.value;
	});
	
	// Service Line list
	$http.get("/sites/17079/_api/Web/Lists/GetByTitle('Service Line')/Items").then(function(response){
		$scope.ServiceLineList = response.data.value;
	});

	// Data Source
	$http.get("/sites/17079/_api/Web/Lists/GetByTitle('Data Source')/Items").then(function(response){
		$scope.DataSourceList = response.data.value;
	});

	// Account Name
	$http.get("/sites/17079/_api/Web/Lists/GetByTitle('Account Name')/Items").then(function(response){
		$scope.AccountNameList = response.data.value;
	});

	//  Feature slier
	$http.get("/sites/17079/_api/Web/Lists/GetByTitle('Reports')/Items?$expand=AttachmentFiles,ReportFormat,ServiceLine,DataSourcesUsedToGenerateReport,AccountName&$select=ReportFormat/Title,ReportFormat/Id,ServiceLine/Title,ServiceLine/Id,DataSourcesUsedToGenerateReport/Id,DataSourcesUsedToGenerateReport/Title,AccountName/Id,AccountName/Title,Id,Title,Description,LikeCount,LogoImage/Url,EditorId,AttachmentFiles&$Filter=FeatureSlider eq 1").then(function(response){
		$scope.FeatureSlierList = response.data.value;
	});

	//  Category slier
	$http.get("/sites/17079/_api/Web/Lists/GetByTitle('Service Line')/Items").then(function(response){
		$scope.CategorySlierList = response.data.value;
	});
	
	//  Contacts Region
	$http.get("/sites/17079/_api/Web/Lists/GetByTitle('Regions')/Items").then(function(response){
		$scope.ContactsRegionList = response.data.value;
	});

	//  Contacts Full
	$http.get("/sites/17079/_api/Web/Lists/GetByTitle('Contacts')/Items?$expand=Region&$select=Region/Title,Region/Id,Title,Description,MailId,LinkedIn,ImagePath/Url").then(function(response){
		$scope.ContactsList = response.data.value;
	});

	// Gategory count
	/*$http.get("/sites/17079/_api/Web/Lists/GetByTitle('Service Line')/Items").then(function(response){
		//console.log("length="+response.data.value.length);
		var cateItemCount = response.data.value.length
		for(i=1; i <= cateItemCount; i++){
			var j = 0;
			var url = "/sites/17079/_api/Web/Lists/GetByTitle('Reports')/Items?$filter=ServiceLineId eq ";
			$http.get(url+i).then(function(itemCount){
				var count = itemCount.data.value.length; 
				//console.log("ind-Count="+count);
				var ClassName = document.getElementsByClassName("totalCount");
				ClassName[j].innerHTML=count;
				j++;
				//console.log("j="+j);
			});
		}
	});*/

	
	var searchPageUrl = 'https://jll2.sharepoint.com/sites/17079/SiteAssets/BI-Report/search-report.aspx'
	$scope.searchpage = function(){
		var searchWord = document.getElementById('searhbox').value;
		var rfValue = document.getElementById('RF-val').value;
		var slValue = document.getElementById('SL-val').value;
		var dsValue = document.getElementById('DS-val').value;
		var anValue = document.getElementById('AN-val').value;
		if(searchWord != '' || rfValue != '' ||  slValue != '' ||  dsValue != '' ||  anValue != ''){
			window.location.href='search-report.aspx?kw='+searchWord+'&rf='+rfValue+'&sl='+slValue+'&ds='+dsValue+'&an='+anValue;
		}else{
			alert("Search criteria cannot be empty");
		}
	}



	// Two List data 
	var serviceLineArray = $http.get("/sites/17079/_api/Web/Lists/GetByTitle('Service Line')/Items"),
		reportsArray = $http.get("/sites/17079/_api/Web/Lists/GetByTitle('Reports')/Items");
	// Data manuplation
	$q.all([serviceLineArray, reportsArray]).then(function(arrayOfResults) {

		$scope.serviceLineList = arrayOfResults[0].data.value;// list One
		$scope.reportsList = arrayOfResults[1].data.value;// list Two


		//slide data array object
		$scope.categoryDetails = [];
		
		// Get the data from Service line list, Create object and push in to service Line array
		angular.forEach($scope.serviceLineList, function(value, key) {

				$scope.newObj = {} // empty Obj
				$scope.newObj.sTitle = value.Title;
				$scope.newObj.sDescription = value.Description;
				$scope.newObj.sId = value.Id;
				$scope.newObj.viewCount = 0;

				$scope.categoryDetails.push($scope.newObj);
		});

		// Report Serviec Line Id push to array
		var reportServiceLineId =  [];

		// Get the service line id from Report list & push in to array
		angular.forEach($scope.reportsList, function(value, key){
			reportServiceLineId.push(value.ServiceLineId)
		});

		//find the repeated Object function
		var keyArray = repeatObj(reportServiceLineId);

		//assain the view count vaue in the array obj
		$.each(keyArray[0],function(aKey, aValue){
			//array obj each
			$.each($scope.categoryDetails, function(aoKey, aoValue){
				if(aValue == aoValue.sId){
					console.log(keyArray[1][aKey]);
					$scope.categoryDetails[aoKey]['viewCount'] = keyArray[1][aKey];
				}
			})
		});
		console.log($scope.categoryDetails);
		
	});

	setTimeout(function(){
		$(".removeLink").attr("href"," ").css({"cursor":"text"})
		$(".like-bt").each(function(){
			console.log($(this).find(".cnt").text());
			if($(this).find(".cnt").text()==0){
				$(this).removeClass("like-active")
			}
		});
		$(".like-bt").click(function(){
			var getCnt = parseInt($(this).find(".cnt").text());
			var ItemId = $(this).attr("rel");
			if(!$(this).hasClass("like-active")){
				getCnt = getCnt+1;				
				$(this).find(".cnt").text(getCnt);
				$(this).addClass("like-active");
				updateList(getCnt,ItemId);
				//console.log("Add")
			}else {
				$(this).removeClass("like-active");
				getCnt = getCnt-1
				$(this).find(".cnt").text(getCnt);
				updateList(getCnt,ItemId);
				//console.log("Remove")
			}
			
		});
	},3000);
});
// Get repeat item in a array
function repeatObj(arr) {
	var a = [], b = [], prev; 
	console.log(prev);
	arr.sort();
	for ( var i = 0; i < arr.length; i++ ) {
		if ( arr[i] !== prev ) {
			a.push(arr[i]);
			b.push(1);
		} else {
			b[b.length-1]++;
		}
		prev = arr[i];
	}	
	return [a, b];
}

function updateList(getCnt,ItemId){
	var inputData = {};
		inputData.__metadata = {};
		inputData.__metadata.type = 'SP.Data.ReportsListItem';
		inputData.LikeCount = getCnt;
		$.ajax  ({
			url: "/sites/17079/_api/Web/Lists/GetByTitle('Reports')/items('"+ItemId+"')", // list item ID
			type: "POST",
			data: JSON.stringify(inputData), 
			headers:{
				"Accept": "application/json;odata=verbose",
				"Content-Type": "application/json;odata=verbose",
				"X-RequestDigest": $("#__REQUESTDIGEST").val(),
				"IF-MATCH": "*",
				"X-HTTP-Method": "MERGE"
			},
			success: function(data, status, xhr){ 
				getListItems(url, listname);
			},
			error: function(xhr, status, error){  
				//$("#ResultDiv").empty().text(data.responseJSON.error);  
			}
		});
}




////////////// For list upadte (Like)//////////////
function getListItemType(Reports) {
	return"SP.Data." + Reports[0].toUpperCase() + Reports.substring(1) + "ReportsListItem";
} 
// Getting list items based on ODATA Query
var url = '/sites/17079/';
var listname = 'Reports';
//var query = '?$select=Title,LikesCount,likecount,LikedBy/Title&$expand=LikedBy';
//var id = "(1)";
var success = 'sucess';
var failure = 'failure';
function getListItems(url, listname) {
	$.ajax({
		url: url + "_api/Web/Lists/GetByTitle('" + listname + "')/items",
		method: "GET",
		headers: { "Accept": "application/json; odata=verbose" },
		success: function (data) {
		},
		error: function (data) {
			console.log("Error");
		}
	});

}
getListItems(url, listname);

function updateListItem()  
{  
	var inputData = {};
	inputData.__metadata = {};
	inputData.__metadata.type = 'SP.Data.ReportsListItem';
	inputData.LikeCount = '12';
	$.ajax  
	({  
		url: "/sites/17079/_api/Web/Lists/GetByTitle('Reports')/items(2)", // list item ID  
		type: "POST",  
		data: JSON.stringify(inputData),  
		headers:  
		{  
			"Accept": "application/json;odata=verbose",  
			"Content-Type": "application/json;odata=verbose",  
			"X-RequestDigest": $("#__REQUESTDIGEST").val(),  
			"IF-MATCH": "*",  
			"X-HTTP-Method": "MERGE"  
		},  
		success: function(data, status, xhr)  
		{ 
			getListItems(url, listname);  
		},  
		error: function(xhr, status, error)  
		{  
			//$("#ResultDiv").empty().text(data.responseJSON.error);  
		}  
	});
}

	

