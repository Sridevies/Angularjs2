$(window).load(function(){
	$("body").css({"overflow":"auto"});
	$(".overlay").fadeOut(600);
	$(".loading").fadeOut(500);
	new WOW().init();

	$(".location-nav h4").click(function(event){
		event.stopPropagation();
		$(".location-nav .dd-box").slideToggle();
	});		
	$(document).click(function (e){
		var container = $("ul.dropDown");
		var containerSearch = $(".dropdown");
		var searchSelectBox = $(".dd-val").find(".bgm");
		var searchSelectArrow = $(".dd-val").find(".down-arrow");
		if (!container.is(e.target) && container.has(e.target).length === 0 || !containerSearch.is(e.target) && containerSearch.has(e.target).length === 0 || !searchSelectBox.is(e.target) && searchSelectBox.has(e.target).length === 0 || !searchSelectArrow.is(e.target) && searchSelectArrow.has(e.target).length === 0){
			//$(".nicescroll-rails").hide();
			searchSelectBox.removeClass("drop-active");
			searchSelectArrow.removeClass("drop-active-arrow");
			container.slideUp();
			containerSearch.slideUp();
			containerSearch.removeClass("active-drop");	
		};	
		$(".dd-box").slideUp();
	});
		
	$(".seasechList .clickFn .dd-val").click(function(event){
		$('#RFscrollbar,#SLscrollbar,#DSscrollbar,#ANscrollbar').scrollTop(0);
		event.stopPropagation();
		$(".dropdown").slideUp();
		$(".bgm").removeClass("drop-active");
		$(".down-arrow").removeClass("drop-active-arrow");

		$(this).next(".dropdown").toggleClass("active-drop");
		$(this).find(".bgm").addClass("drop-active");
		$(this).find(".down-arrow").addClass("drop-active-arrow");
		$(this).next(".dropdown").stop().slideToggle("fast"); 
		if(!$(this).next(".dropdown").hasClass("active-drop")){
			
			$(this).find(".bgm").removeClass("drop-active");
			$(this).next(".dropdown").removeClass("active-drop");
			$(this).find(".down-arrow").removeClass("drop-active-arrow");
		}else {
			$(this).find(".bgm").addClass("drop-active");
		} 
		if ($(this).parent("div").hasClass("dd-report-format")){ 
			$(".dd-service-line").find(".dropdown").removeClass("active-drop");
			$(".dd-data-source").find(".dropdown").removeClass("active-drop");
			$(".dd-account-name").find(".dropdown").removeClass("active-drop");

		}else if ($(this).parent("div").hasClass("dd-service-line")){			
			$(".dd-report-format").find(".dropdown").removeClass("active-drop");
			$(".dd-data-source").find(".dropdown").removeClass("active-drop");
			$(".dd-account-name").find(".dropdown").removeClass("active-drop");
		
		}else if ($(this).parent("div").hasClass("dd-data-source")){
			$(".dd-report-format").find(".dropdown").removeClass("active-drop");
			$(".dd-service-line").find(".dropdown").removeClass("active-drop");
			$(".dd-account-name").find(".dropdown").removeClass("active-drop");

		}else if ($(this).parent("div").hasClass("dd-account-name")){
			$(".dd-report-format").find(".dropdown").removeClass("active-drop");
			$(".dd-service-line").find(".dropdown").removeClass("active-drop");
			$(".dd-data-source").find(".dropdown").removeClass("active-drop");
		}
	});

	setTimeout(function(){
		$(".dropdown ul li").click(function(){
			var thisText =  $(this).text();
			$(this).closest(".clickFn").find("p").text(thisText);
			$(this).closest(".clickFn").find("p").attr("title",thisText);
			$(this).parent("ul").find("li").removeClass("dropdown-active");
			$(this).addClass("dropdown-active");
			$(this).parent("ul").parent("div").parent("div").find(".bgm").removeClass("drop-active");
			$(this).parent("ul").parent("div").parent("div").find(".down-arrow").removeClass("drop-active-arrow");
			$(this).parent("ul").parent("div").removeClass("active-drop");
			$(this).find(".down-arrow").removeClass("drop-active-arrow");	
			$(".dropdown").slideUp();
			
		});
		$(".location-nav .dd-box li:eq(0)").css({"color":"#d62e2d"});
		$(".location-nav .dd-box li").click(function(){
			$(".location-nav .dd-box li").css({"color":"#414143"});
			var LocationName = $(this).text();
			$(this).css({"color":"#d62e2d"});
			$(".location-nav h4 span").text(LocationName);
		});	
		
		//------FORM Validation----
		$("#RFscrollbar li").click(function(){
			var rfVal = $(this).attr("rel");
			$("#RF-val").val(rfVal);
		});
		$("#SLscrollbar li").click(function(){
			var slVal = $(this).attr("rel");
			$("#SL-val").val(slVal);
		});
		$("#DSscrollbar li").click(function(){
			var dsVal = $(this).attr("rel");
			$("#DS-val").val(dsVal);
		});
		$("#ANscrollbar li").click(function(){
			var anVal = $(this).attr("rel");
			$("#AN-val").val(anVal);
		});

	},1500);
	//---------dd Scrollbar
	$('#RFscrollbar,#SLscrollbar,#DSscrollbar,#ANscrollbar').enscroll({
		horizontalScrolling: true,
		verticalTrackClass: 'vertical-track2',
		verticalHandleClass: 'vertical-handle2',
	});

	var userAgent = window.navigator.userAgent;
	if (userAgent.match(/iPad/i) || userAgent.match(/iPhone/i)) {
	  $(".dropdown").css({"top":"54px"});
	}

	$(".cate-view-more").click(function(){
		var IdVal = $(this).attr('rel');
		window.location.href='search-report.aspx?kw=&rf=&sl='+IdVal+'&ds=&an=';
	});

});