$(window).load(function() {
	$("body").css({"overflow":"auto"});
	setTimeout(function(){ 
		$(".loadingbg").fadeOut(600);
		$(".loading").fadeOut(600);
		$(".search-loadImg").fadeOut();	
		$(".search-overlay").fadeOut();
		new WOW().init();
	},5000);

	setTimeout(function(){
		gridLayout();
		
		/*$('.flexslider').flexslider({
		  animation: "slide",
		  useCSS: false,
		  animationLoop: false,
		  smoothHeight: true
		});
		$('.flexslider').resize();*/
		 
		/*$('.slideshow1').slick({
			dots: true,
			prevArrow: false,
			nextArrow: false
		});*/
		$('.slick-slider .slides').slick({
			dots: true,
			prevArrow: false,
			nextArrow: false
		});	
	},1000)
	function gridLayout(){
		var $win = $(window),
		isoContainer = $('.grid').isotope(),
		contentBox = $(".gutter-sizer");
		isoContainer.isotope({
			itemSelector: '.grid-item',
			//layoutMode: 'fitRows',
			masonry: {
				columnWidth: 100
			}
		});	   
		isoContainer.isotope({
			itemSelector: '.grid-item',
			//layoutMode: 'fitRows',
			masonry: {
				columnWidth: 100
			}
		});
		$(window).smartresize(function(){
			var winWidth = $(window).width();
			isoContainer.isotope({
				itemSelector: '.grid-item',
				//layoutMode: 'fitRows',
				masonry: {
					columnWidth: 100
				}
			});
			$(document).resize();
		});		 
	}
	$('#RFscrollbar,#SLscrollbar,#DSscrollbar,#ANscrollbar').enscroll({
		horizontalScrolling: true,
		verticalTrackClass: 'vertical-track2',
		verticalHandleClass: 'vertical-handle2',
	});

/*
	//var $win = $(window),$imgs = $("img"),$con = $('#container').isotope();
	function loadVisible($els, trigger) {
		$els.filter(function () {
			var rect = this.getBoundingClientRect();
			return rect.top >= 0 && rect.top <= window.innerHeight;
		}).trigger(trigger);
	}

	isoContainer.isotope('on', 'layoutComplete', function () {
		loadVisible(contentBox, 'lazylazy');
	});

	$win.on('scroll', function () {
		loadVisible(contentBox, 'lazylazy');
	});

	contentBox.lazyload({
		effect: "fadeIn",
		failure_limit: Math.max(contentBox.length - 1, 0),
		event: 'lazylazy'
	});*/
/*
	$('#asc').click(function (event) {
		$con.isotope({
			sortAscending: true,
			sortBy: 'original'
		});
	});
	$('#desc').click(function (event) {
		$con.isotope({
			sortAscending: false,
			sortBy: 'original'
		});
	});
	$('#thin').click(function (event) {
		$con.isotope({
			sortAscending: true,
			filter: 'img[width="333"]',
			sortBy: 'original'
		});
	});
	$('#all').click(function (event) {
		$con.isotope({
			sortAscending: true,
			filter: '',
			sortBy: 'original'
		});
	});
*/

});
$(window).ready(function(){	

	//alert();
	$("select.select-box option").hover(function(){
		$(this).css({"background-color":"red"});
	});
	/*  */
	$(".sort-Menu a").on("click",function(event){
		event.stopPropagation();
		$("ul.dropDown").stop().slideToggle(300);
	});
	/*
	$("ul.dropDown li").click(function(){
		var thisVal = $(this).text();
		//console.log(thisVal);
		$(".sort-Menu a .selectText").text(" ").text(thisVal);
		$(this).parent("ul").slideUp();
	});*/

	$(".nicescroll-rails").find("div").hide();
	$(document).click(function (e){
		var container = $("ul.dropDown");
		var containerSearch = $(".dropdown");
		var searchSelectBox = $(".dd-val").find(".bgm");
		var searchSelectArrow = $(".dd-val").find(".down-arrow");
		if (!container.is(e.target) && container.has(e.target).length === 0 || !containerSearch.is(e.target) && containerSearch.has(e.target).length === 0 || !searchSelectBox.is(e.target) && searchSelectBox.has(e.target).length === 0 || !searchSelectArrow.is(e.target) && searchSelectArrow.has(e.target).length === 0){
			//$(".nicescroll-rails").hide();
			searchSelectBox.removeClass("drop-active");
			searchSelectArrow.removeClass("drop-active-arrow");
			container.slideUp();
			containerSearch.slideUp();
			containerSearch.removeClass("active-drop");	
		};	
		$(".dd-box").slideUp();
	});
		
	$(".seasechList .clickFn .dd-val").click(function(event){
		$('#RFscrollbar,#SLscrollbar,#DSscrollbar,#ANscrollbar').scrollTop(0);
		event.stopPropagation();
		$(".dropdown").slideUp();
		$(".bgm").removeClass("drop-active");
		$(".down-arrow").removeClass("drop-active-arrow");

		$(this).next(".dropdown").toggleClass("active-drop");
		$(this).find(".bgm").addClass("drop-active");
		$(this).find(".down-arrow").addClass("drop-active-arrow");
		$(this).next(".dropdown").stop().slideToggle(); 
		if(!$(this).next(".dropdown").hasClass("active-drop")){
			
			$(this).find(".bgm").removeClass("drop-active");
			$(this).next(".dropdown").removeClass("active-drop");
			$(this).find(".down-arrow").removeClass("drop-active-arrow");
		}else {
			$(this).find(".bgm").addClass("drop-active");
		} 
		if ($(this).parent("div").hasClass("dd-report-format")){ 
			$(".dd-service-line").find(".dropdown").removeClass("active-drop");
			$(".dd-data-source").find(".dropdown").removeClass("active-drop");
			$(".dd-account-name").find(".dropdown").removeClass("active-drop");

		}else if ($(this).parent("div").hasClass("dd-service-line")){			
			$(".dd-report-format").find(".dropdown").removeClass("active-drop");
			$(".dd-data-source").find(".dropdown").removeClass("active-drop");
			$(".dd-account-name").find(".dropdown").removeClass("active-drop");
		
		}else if ($(this).parent("div").hasClass("dd-data-source")){
			$(".dd-report-format").find(".dropdown").removeClass("active-drop");
			$(".dd-service-line").find(".dropdown").removeClass("active-drop");
			$(".dd-account-name").find(".dropdown").removeClass("active-drop");

		}else if ($(this).parent("div").hasClass("dd-account-name")){
			$(".dd-report-format").find(".dropdown").removeClass("active-drop");
			$(".dd-service-line").find(".dropdown").removeClass("active-drop");
			$(".dd-data-source").find(".dropdown").removeClass("active-drop");
		}
	});

	setTimeout(function(){
		$(".dropdown ul li").click(function(){
			var thisText =  $(this).text();
			$(this).closest(".clickFn").find("p").text(thisText);
			$(this).closest(".clickFn").find("p").attr("title",thisText);
			$(this).parent("ul").find("li").removeClass("dropdown-active");
			$(this).addClass("dropdown-active");
			$(this).parent("ul").parent("div").parent("div").find(".bgm").removeClass("drop-active");
			$(this).parent("ul").parent("div").parent("div").find(".down-arrow").removeClass("drop-active-arrow");
			$(this).parent("ul").parent("div").removeClass("active-drop");
			$(this).find(".down-arrow").removeClass("drop-active-arrow");	
			$(".dropdown").slideUp();
			
		});
		$(".location-nav .dd-box li:eq(0)").css({"color":"#d62e2d"});
		$(".location-nav .dd-box li").click(function(){
			$(".location-nav .dd-box li").css({"color":"#414143"});
			var LocationName = $(this).text();
			$(this).css({"color":"#d62e2d"});
			$(".location-nav h4 span").text(LocationName);
		});
	},3000);
	/**/
	var reportListWidth = 0;		
	$(".left-box-2 ul li").each(function(){
		reportListWidth = reportListWidth + $(this).outerWidth()+10;		
	});
	$(".left-box-2 ul").css("width",reportListWidth-10);

	$(".like-bt").click(function(){
		$(this).find("span").toggleClass("like-acive");
	});

	$(".searchClikFn").click(function(){
		$(".searchContent").css({"transform":"scale(0.80)"},function(){
			$(".searchContent").fadeOut(1000);
		});	
		//$(".seasechList").hide();	
	});


	
});

/*$(window).load(function(){
  $('#container').isotope({
    // options...
  });
});*/