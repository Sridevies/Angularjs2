$(window).load(function(){
	setTimeout(function(){
		$('.slideshow1').slick({
			dots: true,
			infinite: true,
			speed: 1500,
			slidesToShow: 4,
			slidesToScroll: 4,
			dotsClass: 'custom_paging',
			customPaging: function (slider, i) {
				//console.log(slider);
				return '<span>'+(i + 1)+'</span>'+ '/' + Math.ceil(slider.slideCount/4);
			},
			responsive: [
			{
				breakpoint: 1025,
				settings: {
					slidesToShow: 3,
					slidesToScroll: 3,
					infinite: true,
					dots: true,
					customPaging: function (slider, i) {
						//console.log(slider);
						return '<span>'+(i + 1)+'</span>'+ '/' + Math.ceil(slider.slideCount/3);
					},
				}
			},
			{
				breakpoint: 768,
				settings: {
					slidesToShow: 2,
					slidesToScroll: 2,
					customPaging: function (slider, i) {
						//console.log(slider);
						return '<span>'+(i + 1)+'</span>'+ '/' + Math.ceil(slider.slideCount/2);
					},
				}
			},
			{
				breakpoint: 480,
				settings: {
					slidesToShow: 1,
					slidesToScroll: 1,
					customPaging: function (slider, i) {
						//console.log(slider);
						return '<span>'+(i + 1)+'</span>'+ '/' + slider.slideCount;
					},
				}
			}
			]
		});

		$('.slideshow2').slick({
			dots: true,
			infinite: true,
			speed: 1500,
			slidesToShow: 4,
			slidesToScroll: 4,
			dotsClass: 'custom_paging',
			customPaging: function (slider, i) {
				//console.log(slider);
				return '<span>'+(i + 1)+'</span>'+ '/' + Math.ceil(slider.slideCount/4);
			},
			responsive: [
			{
				breakpoint: 1025,
				settings: {
					slidesToShow: 3,
					slidesToScroll: 3,
					infinite: true,
					dots: true,
					customPaging: function (slider, i) {
						//console.log(slider);
						return '<span>'+(i + 1)+'</span>'+ '/' + Math.ceil(slider.slideCount/3);
					},
				}
			},
			{
				breakpoint: 768,
				settings: {
					slidesToShow: 2,
					slidesToScroll: 2,
					customPaging: function (slider, i) {
						//console.log(slider);
						return '<span>'+(i + 1)+'</span>'+ '/' + Math.ceil(slider.slideCount/2);
					},
				}
			},
			{
				breakpoint: 480,
				settings: {
					slidesToShow: 1,
					slidesToScroll: 1,
					customPaging: function (slider, i) {
						//console.log(slider);
						return '<span>'+(i + 1)+'</span>'+ '/' + slider.slideCount;
					},
				}
			}
			]
		});

		$('.slideshow3').slick({
			dots: true,
			infinite: true,
			speed: 1500,
			slidesToShow: 3,
			slidesToScroll: 3,
			dotsClass: 'custom_paging',
			customPaging: function (slider, i) {
				//console.log(slider);
				return '<span>'+(i + 1)+'</span>'+ '/' + Math.ceil(slider.slideCount/4);
			},
			responsive:[
			{
				breakpoint: 1025,
				settings: {
					slidesToShow: 3,
					slidesToScroll: 3,
					infinite: true,
					dots: true,
					customPaging: function (slider, i) {
						//console.log(slider);
						return '<span>'+(i + 1)+'</span>'+ '/' + Math.ceil(slider.slideCount/3);
					},
				}
			},
			{
				breakpoint: 768,
				settings: {
					slidesToShow: 2,
					slidesToScroll: 2,
					customPaging: function (slider, i) {
						//console.log(slider);
						return '<span>'+(i + 1)+'</span>'+ '/' + Math.ceil(slider.slideCount/2);
					},
				}
			},
			{
				breakpoint: 480,
				settings: {
					slidesToShow: 1,
					slidesToScroll: 1,
					customPaging: function (slider, i) {
						//console.log(slider);
						return '<span>'+(i + 1)+'</span>'+ '/' + slider.slideCount;
					},
				}
			}
			]
		});
		var RegionName = $(".location-nav .dd-box li:eq(0)").text(); 
		var RegionClass = "."+RegionName;
		$('.slideshow3').slick('slickFilter',RegionClass);

		$(".location-nav .dd-box li").on('click', function(){
			var Region1Name = $(this).text();
			var Region1Class = "."+Region1Name;
			//console.log(Region1Class);
			$('.slideshow3').slick('slickUnfilter');
			$('.slideshow3').slick('slickFilter',Region1Class);
		})
	},1500)

});