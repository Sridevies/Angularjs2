angular.module('myApp',[]).controller('BISearch',function($scope,$http,$q,$window,$compile, $timeout){
	
	$http.get("/sites/17079/_api/Web/currentUser?$select=Title,LoginName,Id").then(function(response){
		console.log(response);
		$scope.UserID = response.data;
	});	


	// Report Format list
	$http.get("/sites/17079/_api/Web/Lists/GetByTitle('Report Format')/Items").then(function(response){
		$scope.ReportFormatList = response.data.value;
	});
	
	// Service Line list
	$http.get("/sites/17079/_api/Web/Lists/GetByTitle('Service Line')/Items").then(function(response){
		$scope.ServiceLineList = response.data.value;
	});

	// Data Source
	$http.get("/sites/17079/_api/Web/Lists/GetByTitle('Data Source')/Items").then(function(response){
		$scope.DataSourceList = response.data.value;
	});

	// Account Name
	$http.get("/sites/17079/_api/Web/Lists/GetByTitle('Account Name')/Items").then(function(response){
		$scope.AccountNameList = response.data.value;
	});
	
	$window.onload = function(){
		//------FORM Validation----		
		var QueryString = function () {
			// This function is anonymous, is executed immediately and 
			// the return value is assigned to QueryString!
			var query_string = {};
			var query = window.location.search.substring(1);
			var vars = query.split("&");
			for (var i=0;i<vars.length;i++) {
			var pair = vars[i].split("=");
				// If first entry with this name
			if (typeof query_string[pair[0]] === "undefined") {
			  query_string[pair[0]] = decodeURIComponent(pair[1]);
				// If second entry with this name
			} else if (typeof query_string[pair[0]] === "string") {
			  var arr = [ query_string[pair[0]],decodeURIComponent(pair[1]) ];
			  query_string[pair[0]] = arr;
				// If third or later entry with this name
			} else {
			  query_string[pair[0]].push(decodeURIComponent(pair[1]));
			}
			} 
			return query_string;
		}();
		
		$("#searhbox").val(QueryString.kw);
		$("#RF-val").val(QueryString.rf);
		$("#SL-val").val(QueryString.sl);
		$("#DS-val").val(QueryString.ds);
		$("#AN-val").val(QueryString.an); 
	
		setTimeout(function(){
			$("#RFscrollbar li:eq("+QueryString.rf+")").trigger("click"); 
			$("#SLscrollbar li:eq("+QueryString.sl+")").trigger("click");
			$("#DSscrollbar li:eq("+QueryString.ds+")").trigger("click");
			$("#ANscrollbar li:eq("+QueryString.an+")").trigger("click");

			$("#RFscrollbar li").click(function(){
				var rfVal = $(this).attr("rel");
				$("#RF-val").val(rfVal);
			});
			$("#SLscrollbar li").click(function(){
				var slVal = $(this).attr("rel");
				$("#SL-val").val(slVal);
			});
			$("#DSscrollbar li").click(function(){
				var dsVal = $(this).attr("rel");
				$("#DS-val").val(dsVal);
			});
			$("#ANscrollbar li").click(function(){
				var anVal = $(this).attr("rel");
				$("#AN-val").val(anVal);
			});
		},3000);
		setTimeout(function(){
			showingResultText();
		},3200);		
		setTimeout(function(){
			document.getElementById("updateSearch").click();
		},5000);
	};
	$scope.searchUpdate = function(){
		var searchWord = document.getElementById('searhbox').value;
		var rfValue = document.getElementById('RF-val').value;
		var slValue = document.getElementById('SL-val').value;
		var dsValue = document.getElementById('DS-val').value;
		var anValue = document.getElementById('AN-val').value;

		var listURLwithFilter = "/sites/17079/_api/Web/Lists/GetByTitle('Reports')/Items?$expand=AttachmentFiles,ReportFormat,ServiceLine,DataSourcesUsedToGenerateReport,AccountName&$select=ID,AttachmentFiles,Description,BusinessQuestionThisReportAnswer,DataCaptureProcess,Example,ReportLocation,DeliveryMethod,PrimaryReportConsumer,InternalJLLAccountTeamFacing,ExternalClientFacing,BusinessOwner,ReportCreator,FrequencyUpdatedDelivered,OngoingEffortToGenerateReport,TotalHoursToProduceInitially,WhatIssuesAreThereWithTheReport,AllMetrics,DocumentationExists,OtherNotes,ReportImportance,Keywords,LogoImage,PDFPath,LikeCount,EditorId,ReportFormat/Title,ReportFormat/Id,Title,ServiceLine/Title,ServiceLine/Id,Title,DataSourcesUsedToGenerateReport/Title,DataSourcesUsedToGenerateReport/Id,Title,AccountName/Title,AccountName/Id,Title&$filter=({filterqry})";
		if(searchWord != '' || rfValue != '' ||  slValue != '' ||  dsValue != '' ||  anValue != ''){
			//alert("Working");	
			$(".search-overlay").show();
			$(".search-loadImg").fadeIn();
			               
			var filterQuery = "{titlefilter}{rffilter}{slfilter}{dsfilter}{anfilter}";

			// For Report Title
			if(searchWord){
				   filterQuery = filterQuery.replace("{titlefilter}","Title eq '"+searchWord+"' or Keywords eq '"+searchWord+"' and ");
			}else{
				   filterQuery = filterQuery.replace("{titlefilter}","");
			}
			
			// For Report Format
			if(rfValue){
				   filterQuery = filterQuery.replace("{rffilter}","ReportFormatId eq '"+rfValue+"' and ");
			}else{
				   filterQuery = filterQuery.replace("{rffilter}","");
			}
			
			// For Service LIne
			if(slValue){
				   filterQuery = filterQuery.replace("{slfilter}","ServiceLineId eq '"+slValue+"' and ");
			}else{
				   filterQuery = filterQuery.replace("{slfilter}","");
			}
			
			// For Data Source
			if(dsValue){
				   filterQuery = filterQuery.replace("{dsfilter}","DataSourcesUsedToGenerateReportId eq '"+dsValue+"' and ");
			}else{
				   filterQuery = filterQuery.replace("{dsfilter}","");
			}
			
			// For Account Name
			if(anValue){
				   filterQuery = filterQuery.replace("{anfilter}","AccountNameId eq '"+anValue+"' and ");
			}else{
				   filterQuery = filterQuery.replace("{anfilter}","");
			}
			filterQuery = filterQuery.substring(0,filterQuery.length-5);
			listURLwithFilter = listURLwithFilter.replace("{filterqry}",filterQuery);
			//console.log(listURLwithFilter);
			var selectText = $(".selectText").text();
			if(selectText == 'Alphabetically'){
				$http.get(listURLwithFilter+'&$orderby=Title asc').then(function(searhQueryResponse){
					$scope.searchData = searhQueryResponse.data.value;
					//console.log(searhQueryResponse.data);
				});
			}else{
				$http.get(listURLwithFilter+'&$orderby=LikeCount desc').then(function(searhQueryResponse){
					$scope.searchData = searhQueryResponse.data.value;
					//console.log(searhQueryResponse.data);
				});
			}
			//For top4 slider
			$http.get(listURLwithFilter+'&$top=4&$orderby=LikeCount desc').then(function(sliderquery){
				$scope.sliderData = sliderquery.data.value;
			});
			
			//For Related Searcch
			$http.get("/sites/17079/_api/Web/Lists/GetByTitle('Reports')/Items?$expand=AttachmentFiles,ReportFormat,ServiceLine,DataSourcesUsedToGenerateReport,AccountName&$select=ID,AttachmentFiles,Description,BusinessQuestionThisReportAnswer,DataCaptureProcess,Example,ReportLocation,DeliveryMethod,PrimaryReportConsumer,InternalJLLAccountTeamFacing,ExternalClientFacing,BusinessOwner,ReportCreator,FrequencyUpdatedDelivered,OngoingEffortToGenerateReport,TotalHoursToProduceInitially,WhatIssuesAreThereWithTheReport,AllMetrics,DocumentationExists,OtherNotes,ReportImportance,Keywords,LogoImage,PDFPath,LikeCount,EditorId,ReportFormat/Title,ReportFormat/Id,Title,ServiceLine/Title,ServiceLine/Id,Title,DataSourcesUsedToGenerateReport/Title,DataSourcesUsedToGenerateReport/Id,Title,AccountName/Title,AccountName/Id,Title").then(function(relatedsearch){
				$scope.relatedData = relatedsearch.data.value;
			});
			$scope.relatedFilterQuery();
			$(".slick-slider .slides").slick('unslick');
			setTimeout(function(){
				$(".grid").isotope( 'reloadItems' ).isotope();
				showingResultText();
				//$('.flexslider').resize();
				//$(".slick-slider .slides").slick() 
				$('.slick-slider .slides').slick({
					prevArrow: false,
					nextArrow: false,
					dots: true,
					infinite: false,
					speed: 300,
					slidesToShow: 1,
					slidesToScroll: 1
				});	
				$(document).resize();
				if ($('.slides li').length == 0){
					$('.grid').hide();
					$(".result-sort").hide();
					$('.Noresult').show();
				}else{
					$('.grid').show();
					$('.Noresult').hide();
					$(".result-sort").show();
				} 
				var searchText = $(".getResultText").text().trim();
				var trimRemove = searchText.substring(0, searchText.length -1).trim();
				$(".resultText").text(" ").text(trimRemove);
				
				
				
			},1500);
			
			/*$(".grid-item").click(function(){
				$(".grid-item").removeClass("active");
				$(this).addClass("active");
				alert("Clicked");
			});*/
			setTimeout(function(){
				$(".search-loadImg").fadeOut();	
				$(".search-overlay").fadeOut();
				$scope.likeFn();
			},4000);
			
		}else{
			alert("Please select any one field"); 
			$(".search-overlay").hide();
			$(".search-loadImg").hide();
		}
		if ($(window).width()<767){
			var headerHeing = $(".header-SR").height();
			$('html,body').animate({scrollTop:headerHeing}, 800);
		}
	}
	$(".result-sort li").click(function(){
		var sortText = $(this).text();
		$(".selectText").text(sortText);
		$("#updateSearch").trigger("click");
	});

	$scope.relatedFilterQuery = function(){
		relatedFilter();		
		$scope.filterKW = $("#filterKW").val();
		$scope.filterRF = $("#filterRF").val();
		$scope.filterSL = $("#filterSL").val();
		$scope.filterDS = $("#filterDS").val();
		$scope.filterAN = $("#filterAN").val();
	}
	
	
	//=====================For Details 
	$scope.reportDetails = function(ItemId){
		console.log(ItemId)
		$http.get("/sites/17079/_api/Web/Lists/GetByTitle('Reports')/Items(" +ItemId+ ")?$expand=AttachmentFiles,ReportFormat,ServiceLine,DataSourcesUsedToGenerateReport,AccountName&$select=ID,AttachmentFiles,Description,BusinessQuestionThisReportAnswer,DataCaptureProcess,Example,ReportLocation,DeliveryMethod,PrimaryReportConsumer,InternalJLLAccountTeamFacing,ExternalClientFacing,BusinessOwner,ReportCreator,FrequencyUpdatedDelivered,OngoingEffortToGenerateReport,TotalHoursToProduceInitially,WhatIssuesAreThereWithTheReport,AllMetrics,DocumentationExists,OtherNotes,ReportImportance,Keywords,LogoImage,PDFPath,DownloadDataModel,LikeCount,EditorId,ReportFormat/Title,ReportFormat/Id,Title,ServiceLine/Title,ServiceLine/Id,Title,DataSourcesUsedToGenerateReport/Title,DataSourcesUsedToGenerateReport/Id,Title,AccountName/Title,AccountName/Id,Title").then(function(response){
			//console.log(response);
			$scope.reportinfo = response.data;
		});
		
		$("html,body").animate({"scrollTop":0},500,function(){
			$(".search-result").animate({"z-index":2},100);
			$(".header-SR").animate({"z-index":0},100);
			$(".seasechList, .searchContent").fadeOut().addClass("searhAnimation");
			$(".searchContent, .seasechList").fadeOut();		
			$(".searchDetail").fadeIn().addClass("repoartAnimation");
			$("a.back2search").fadeIn();
			
			

		});
		
		$(".NextPrev,.sliderNextPrev,.relatedReportNextPrev").click(function(){
			$(".NextPrev,.sliderNextPrev,.relatedReportNextPrev").removeClass("CurrentReport");
			$(this).addClass("CurrentReport");
			//alert("Clicked");

		});

		$scope.thumblist();
		$(".slick-slider .slides").slick('unslick');

		setTimeout (function(){
			$scope.likeFn();
		},2000);
		
		
	}

	$scope.nextreport = function(){
		var nextReportId = $(".CurrentReport").next(".NextPrev,.sliderNextPrev,.relatedReportNextPrev").attr("rel");
		//alert("Next id = "+nextReportId);
		$http.get("/sites/17079/_api/Web/Lists/GetByTitle('Reports')/Items(" +nextReportId+ ")?$expand=AttachmentFiles,ReportFormat,ServiceLine,DataSourcesUsedToGenerateReport,AccountName&$select=ID,AttachmentFiles,Description,BusinessQuestionThisReportAnswer,DataCaptureProcess,Example,ReportLocation,DeliveryMethod,PrimaryReportConsumer,InternalJLLAccountTeamFacing,ExternalClientFacing,BusinessOwner,ReportCreator,FrequencyUpdatedDelivered,OngoingEffortToGenerateReport,TotalHoursToProduceInitially,WhatIssuesAreThereWithTheReport,AllMetrics,DocumentationExists,OtherNotes,ReportImportance,Keywords,LogoImage,PDFPath,DownloadDataModel,LikeCount,ReportFormat/Title,ReportFormat/Id,Title,ServiceLine/Title,ServiceLine/Id,Title,DataSourcesUsedToGenerateReport/Title,DataSourcesUsedToGenerateReport/Id,Title,AccountName/Title,AccountName/Id,Title").then(function(response){
			//console.log(response);
			$scope.reportinfo = response.data;
		});

		$(".CurrentReport").next(".NextPrev,.sliderNextPrev,.relatedReportNextPrev").addClass("CurrentReport");
		//$(".active:last-child").prev(".grid-item").removeClass("active");
		var activeLength = $(".CurrentReport").length;
		if(activeLength > 1){ 
			$(".CurrentReport:eq(0)").removeClass("CurrentReport");
		}else{
			alert("No Report");
		}
		
		$scope.thumblist();
		setTimeout (function(){
			$scope.likeFn();
		},2000);
	}; 
	$scope.prevreport = function(){
		var prevReportId = $(".CurrentReport").prev(".NextPrev,.sliderNextPrev,.relatedReportNextPrev").attr("rel");
		//alert("Preview ID = "+prevReportId);
		$http.get("/sites/17079/_api/Web/Lists/GetByTitle('Reports')/Items(" +prevReportId+ ")?$expand=AttachmentFiles,ReportFormat,ServiceLine,DataSourcesUsedToGenerateReport,AccountName&$select=ID,AttachmentFiles,Description,BusinessQuestionThisReportAnswer,DataCaptureProcess,Example,ReportLocation,DeliveryMethod,PrimaryReportConsumer,InternalJLLAccountTeamFacing,ExternalClientFacing,BusinessOwner,ReportCreator,FrequencyUpdatedDelivered,OngoingEffortToGenerateReport,TotalHoursToProduceInitially,WhatIssuesAreThereWithTheReport,AllMetrics,DocumentationExists,OtherNotes,ReportImportance,Keywords,LogoImage,PDFPath,DownloadDataModel,LikeCount,ReportFormat/Title,ReportFormat/Id,Title,ServiceLine/Title,ServiceLine/Id,Title,DataSourcesUsedToGenerateReport/Title,DataSourcesUsedToGenerateReport/Id,Title,AccountName/Title,AccountName/Id,Title").then(function(response){
			//console.log(response);
			$scope.reportinfo = response.data;
		});

		$(".CurrentReport").prev(".NextPrev,.sliderNextPrev,.relatedReportNextPrev").addClass("CurrentReport");
		var activeLength = $(".CurrentReport").length;
		if(activeLength > 1){ 
			$(".CurrentReport:eq(1)").removeClass("CurrentReport");
		}else{
			alert("No Report");
		}
		//$(".active:eq(1)").removeClass("active");
		//$(".active:last-child").removeClass("active");

		$scope.thumblist();
		setTimeout (function(){
			$scope.likeFn();
		},2000);
	};

	
	$scope.thumblist = function (){
		setTimeout (function(){
			if($(".left-box-2 ul li:eq(0)").hasClass("ng-hide")){
				//alert("no");
				$(".left-box-2").slideUp();
			}else {
				//alert("Yes");
				$(".left-box-2").slideDown();
				if (!$(".left-box-2 ul li:eq(2)").hasClass("ng-hide")){
					$(".left-box-2 ul").css({"width":"300px"});
				}else if (!$(".left-box-2 ul li:eq(3)").hasClass("ng-hide")){
					$(".left-box-2 ul").css({"width":"400px"});
				}else if (!$(".left-box-2 ul li:eq(4)").hasClass("ng-hide")){
					$(".left-box-2 ul").css({"width":"500px"});
				};
			}
			
		},1000);
	}

	$scope.likeFn = function(){
		//alert("start");
		$(".like-bt").each(function(){
			console.log($(this).find(".cnt").text());
			if($(this).find(".cnt").text()==0){
				$(this).removeClass("like-active");
			}
		});
		$(".like-bt").click(function(){
			var getCnt = parseInt($(this).find(".cnt").text());
			var ItemId = $(this).attr("rel");
			if(!$(this).hasClass("like-active")){
				getCnt = getCnt+1;				
				$(this).find(".cnt").text(getCnt);
				$(this).addClass("like-active");
				updateList(getCnt,ItemId);
				//console.log("Add")
			}else {
				$(this).removeClass("like-active");
				getCnt = getCnt-1
				$(this).find(".cnt").text(getCnt);
				updateList(getCnt,ItemId);
				//console.log("Remove")
			}
		});
	}
});

function updateList(getCnt,ItemId){
	var inputData = {};
		inputData.__metadata = {};
		inputData.__metadata.type = 'SP.Data.ReportsListItem';
		inputData.LikeCount = getCnt;
		$.ajax  ({
			url: "/sites/17079/_api/Web/Lists/GetByTitle('Reports')/items('"+ItemId+"')", // list item ID
			type: "POST",
			data: JSON.stringify(inputData), 
			headers:{
				"Accept": "application/json;odata=verbose",
				"Content-Type": "application/json;odata=verbose",
				"X-RequestDigest": $("#__REQUESTDIGEST").val(),
				"IF-MATCH": "*",
				"X-HTTP-Method": "MERGE"
			},
			success: function(data, status, xhr){ 
				getListItems(url, listname);
			},
			error: function(xhr, status, error){  
				//$("#ResultDiv").empty().text(data.responseJSON.error);  
			}
		});
}

// Getting list items based on ODATA Query
var url = '/sites/17079/';
var listname = 'Reports';
//var query = '?$select=Title,LikesCount,likecount,LikedBy/Title&$expand=LikedBy';
//var id = "(1)";
var success = 'sucess';
var failure = 'failure';

function getListItems(url, listname) {
	$.ajax({
		url: url + "_api/Web/Lists/GetByTitle('" + listname + "')/items",
		method: "GET",
		headers: { "Accept": "application/json; odata=verbose" },
		success: function (data) {
		},
		error: function (data) {
			console.log("Error");
		}
	});

}
getListItems(url, listname);



function relatedFilter(){
	var filterKW = $("#searhbox").val();
	$("#filterKW").val(filterKW);
	
	//console.log("functin enter")
	
	var filterRF = $('#ddrf').text();
	if(filterRF == 'Report Format'){
		$('#filterRF').val('');
		//console.log("val empty chk :" + filterRF)
	}else{
		$('#filterRF').val('');
		$('#filterRF').val($('#ddrf').text().trim());	
		//console.log($('#filterRF').val(filterRF));		
	}
	
	var filterSL = $('#ddsl').text();
	if(filterSL == 'Service Line'){
		$('#filterSL').val('');	
	}else{
		$('#filterSL').val('');	
		$('#filterSL').val($('#ddsl').text().trim());
		//console.log($('#filterSL').val(filterSL));		
	}

	var filterDS = $('#ddds').text();
	if(filterDS == 'Data Source'){
		$('#filterDS').val('');	
	}else{
		$('#filterDS').val('');		
		$('#filterDS').val($('#ddds').text().trim());
		//console.log($('#filterDS').val(filterDS));		
	}
	
	var filterAN = $('#ddan').text();
	if(filterAN == 'Account Name'){
		$('#filterAN').val('');
	}else{
		$('#filterAN').val('');
		$('#filterAN').val($('#ddan').text().trim());	
		//console.log($('#filterAN').val(filterAN));		
	}
}
function showingResultText(){
	var searchText = $("#searhbox").val();
	if(searchText != ''){
		$("#searchkeyText").text(searchText+" / ");
	}else{
		$("#searchkeyText").text('');
	}
	
	var rfText = $(".dd-val:eq(0) p").text();
	if(rfText != 'Report Format'){
		$("#rfText").text(rfText+" / ");
	}else{
		$("#rfText").text('');
	}
	
	var slText = $(".dd-val:eq(1) p").text();
	if(slText != 'Service Line'){
		$("#slText").text(slText+" / ");
	} else{
		$("#slText").text('');
	}
	
	var dsText = $(".dd-val:eq(2) p").text();
	if(dsText != 'Data Source'){
		$("#dsText").text(dsText+" / ");
	}else{
		$("#dsText").text('');
	}
	
	var anText = $(".dd-val:eq(3) p").text();
	if(anText != 'Account Name'){
		$("#anText").text(anText+" / ");
	}else{
		$("#anText").text('');
	}
	
}
