/*  price check  */
function getprice1() {
		var incomeval = document.getElementById("income").value;
		
		var getPrice = document.getElementById("net-price2").value;
		var purcheck, sdltcheck, r,s;
		incomeval = parseInt(incomeval);
		getPrice = parseInt(getPrice);
		
		var resultcost = '', resultpurchase = '', resultnet = '', resultsdlt = '', sdltinput = '';
		var y;
		if (getPrice <= 0) {
		 alert("Please Enter valid price");
		}	   
		if (getPrice <= 150000) {
			
			sdltcheck = getPrice * 0;
			purcheck = ((getPrice * 0.018) + sdltcheck) / getPrice;
			s = purcheck * 100;
			r = (incomeval / getPrice /(1 + purcheck)) *100;
			resultcost =  sdltcheck.toFixed(0);
			resultpurchase = s.toFixed(2) + "%";
			resultnet = r.toFixed(2) + "%";
			sdltinput = (sdltcheck / getPrice) *100;
			sdltinput = sdltinput.toFixed(2) + "%";

		} 
		else 
		if (getPrice <= 250000) {
			sdltcheck = (150000 * 0) + ((getPrice - 150000) * 0.02);
			purcheck = ((getPrice * 0.018) + sdltcheck) / getPrice;
			s = purcheck * 100;
			r = (incomeval / getPrice /(1 + purcheck)) *100;
			resultcost = sdltcheck.toFixed(0);
			resultpurchase = s.toFixed(2) + "%";
			resultnet = r.toFixed(2) + "%";
			sdltinput = (sdltcheck / getPrice) *100;
			sdltinput = sdltinput.toFixed(2) + "%";
			
		} 
		else 
		if (getPrice > 250000) {
			sdltcheck = (150000 * 0) + ((250000 - 150000) * 0.02) + ((getPrice - 250000) * 0.05);
			purcheck = ((getPrice * 0.018) + sdltcheck) / getPrice;
			s = purcheck * 100;
			r = (incomeval / getPrice /(1 + purcheck)) *100;
			resultcost = sdltcheck.toFixed(0);
			resultpurchase = s.toFixed(2) + "%";
			resultnet = r.toFixed(2) + "%";
			sdltinput = (sdltcheck / getPrice) *100;
			sdltinput = sdltinput.toFixed(2) + "%";
			
		}
			document.getElementById("result-purchase-per").innerHTML = resultpurchase;
			document.getElementById('result-sdlt-cost').innerHTML = resultcost;
			document.getElementById('result-net-yield').innerHTML = resultnet;
			document.getElementById('result-sdlt-per').innerHTML = sdltinput;

			
	}

/*  price check no option */
function getpriceNo() {
		
		var getPrice = document.getElementById("net-price2").value;
		var purcheck, sdltcheck, r,s;
		getPrice = parseInt(getPrice);
		var resultcost = '', resultpurchase = '', resultnet = '';
		var sdltinput = '';
		if (getPrice <= 0) {
		 alert("Please Enter valid price");
		}	   
		if (getPrice <= 150000) {
			
			sdltcheck = getPrice * 0;
			purcheck = ((getPrice * 0.018) + sdltcheck) / getPrice;
			s = purcheck * 100;
			resultcost =  sdltcheck.toFixed(0);
			resultpurchase = s.toFixed(2) + "%";
			sdltinput = (sdltcheck / getPrice) *100;
			sdltinput = sdltinput.toFixed(2) + "%";
		} 
		else 
		if (getPrice <= 250000) {
			sdltcheck = (150000 * 0) + ((getPrice - 150000) * 0.02);
			purcheck = ((getPrice * 0.018) + sdltcheck) / getPrice;
			s = purcheck * 100;
			resultcost = sdltcheck.toFixed(0);
			resultpurchase = s.toFixed(2) + "%";
			sdltinput = (sdltcheck / getPrice) *100;
			sdltinput = sdltinput.toFixed(2) + "%";
		} 
		else 
		if (getPrice > 250000) {
			sdltcheck = (150000 * 0) + ((250000 - 150000) * 0.02) + ((getPrice - 250000) * 0.05);
			purcheck = ((getPrice * 0.018) + sdltcheck) / getPrice;
			s = purcheck * 100;
			resultcost = sdltcheck.toFixed(0);
			resultpurchase = s.toFixed(2) + "%";
			sdltinput = (sdltcheck / getPrice) *100;
			sdltinput = sdltinput.toFixed(2) + "%";
		}
			document.getElementById("result-purchase-per").innerHTML = resultpurchase;
			document.getElementById('result-sdlt-cost').innerHTML = resultcost;
			document.getElementById('result-sdlt-per').innerHTML = sdltinput;
	}





/*  number or text check */
function isNumber(n){
  return (parseFloat(n) == n);
}

function TotalResultChart(){
	var totalVal = parseInt($('#result-purchase-per').html());
	var doughnutData = [
		{value:totalVal,color:"#ffffff"},
		{value:100-totalVal,color:"#404042" },
		
	];
	$( "#myDoughnut" ).doughnutit({
		dnData: doughnutData,
		dnSize: 110,
		dnInnerCutout: 85,
		dnAnimation: true,
		dnAnimationSteps: 100,
		dnAnimationEasing: 'linear',
		dnStroke: false,
		dnShowText: true,
		dnFontSize: '0px',
		dnFontColor: "#819596",
		dnText: totalVal,
		dnStartAngle: 270,
		dnCounterClockwise: false
	});// End Doughnut
		
	
}

function TotalResultChart1(){
	var totalVal1 = parseInt($('#result-net-yield').html());
	var doughnutData1 = [
		{value:totalVal1,color:"#ffffff"},
		{value:100-totalVal1,color:"#404042" },
		
	];

	$( "#myDoughnut1" ).doughnutit({
		dnData: doughnutData1,
		dnSize: 50,
		dnInnerCutout: 70,
		dnAnimation: true,
		dnAnimationSteps: 100,
		dnAnimationEasing: 'linear',
		dnStroke: false,
		dnShowText: true,
		dnFontSize: '0px',
		dnFontColor: "#819596",
		dnText: totalVal1,
		dnStartAngle: 270,
		dnCounterClockwise: false
	});// End Doughnut
		
	
}
function TotalResultChart2(){
	var totalVal = parseInt($('#result-sdlt-per').html());
	var doughnutData = [
		{value:totalVal,color:"#ffffff"},
		{value:100-totalVal,color:"#404042" },
		
	];
	$( "#myDoughnut2" ).doughnutit({
		dnData: doughnutData,
		dnSize: 110,
		dnInnerCutout: 85,
		dnAnimation: true,
		dnAnimationSteps: 100,
		dnAnimationEasing: 'linear',
		dnStroke: false,
		dnShowText: true,
		dnFontSize: '0px',
		dnFontColor: "#819596",
		dnText: totalVal,
		dnStartAngle: 270,
		dnCounterClockwise: false
	});// End Doughnut
		
	
}