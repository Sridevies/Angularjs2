
$(document).ready(function () {
	function isNumber(n){
	  return (parseFloat(n) == n);
	}
	$("#income").keyup(function(event){
        var input = $(this).val();
        if(!isNumber(input)){
            delay(function(){
				alert("Enter Numbers Only");
			}, 200 );
            $(this).val('');
			$('#result-purchase-per').html('');
			$('#result-net-yield').html('');
			$("#result-sdlt-cost").html('');
			$('#result-purchase-per').html('');
			$('#result-net-yield').html('');
			$('#result-sdlt-per').html('');
			$('#netpriceOutput').html('');
			TotalResultChart();
			TotalResultChart1();
			TotalResultChart2();
        }
    });
	$("#net-price2").keyup(function(event){
        var input = $(this).val();
        if(!isNumber(input)){
            delay(function(){
				alert("Enter Numbers Only");
			}, 200 );
            $(this).val('');
			$('#result-purchase-per').html('');
			$('#result-net-yield').html('');
			$("#result-sdlt-cost").html('');
			$('#result-purchase-per').html('');
			$('#result-net-yield').html('');
			$('#result-sdlt-per').html('');
			TotalResultChart();
			TotalResultChart1();
			TotalResultChart2();
        }	
    });
	$("#net-yeild").keyup(function(event){
        var input = $(this).val();
        if(!isNumber(input)){
            delay(function(){
				alert("Enter % Value");
			}, 200 );
            $(this).val('');
			$('#result-purchase-per').html('');
			$('#result-net-yield').html('');
			$("#result-sdlt-cost").html('');
			$('#result-purchase-per').html('');
			$('#result-net-yield').html('');
			$('#result-sdlt-per').html('');
			$('#netpriceOutput').html('');
			TotalResultChart();
			TotalResultChart1();
			TotalResultChart2();
        }
    });
	/*  price format check  */
	$.fn.digits = function (){ 
		return this.each(function(){ 
		$(this).text( $(this).text().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,") ); 
		})
	}
	
	/*  if no option click, price value null check*/
	$('#no').click(function(){
		$('#income,#net-yeild').val('');
		if ($(this).is(':checked') && $(this).val() == 'no') {
			$('#net-price2').val('');
		}
	});
	
	$('#yes').click(function(){
		$('#net-price2').val('');

	});
	
	var delay = (function(){
		var timer = 0;
		return function(callback, ms){
			clearTimeout (timer);
			timer = setTimeout(callback, ms);
		};
	})();
	
	$('.sdlt-yield').hide();
	$('#net-price').hide();
	$('#percentageerror').hide();
	$('#net-yeild-ie-button').show();
	//Calculation based on inputs

	$('#net-yeild').on("keyup", function() {
		if($('#net-yeild').val() > 100)
		{
			$('#net-yeild').val('');
			$('#percentageerror').show();			
			$("#result-sdlt-cost").html('');
			$('#result-purchase-per').html('');
			$('#netpriceOutput').html('');
			$('#result-sdlt-per').html('');			
			TotalResultChart();
			TotalResultChart1();
			TotalResultChart2();
			$('#net-yeild-ie-button').prop('disabled', true);
		} else
		{
			$('#percentageerror').hide();
			$('#net-yeild-ie-button').prop('disabled', false);
		}
	});
	function netyeildVal()
	{
		if($('#income').val()==""){			
			$("#result-sdlt-cost").html('');
			$('#result-purchase-per').html('');
			$('#netpriceOutput').html('');
			$('#result-sdlt-per').html('');			
			TotalResultChart();
			TotalResultChart1();
			TotalResultChart2()
			delay(function(){
				alert("Enter the Income")
			}, 200 );
		}
		else if($('#net-yeild').val()==""){			
			$("#result-sdlt-cost").html('');
			$('#result-purchase-per').html('');
			$('#netpriceOutput').html('');
			$('#result-sdlt-per').html('');			
			TotalResultChart();
			TotalResultChart1();
			TotalResultChart2();
			delay(function(){
				alert("Enter the Net Yield");
			}, 200 );
		}else if ($('#net-yeild').val() <= 0) {
			delay(function(){
				alert("Please Enter valid Net Yield");
			}, 200 );			
		}else{
			netYieldcalc(); 
			TotalResultChart();
			TotalResultChart1();
			TotalResultChart2();
			$('#result-sdlt-cost').digits();			
			
		}
	}

	function NetpriceVal()
	{
		if($('#income').val()==""){					
			$("#result-sdlt-cost").html('');
			$('#result-purchase-per').html('');
			$('#result-net-yield').html('');
			$('#result-sdlt-per').html('');
			TotalResultChart();
			TotalResultChart1();
			TotalResultChart2();
			delay(function(){
				alert("Enter the Income");
			}, 200 );
		}else if($('#net-price2').val()==""){					
			$("#result-sdlt-cost").html('');
			$('#result-purchase-per').html('');
			$('#result-net-yield').html('');
			$('#result-sdlt-per').html('');
			TotalResultChart();
			TotalResultChart1();
			TotalResultChart2();
			delay(function(){
				alert("Enter the Net Price");
			}, 200 );
		}else{
			getprice1();
			$('#result-sdlt-cost').digits();
			TotalResultChart();
			TotalResultChart2();
			TotalResultChart1();
		}
	}
	$('#net-yeild-ie-button').click(function() {		
		netyeildVal();		
	});
	
	$('#net-group').change(function() {
		if ($('#net-group').val() == 'net-yield') {
			$('.sdlt-yield').hide()
			$('.sdlt-price').show();
			$('#net-yeild-percent').show();			
			$('#net-price').hide();
			$('#net-yeild-ie-button').show();
			$('#net-price-ie-button').hide();
			$('#no-netprice-ie-button').hide();
			$('#net-yeild').val('');
			$('#result-sdlt-cost').html('');
			$('#result-purchase-per').html('');
			$('#result-net-yield').html('');
			$('#result-sdlt-per').html('');
			$('#net-yeild-ie-button').click(function() {
				netyeildVal();				
			});
			$('#netpriceOutput').html('');
			TotalResultChart();
			TotalResultChart1();
			TotalResultChart2()
		  
		 } else {
		 
			$('.sdlt-price').hide();
			$('.sdlt-yield').show();
			$('#net-yeild-percent').hide();
			$('#net-price').show();
			$('#net-yeild-ie-button').hide();
			$('#net-price-ie-button').show();
			$('#no-netprice-ie-button').hide();
			$('#net-yeild').val('');
			$('#net-price-ie-button').click(function() {
				NetpriceVal();					
			});
			$("#result-sdlt-cost").html('');
			$('#result-purchase-per').html('');
			$('#result-net-yield').html('');
			$('#result-sdlt-per').html('');
			TotalResultChart();
			TotalResultChart1();
			TotalResultChart2();
			$('#net-price2').val('');
			
		 }
	});

	$('input:radio[name="pro-invest"]').change(
		function(){
			if ($(this).is(':checked') && $(this).val() == 'yes') {
				$('.no-hide').fadeIn();
				$('.sdlt-yield').fadeOut()
				$('.sdlt-price').fadeIn();
				$('#net-yeild-percent').show();
				$('#net-price').hide();
				$('#net-group').change();
				if ($('#net-group').val() == 'net-yield') {
					$('#net-yeild-ie-button').show();
					$('#net-price-ie-button').hide();
					$('#no-netprice-ie-button').hide();
					$('#net-yeild-ie-button').click(function() {
						netyeildVal();					
					});
				}
				else{
					$('#net-yeild-ie-button').hide();
					$('#net-price-ie-button').show();
					$('#no-netprice-ie-button').hide();
					$('#net-price-ie-button').click(function() {
						NetpriceVal();					
					});
				}
				
			} else
			{
				$('.no-hide').fadeOut();
				$('.sdlt-yield').fadeOut()
				$('.sdlt-price').fadeOut();
				$('#net-yeild-percent').hide();
				$('#net-yeild-ie-button').hide();
				$('#net-price-ie-button').hide();
				$('#no-netprice-ie-button').show();
				$('#net-price').show();
				$('#no-netprice-ie-button').on("click", function(){
					if($('#net-price2').val()==""){					
						$("#result-sdlt-cost").html('');
						$('#result-purchase-per').html('');
						$('#result-net-yield').html('');
						$('#result-sdlt-per').html('');
						TotalResultChart();
						TotalResultChart1();
						TotalResultChart2();
						delay(function(){
							alert("Enter the Net Price");
						}, 200 );
					}else{
					   getpriceNo();
						TotalResultChart();
						TotalResultChart2();
					   $('#result-sdlt-cost').digits();
					}
				});
				$('#net-price2').val('');
				$('#net-yeild').val('');
				$('#result-sdlt-cost').html('');
				$('#result-purchase-per').html('');
				$('#result-net-yield').html('');
				$('#result-sdlt-per').html('');
				TotalResultChart();
				TotalResultChart1();
				TotalResultChart2()
			}
		});
/* Net Yield start */

	var sdltcheck = 0; 
	var netyieldPrecent = 0;
	var income = 0;
	var inputNetYield = 0; //In Percentage
	var inputNetYieldDecimal = 0; //In Decimal
	
	var initalPurchaseCost = 0;
	var initalTargetPrice = 0;
	var proportion = '';
	var sdltpercentage = 0;
	var calulatedNetYield = 0;
	
	var noOfIteration = 0;
	
	var inputRangePrice = 0;
	var minPrice = 0;
	var maxPrice = 0;
	var loopCount = 0;
	var rangeArray = [];
	
	function netYieldcalc(){
		//console.clear();
		//Intiate new start
		sdltcheck = 0; 
		netyieldPrecent = 0;
		income = 0;
		inputNetYield = 0;
		inputNetYieldDecimal = 0;
		initalPurchaseCost = 0;
		initalTargetPrice = 0;
		proportion = '';
		calulatedNetYield = 0;
		noOfIteration = 0;
		inputRangePrice = 0;
		minPrice = 0;
		maxPrice = 0;
		loopCount = 0;
		sdltpercentage = 0;
		rangeArray = [];
		//Initate new start
		
		income = ($("#income").val() *1 );
		inputNetYield = ($("#net-yeild").val() * 1);
		initalTargetPrice = income * 5;
		inputRangePrice = initalTargetPrice;
		inputNetYieldDecimal = inputNetYield/100;
		forwardProportion();
	};
	
	function FindNetYieldPercent(income,initalTargetPrice,initalPurchaseCost){
		//console.log("FindNetYieldPercent");
		NewSDLT(initalTargetPrice);
		NewPurchasersCost(initalTargetPrice);
		NetYieldPercentage(income,initalTargetPrice,initalPurchaseCost);
		return netyieldPrecent;
		
	}
	
	function forwardProportion(){
		loopCount++;
		if	(loopCount>12){
			//console.log("Infinite loop break");
			return false;
		}
		calulatedNetYield = calculateNetYield(income,inputRangePrice,initalPurchaseCost);
		//console.log("inputRangePrice : "+ inputRangePrice +" | calulatedNetYield : "+calulatedNetYield );
        var diffenceValue = parseFloat(inputNetYield)-parseFloat(calulatedNetYield);
        if(inputNetYield.toFixed(12)==calulatedNetYield.toFixed(12)){
			//console.log("Min diff in FWD");
		}else{
			if(diffenceValue<0){//Negative
				if(proportion!="P"){
					proportion = "N"; 
					inputRangePrice = inputRangePrice*2;
					//console.log("Negative diffenceValue : " + diffenceValue +" | Input Value : "+ inputRangePrice );
					forwardProportion();
				}else{
					loopCount =0;
					finalRange();
				}
				
			}else if(diffenceValue>0){//Positve
				if(proportion!="N"){
				proportion = "P"; 
				inputRangePrice = inputRangePrice/2;
				//console.log("Positive diffenceValue : " + diffenceValue +" | Input Value : "+ inputRangePrice );
				forwardProportion();
				}else{
					loopCount=0;
					finalRange();
				}
			}
		}
	}
	
	function finalRange(){
		//console.log("final range proportion : "+proportion);
		if(proportion=="N"){
			maxPrice = inputRangePrice;
			minPrice = inputRangePrice/2;
			//console.log("Min "+minPrice);
			//console.log("Max "+maxPrice);
			rangeArray =[];
			findMinDiffernce();
		}else{
			maxPrice = inputRangePrice*2;
			minPrice = inputRangePrice;
			//console.log("Min "+minPrice);
			//console.log("Max "+maxPrice);
			rangeArray =[];
			findMinDiffernce();
		}
	} 

	function findMinDiffernce(){
		loopCount++;
		if (loopCount>12){
			//console.log("Infinite loop break in findMinDiffernce");
			return false;
		}
		calulatedNetYield = calculateNetYield(income,minPrice,initalPurchaseCost);
		//console.log("Price : "+ minPrice + " | calculated :"+calulatedNetYield.toFixed(4) + " | input : "+inputNetYield.toFixed(4));
		if(parseFloat(calulatedNetYield.toFixed(12))<parseFloat(inputNetYield.toFixed(12))){
			//console.log(rangeArray);
			if(rangeArray.length>1){
				minPrice = rangeArray[rangeArray.length-2];
				maxPrice = rangeArray[rangeArray.length-1];
			}else{
				minPrice = inputRangePrice/2;
				maxPrice = rangeArray[rangeArray.length-1];
			}
			rangeArray = [];
			finalPrice();
			}else{
			if(minPrice>maxPrice){
				//console.log("Min price is greater than Max Price");
			}else{
				minPrice = (minPrice+maxPrice)/2;
				rangeArray.push(minPrice);
				findMinDiffernce();
			}
		}
	}

	function finalPrice(){
		loopCount++;
		if (loopCount>80){
			//console.log("Infinite loop break");
			return false;
		}
		rangeArray.push(minPrice);
		calulatedNetYield = calculateNetYield(income,minPrice,initalPurchaseCost);
		//console.log("finalPrice : "+ minPrice + " | calculated :"+calulatedNetYield.toFixed(12) + " | input : "+inputNetYield.toFixed(12));
		//$("#netprice").html("Net Price : " + minPrice.toFixed(0) + " <br>SDLT :" + sdltcheck.toFixed(0) +" <br>Purchase cost % : "+ (initalPurchaseCost*100).toFixed(2)+" <br>NYield %: "+ (netyieldPrecent*100).toFixed(2));
		if(minPrice){ // allow only valid number
			sdltpercentage = (sdltcheck / minPrice) *100;
			//set the ouput
			//console.log(minPrice);
			$("#netpriceOutput").html(minPrice.toFixed(0));
			$("#result-sdlt-cost").html(sdltcheck.toFixed(0));
			$("#result-purchase-per").html((initalPurchaseCost*100).toFixed(2)+" %");
			$("#result-sdlt-per").html((sdltpercentage).toFixed(2)+" %");
			$('#netpriceOutput').digits();
			//TotalResultChart();
			//TotalResultChart1();
			//TotalResultChart2();
			var minDff = calulatedNetYield.toFixed(12) -inputNetYield.toFixed(12);
			//console.log("minDff : "+minDff.toFixed(12)); 
			if(minDff.toFixed(12)<0){ //Check negative to rest the min to max
				minPrice = rangeArray[rangeArray.length-2];
				maxPrice = rangeArray[rangeArray.length-1];
				rangeArray = [];
				finalPrice();
			}else
			{ // If non negative continue to match min difference
				if(minDff.toFixed(12)==0.000000000000){
					//console.log("Final Price " + minPrice);
				}else if(minDff.toFixed(12)>=0.000000000001 && minDff.toFixed(12)<=0.000000000010){ //Find minimum differnce
					minPrice = rangeArray[rangeArray.length-1];
					minPrice = (minPrice+maxPrice)/2;
					finalPrice();
				}else
				{ //break to mid point to get min price
					if(minPrice>maxPrice){
						//console.log("Min price is greater than Max Price");
					}else{
						minPrice = (minPrice+maxPrice)/2;
						finalPrice();
					}
				}
			}
		}
	}
	
    function calculateNetYield(incomeVal,initialTarPriceVal,initialPurchaseCostVal){
		//console.log("calculateNetYield");
        noOfIteration++;
        var temp = 0;
        temp = FindNetYieldPercent(incomeVal,initialTarPriceVal,initialPurchaseCostVal);
        temp = temp*100;
        return parseFloat(temp);
		//return (temp.toFixed(3) * 1);
    }

	// find SDLT cost income,initalTargetPrice,initalPurchaseCost
	function NewSDLT(initalTargetPrice){
		//console.log("NewSDLT");
		//console.log("target price: " + initalTargetPrice);
		if (initalTargetPrice <= 150000) {			
			sdltcheck = initalTargetPrice * 0;
		} 
		else 
			if (initalTargetPrice <= 250000) {
			sdltcheck = (150000 * 0) + ((initalTargetPrice - 150000) * 0.02);
		} 
		else 
			if (initalTargetPrice > 250000) {
			sdltcheck = (150000 * 0) + ((250000 - 150000) * 0.02) + ((initalTargetPrice - 250000) * 0.05);
		}
		//console.log("New SDLT: " + sdltcheck);
	}
	
	// find purchase cost
	function NewPurchasersCost(initalTargetPrice){
		//console.log("NewPurchasersCost");
		initalPurchaseCost = ((initalTargetPrice * 0.018) + sdltcheck) / initalTargetPrice;
		//console.log("New Purchase cost: " + initalPurchaseCost);
		
	}
	
	//netyield percentage
	function NetYieldPercentage(income,initalTargetPrice,initalPurchaseCost){
		//console.log("NetYieldPercentage");
		netyieldPrecent = (income / initalTargetPrice /(1 + initalPurchaseCost));
		////console.log("NetYield Percentage: " + netyieldPrecent);
	}

/* Net Yield end */
	
});
