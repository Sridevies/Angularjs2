$(document).ready(function(){
	$(".team-photo").hover(function(){
		//$(this).find(".info-box").animate({"bottom":""});
	});
	
	$(".team-photo").hover(function(){
		$(this).find("h3").fadeOut();
		$(this).find(".hover1").stop().animate({"height":"0"},700);
		$(this).find(".hover2").stop().animate({"height":"0"},700);

		$(this).find(".info-box-bottom").stop().animate({"height":"0","height":"150px"},700);
		$(this).find(".info-box-top").stop().animate({"height":"0","height":"150px"},700);
	},function(){
		$(this).find("h3").fadeIn();
		$(this).find(".hover1").stop().animate({"height":"100%"},700);
		$(this).find(".hover2").stop().animate({"height":"100%"},700);

		$(this).find(".info-box-bottom").stop().animate({"height":"0","height":"00px"},700);
		$(this).find(".info-box-top").stop().animate({"height":"0","height":"00px"},700);
	});
	
	$(window).scroll(function() {
		//var halfWidth = $("#team-members").width()/2;
		if($(window).scrollTop() + $(window).height() == $(document).height()) {
			$('.mouse-icon').fadeOut();
		}else{
			$('.mouse-icon').fadeIn();
		}
	});
	$('#service-view-all .flexslider').flexslider({
		animation: "slide",
		slideshow: false,
		animationLoop: true,
		itemWidth: 250,
		itemMargin:20,
		minItems: 2,
		maxItems: 4
	});
	var slidertrainingviewallCount = $("#service-view-all .flex-control-nav li").length;
	$("#service-view-count").text(slidertrainingviewallCount);
	startSlider()
	viewAllTriggerService()
	
	
	
});
	
function viewAllTriggerService(){
	$('.view-all-container-close').click(function(){
		$('.view-all-container').stop().animate({'right': '-2000'},1000);
		//$('.view-all-container').css("left","-2000px");
		$('.view-all-container').show();
	});
	
	$(window).scroll(function(){
		$('.view-all-container').stop().animate({'right': '-2000'},100);
	});
}
function startSlider(){

	$('#slider-training .flexslider').flexslider({
		animation: "slide",
		slideshow: false,
		animationLoop: true
	});

	$('#slider-service .flexslider').flexslider({
		animation: "slide",
		slideshow: false,
		animationLoop: true
	});

	$('#slider-example-uses .flexslider').flexslider({
		animation: "slide",
		slideshow: false,
		animationLoop: true
	});


	$('#service-view-all-sector .flexslider').flexslider({
		//controlNav: true,
		//directionNav: true,
		//slideshow: false, 
		//animation: "slide",
		//animationLoop: true,
		animation: "slide",
		slideshow: false,
		animationLoop: true,
		itemWidth: 250,
		itemMargin:20,
		minItems: 2,
		maxItems: 4
	});

	

	var sliderTrainingCount = $("#slider-training .flex-control-nav li").length;
	$("#slider-training .slide-total-count span").text(sliderTrainingCount);
	var sliderTrainingCount = $("#slider-service .flex-control-nav li").length;
	$("#slider-service .slide-total-count span.slide-tot-val").text(sliderTrainingCount);
	var sliderTrainingCount = $("#slider-example-uses .flex-control-nav li").length;
	$("#slider-example-uses .slide-total-count span").text(sliderTrainingCount);
	var slidertrainingviewallCount = $("#service-view-all .flex-control-nav li").length;
	$("#service-view-count").text(slidertrainingviewallCount);
	var slidertrainingviewallCountSector = $("#service-view-all-sector .flex-control-nav li").length;
	$("#service-view-count-sector").text(slidertrainingviewallCountSector);
}