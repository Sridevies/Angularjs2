videojs.registerPlugin('jll_fullscreen', function(options) {
	
	var player,
		forceFullWidth;

		player = this;

		if(!options || typeof options.forceFullWidth == "undefined") {
			console.log('WARNING - forceFullWidth parameter missing - Will default to "true".');
			forceFullWidth = true;
		}
		else {
			forceFullWidth = !!options.forceFullWidth;
		}

	//check for JQuery
	if(!window.jQuery) {
		var jQueryScript = document.createElement('script');
		jQueryScript.src = 'https://code.jquery.com/jquery-3.2.1.min.js';
		jQueryScript.type = 'text/javascript';
		document.getElementsByTagName('head')[0].appendChild(jQueryScript);

		jQueryScript.onload = function(){
			jQuery.noConflict();
			pluginConfiguration(jQuery);
		};
	}
	else{
		pluginConfiguration(jQuery);
	}

	function pluginConfiguration(jQuery){
		var controlBar,
			playButton,
			volumeButton,
			progressBar;

		forceFullWidth ? player.addClass('jll_background_video_force') : player.addClass('jll_background_video');

		// Play on start
		player.autoplay(true);

		// Loop video
		player.loop(true);

		// Disable standard controls (custom control bar will be used)
		player.controls(false);

		// Mute by default
		player.muted(true);


		// Create control bar elements
		controlBar = jQuery('<div id="jll_controlBar"></div>"');

		playButton = jQuery('<button class="vjs-play-control vjs-control vjs-button vjs-playing" type="button" aria-live="polite" title="play/pause" aria-disabled="false"></button>');
		playButton.append('<span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text">Play</span>');
		controlBar.append(playButton);

		volumeButton = jQuery('<button class="vjs-mute-control vjs-control vjs-button vjs-vol-0" type="button" aria-live="polite" title="mute/unmute" aria-disabled="false"></button>');
		volumeButton.append('<span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text">Mute/Unmute</span>');
		controlBar.append(volumeButton);

		progressBar = jQuery(player.el_).find('.vjs-progress-control.vjs-control').first().detach();

		controlBar.append(progressBar);


		// Create events for elements
		playButton.click(function(){
			if(player.paused()){
				player.play();
				jQuery(this).removeClass('vjs-paused').addClass('vjs-playing');
			}
			else{
				player.pause();
				jQuery(this).removeClass('vjs-playing').addClass('vjs-paused');
			}
		});

		volumeButton.click(function(){
			if(player.muted()){
				player.muted(false);
				player.volume(1);
				jQuery(this).removeClass('vjs-vol-0');
			}
			else{
				player.muted(true);
				jQuery(this).addClass('vjs-vol-0');
			}
		});


		//Append the control bar to the body
		jQuery('body').prepend(controlBar);

	};
});